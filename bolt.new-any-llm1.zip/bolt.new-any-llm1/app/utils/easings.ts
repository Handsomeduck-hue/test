import { cubicBezier } from 'framer-motion';

export const cubicEasingFn = cubicBezier(0.4, 0, 0.2, 1);
