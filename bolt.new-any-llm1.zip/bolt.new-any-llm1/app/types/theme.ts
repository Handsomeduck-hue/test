export type Theme = 'dark' | 'light';
