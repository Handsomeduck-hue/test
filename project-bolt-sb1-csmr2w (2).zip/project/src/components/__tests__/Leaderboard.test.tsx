import React from 'react';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Leaderboard } from '../Leaderboard';
import type { LeaderboardEntry } from '../../lib/supabase';

describe('Leaderboard', () => {
  const mockEntries: LeaderboardEntry[] = [
    { id: '1', user_id: 'user1', username: 'Player 1', score: 1000, created_at: '2024-03-17' },
    { id: '2', user_id: 'user2', username: 'Player 2', score: 800, created_at: '2024-03-17' },
    { id: '3', user_id: 'user3', username: 'Player 3', score: 600, created_at: '2024-03-17' }
  ];

  it('renders leaderboard title', () => {
    render(<Leaderboard entries={mockEntries} />);
    expect(screen.getByText('Leaderboard')).toBeInTheDocument();
  });

  it('displays entries in correct order', () => {
    render(<Leaderboard entries={mockEntries} />);
    const scores = screen.getAllByText(/\d+/).map(el => parseInt(el.textContent || '0'));
    expect(scores).toEqual([1000, 800, 600]);
  });

  it('highlights current user entry', () => {
    render(<Leaderboard entries={mockEntries} currentUserId="user2" />);
    const playerRow = screen.getByText('Player 2').closest('div');
    expect(playerRow).toHaveClass('bg-system-blue/10');
  });

  it('shows medal icons for top 3 players', () => {
    render(<Leaderboard entries={mockEntries} />);
    const medals = document.querySelectorAll('svg.text-yellow-500, svg.text-gray-400, svg.text-amber-600');
    expect(medals.length).toBe(3);
  });

  it('shows "You" badge for current user', () => {
    render(<Leaderboard entries={mockEntries} currentUserId="user1" />);
    expect(screen.getByText('You')).toBeInTheDocument();
  });
});