import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../../modules/ui/utils/cn';

type GameHintProps = {
  hint: string;
};

export function GameHint({ hint }: GameHintProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: 10 }}
      transition={{ type: "spring", stiffness: 300, damping: 25 }}
      className={cn(
        "p-4 sm:p-6",
        "bg-system-blue/5 dark:bg-system-blue-dark/5",
        "border border-system-blue/10 dark:border-system-blue-dark/10",
        "rounded-xl sm:rounded-2xl text-center",
        "backdrop-blur-sm shadow-lg",
        "transform-gpu"
      )}
    >
      <p className="text-sm sm:text-base text-[#1D1D1F] dark:text-white font-medium leading-relaxed">
        {hint}
      </p>
    </motion.div>
  );
}