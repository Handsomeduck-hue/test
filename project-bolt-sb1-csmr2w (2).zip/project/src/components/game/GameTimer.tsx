import React from 'react';
import { motion } from 'framer-motion';
import { Timer } from 'lucide-react';
import { Badge } from '../../modules/ui/components/Badge';

type GameTimerProps = {
  timeRemaining: number;
};

export function GameTimer({ timeRemaining }: GameTimerProps) {
  return (
    <Badge variant="orange" className="text-sm sm:text-base lg:text-lg">
      <Timer className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
      {Math.ceil(timeRemaining)}s
    </Badge>
  );
}