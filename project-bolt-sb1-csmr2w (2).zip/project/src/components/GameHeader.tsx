import React from 'react';
import { Timer, Heart, Trophy, Zap, HelpCircle } from 'lucide-react';
import { motion } from 'framer-motion';
import { cn } from '../modules/ui/utils/cn';

type GameHeaderProps = {
  score: number;
  lives: number;
  level: number;
  timeRemaining: number;
  currentStreak: number;
  hintsRemaining: number;
  onUseHint: () => void;
};

export function GameHeader({
  score = 0,
  lives = 3,
  level = 1,
  timeRemaining = 30,
  currentStreak = 0,
  hintsRemaining = 3,
  onUseHint,
}: GameHeaderProps) {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-3">
      <div className="grid grid-cols-3 gap-3">
        <div className={cn(
          "flex items-center justify-between p-3",
          "bg-white dark:bg-[#1C1C1E]",
          "rounded-xl shadow-sm"
        )}>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Trophy className="w-3 h-3 sm:w-4 sm:h-4 text-system-yellow dark:text-system-yellow-dark" />
            <span className="text-sm sm:text-base lg:text-lg font-bold">{score.toLocaleString()}</span>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Zap className="w-3 h-3 sm:w-4 sm:h-4 text-system-purple dark:text-system-purple-dark" />
            <span className="text-sm sm:text-base lg:text-lg font-bold">{currentStreak}x</span>
          </div>
        </div>

        <div className={cn(
          "flex items-center justify-center p-3",
          "bg-white dark:bg-[#1C1C1E]",
          "rounded-xl shadow-sm"
        )}>
          <div className="flex items-center gap-1">
            {Array.from({ length: 3 }).map((_, i) => (
              <motion.div
                key={i}
                animate={{
                  scale: i < lives ? 1 : 0.8,
                  opacity: i < lives ? 1 : 0.3,
                }}
              >
                <Heart
                  className={cn(
                    "w-4 h-4 sm:w-5 sm:h-5",
                    i < lives 
                      ? "text-system-red fill-system-red dark:text-system-red-dark dark:fill-system-red-dark" 
                      : "text-system-gray-3 dark:text-system-gray-dark-3"
                  )}
                />
              </motion.div>
            ))}
          </div>
        </div>

        <div className={cn(
          "flex items-center justify-between p-3",
          "bg-white dark:bg-[#1C1C1E]",
          "rounded-xl shadow-sm"
        )}>
          <div className="flex items-center gap-1.5 sm:gap-2">
            <Timer className="w-4 h-4 sm:w-5 sm:h-5 text-system-blue dark:text-system-blue-dark" />
            <motion.span
              key={timeRemaining}
              initial={{ scale: 1.2 }}
              animate={{ scale: 1 }}
              className="text-base sm:text-lg lg:text-xl font-bold"
            >
              {Math.max(0, Math.floor(timeRemaining))}s
            </motion.span>
          </div>
          <button
            onClick={onUseHint}
            disabled={hintsRemaining <= 0}
            className={cn(
              "flex items-center gap-1.5 sm:gap-2 px-2.5 sm:px-3 py-1 rounded-lg",
              "transition-colors duration-200 text-sm sm:text-base",
              hintsRemaining > 0
                ? "bg-system-indigo/10 text-system-indigo hover:bg-system-indigo/20 dark:bg-system-indigo-dark/20 dark:text-system-indigo-dark"
                : "bg-system-gray-4/10 text-system-gray-4 cursor-not-allowed dark:bg-system-gray-dark-4/20 dark:text-system-gray-dark-4"
            )}
          >
            <HelpCircle className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
            <span className="font-medium">{hintsRemaining}</span>
          </button>
        </div>
      </div>
    </div>
  );
}