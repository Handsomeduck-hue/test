import { isAdBlockEnabled } from './utils';
import { AD_RETRY_ATTEMPTS, AD_RETRY_DELAY, AD_CONTAINER_ID } from './constants';

export type AdErrorCode = 
  | 'NO_FILL'
  | 'NETWORK_ERROR' 
  | 'TIMEOUT'
  | 'INVALID_STATE'
  | 'AD_BLOCKER'
  | 'INITIALIZATION_ERROR'
  | 'LOAD_ERROR';

export type AdErrorDetails = {
  code: AdErrorCode;
  message: string;
  timestamp: number;
  adUnit?: string;
  retryAttempts?: number;
};

export const AD_ERROR_MESSAGES = {
  NO_FILL: 'No ads are currently available. Please try again later.',
  NETWORK_ERROR: 'Unable to load ad due to network connectivity issues.',
  TIMEOUT: 'Ad request timed out. Please check your connection and try again.',
  INVALID_STATE: 'Ad system is in an invalid state. Please restart the app.',
  AD_BLOCKER: 'Ad blocker detected. Please disable it to watch ads.',
  INITIALIZATION_ERROR: 'Failed to initialize ad services.',
  LOAD_ERROR: 'Failed to load advertisement. Please try again.'
};

export const USER_FRIENDLY_SOLUTIONS = {
  NO_FILL: [
    'Wait a few minutes before trying again',
    'Check that you have a stable internet connection'
  ],
  NETWORK_ERROR: [
    'Check your internet connection',
    'Try switching between Wi-Fi and mobile data'
  ],
  TIMEOUT: [
    'Check your internet speed',
    'Try moving to an area with better signal'
  ],
  INVALID_STATE: [
    'Refresh the page',
    'Clear browser cache'
  ],
  AD_BLOCKER: [
    'Disable any ad blocking apps or browser extensions',
    'Add this site to your ad blocker\'s whitelist'
  ],
  INITIALIZATION_ERROR: [
    'Refresh the page',
    'Clear browser cache and try again'
  ]
};

export const troubleshootAdError = async (error: AdErrorDetails): Promise<string> => {
  if (await isAdBlockEnabled()) {
    return AD_ERROR_MESSAGES.AD_BLOCKER;
  }

  try {
    const response = await fetch('https://www.google.com/generate_204');
    if (!response.ok) {
      return AD_ERROR_MESSAGES.NETWORK_ERROR;
    }
  } catch {
    return AD_ERROR_MESSAGES.NETWORK_ERROR;
  }

  return AD_ERROR_MESSAGES[error.code] || 'An unknown error occurred. Please try again.';
};

export const getAdErrorSolutions = (errorCode: AdErrorCode): string[] => {
  return USER_FRIENDLY_SOLUTIONS[errorCode] || [
    'Try again later',
    'Check your internet connection'
  ];
};

export const checkAdRequirements = (): { ready: boolean; issues: string[] } => {
  const issues: string[] = [];

  if (!navigator.onLine) {
    issues.push('No internet connection detected');
  }

  if (isAdBlockEnabled()) {
    issues.push('Ad blocker detected');
  }

  if (!window.googletag) {
    issues.push('Ad service not initialized');
  }

  return {
    ready: issues.length === 0,
    issues
  };
};