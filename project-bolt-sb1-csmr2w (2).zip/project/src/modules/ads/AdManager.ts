import { create } from 'zustand';
import { AD_CLIENT_ID, AD_SLOT_ID, AD_TIMEOUT, AD_RETRY_INTERVAL } from './constants';

type AdState = {
  isLoading: boolean;
  error: string | null;
  initialized: boolean;
};

type AdStore = {
  state: AdState;
  actions: {
    initializeAds: () => Promise<void>;
  };
};

const initialState: AdState = {
  isLoading: false,
  error: null,
  initialized: false
};

export const useAdStore = create<AdStore>((set) => ({
  state: initialState,
  actions: {
    initializeAds: async () => {
      try {
        const { initialized } = useAdStore.getState().state;
        if (initialized) {
          return;
        }

        set({ state: { ...initialState, isLoading: true } });
        
        // Initialize adsbygoogle if not already done
        window.adsbygoogle = window.adsbygoogle || [];

        // Wait for AdSense to be ready
        await new Promise<void>((resolve, reject) => {
          if (window.adsbygoogle) {
            resolve();
            return;
          }

          // Wait for AdSense script to load
          const checkAdsense = setInterval(() => {
            if (window.adsbygoogle) {
              clearInterval(checkAdsense);
              resolve();
            }
          }, AD_RETRY_INTERVAL);
          
          // Timeout after specified duration
          setTimeout(() => {
            clearInterval(checkAdsense);
            reject(new Error('AdSense initialization timeout'));
          }, AD_TIMEOUT);
        });

        set({ 
          state: { 
            isLoading: false, 
            error: null,
            initialized: true 
          } 
        });
      } catch (error) {
        set({ 
          state: { 
            isLoading: false,
            initialized: false,
            error: error instanceof Error ? error.message : 'Failed to initialize ads'
          } 
        });
      }
    }
  }
}));