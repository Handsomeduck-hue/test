export const AD_CLIENT_ID = 'ca-pub-1276418176853020';
export const AD_SLOT_ID = '5464678735';
export const AD_CONTAINER_ID = 'ad-container';

// Timeouts
export const AD_TIMEOUT = 5000; // 5 seconds
export const AD_RETRY_INTERVAL = 100; // 100ms between retries

export const AD_CONTAINER_STYLES = {
  position: 'relative',
  margin: '1rem auto',
  textAlign: 'center',
  minHeight: '250px',
  maxWidth: '970px',
  overflow: 'hidden',
  background: 'rgba(0, 0, 0, 0.02)',
  borderRadius: '0.5rem'
} as const;