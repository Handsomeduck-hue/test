export { useAdStore } from './AdManager';
export type { AdState, AdStore } from './types';