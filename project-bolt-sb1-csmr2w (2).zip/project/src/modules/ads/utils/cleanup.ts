export function cleanupAdContainer(containerId: string): void {
  const container = document.getElementById(containerId);
  if (container) {
    container.remove();
  }
}

export function cleanupAdResources(resources: {
  container?: HTMLElement;
  adDisplayContainer?: any;
  adsLoader?: any;
  adsManager?: any;
}): void {
  try {
    if (resources.container?.parentElement) {
      resources.container.remove();
    }
    if (resources.adDisplayContainer) {
      resources.adDisplayContainer.destroy();
    }
    if (resources.adsLoader) {
      resources.adsLoader.destroy();
    }
    if (resources.adsManager) {
      resources.adsManager.destroy();
    }
  } catch (error) {
    console.debug('Ad cleanup error:', error);
  }
}