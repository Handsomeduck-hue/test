import { AD_ERROR_MESSAGES } from '../constants';

export function validateAdRequirements(): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Check if page is visible
  if (document.hidden) {
    errors.push('Page must be visible to initialize ads');
  }

  // Check network connectivity
  if (!navigator.onLine) {
    errors.push(AD_ERROR_MESSAGES.NETWORK);
  }

  // Check if ad blocker is present
  if (document.querySelector('script[src*="gpt.js"]')?.hasAttribute('data-blocked')) {
    errors.push(AD_ERROR_MESSAGES.BLOCKED);
  }

  // Check if googletag is already defined but in an error state
  if (window.googletag && !window.googletag.apiReady) {
    errors.push('GPT API not ready');
  }

  // Check for low memory conditions
  if (performance?.memory && performance.memory.jsHeapSizeLimit - performance.memory.usedJSHeapSize < 50 * 1024 * 1024) {
    errors.push('Low memory detected. Please close other apps and try again.');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}