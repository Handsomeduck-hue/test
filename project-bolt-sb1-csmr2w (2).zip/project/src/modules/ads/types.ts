declare global {
  interface Window {
    adsbygoogle: any[];
  }
}

export interface AdState {
  isLoading: boolean;
  error: string | null;
  initialized: boolean;
}

export interface AdStore {
  state: AdState;
  actions: {
    initializeAds: () => Promise<void>;
  };
}