import ReactGA from 'react-ga4';

ReactGA.initialize('G-K99WE65NDE', {
  testMode: process.env.NODE_ENV !== 'production',
  gaOptions: {
    cookieFlags: 'SameSite=None;Secure',
    anonymizeIp: true,
    allowAdFeatures: false
  }
});

export const pageview = (url: string) => {
  ReactGA.send({ hitType: 'pageview', page: url });
};

export const event = ({
  action,
  category,
  label,
  value
}: {
  action: string;
  category: string;
  label?: string;
  value?: number;
}): void => {
  ReactGA.event({
    action,
    category,
    label,
    value
  });
};