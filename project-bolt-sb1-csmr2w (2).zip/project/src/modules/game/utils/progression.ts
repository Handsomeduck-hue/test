import { GameState, Difficulty } from '../types';
import { difficultyProgression } from '../../../data/categories';

export const checkDifficultyProgression = (state: GameState): Difficulty => {
  const { scoreThresholds } = difficultyProgression;
  
  if (state.score >= scoreThresholds[Difficulty.Expert]) {
    return Difficulty.Expert;
  }
  if (state.score >= scoreThresholds[Difficulty.Hard]) {
    return Difficulty.Hard;
  }
  if (state.score >= scoreThresholds[Difficulty.Medium]) {
    return Difficulty.Medium;
  }
  return Difficulty.Easy;
};