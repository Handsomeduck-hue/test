export const enum Difficulty {
  Easy = 'EASY',
  Medium = 'MEDIUM',
  Hard = 'HARD',
  Expert = 'EXPERT'
}

export type Achievement = {
  id: string;
  name: string;
  description: string;
  icon: React.ElementType;
  reward: Reward;
};

export type Reward = {
  type: 'extra_life' | 'hint' | 'time_bonus' | 'score_multiplier';
  value: number;
};

export type GameSet = {
  items: string[];
  oddOneOut: string;
  explanation: string;
  hint: string;
};

export type Category = {
  name: string;
  difficulty: Difficulty;
  sets: GameSet[];
};

export type GameResult = {
  correct: boolean;
  bonus?: number;
  mistake?: string;
  message?: string;
};

export type HighScore = {
  score: number;
  date: string;
  difficulty: Difficulty;
  level: number;
  achievements: Achievement[];
};

export type GameState = {
  score: number;
  currentLevel: number;
  lives: number;
  gameOver: boolean;
  gameStarted: boolean;
  hintsRemaining: number;
  currentStreak: number;
  bestStreak: number;
  timeRemaining: number;
  showHint: boolean;
  currentCategory?: Category;
  currentSet?: GameSet;
  lastResult: GameResult | null;
  difficulty: Difficulty;
  totalGamesPlayed: number;
  highScores: HighScore[];
  timeBonus: number;
  streakBonus: number;
  difficultyBonus: number;
  achievements: Achievement[];
};