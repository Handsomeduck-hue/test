import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../utils/cn';

type CardProps = {
  variant?: 'default' | 'elevated';
  children: React.ReactNode;
  className?: string;
  animate?: boolean;
} & React.HTMLAttributes<HTMLDivElement>;

export function Card({ 
  variant = 'default',
  children, 
  className, 
  animate = true,
  ...props 
}: CardProps) {
  const Component = animate ? motion.div : 'div';

  const desktopAnimation = {
    hover: {
      y: -4,
      transition: { duration: 0.2 }
    },
    tap: {
      scale: 0.98,
      transition: { duration: 0.1 }
    }
  };

  const variants = {
    default: 'bg-white dark:bg-[#1C1C1E] shadow-sm',
    elevated: 'bg-white dark:bg-[#1C1C1E] shadow-lg'
  };

  return (
    <Component
      initial={animate ? { opacity: 0, y: 20 } : undefined}
      animate={animate ? { opacity: 1, y: 0 } : undefined}
      whileHover={animate ? desktopAnimation.hover : undefined}
      whileTap={animate ? desktopAnimation.tap : undefined}
      className={cn(
        'w-full rounded-3xl p-4 sm:p-6 md:p-8',
        'border border-[#E5E5EA] dark:border-[#38383A]',
        variants[variant],
        'touch-manipulation select-none',
        'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-system-blue dark:focus-visible:ring-system-blue-dark',
        'transition-all duration-200',
        className
      )}
      {...props}
    >
      {children}
    </Component>
  );
}