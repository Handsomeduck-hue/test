import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../utils/cn';

type GameCardProps = {
  item: string;
  index: number;
  onClick: () => void;
  disabled: boolean;
  selected?: boolean;
};

export function GameCard({ item, index, onClick, disabled, selected }: GameCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: 1, 
        y: 0,
        scale: selected ? 0.95 : 1,
        transition: { delay: index * 0.1 }
      }}
      whileHover={disabled ? {} : { scale: 1.02 }}
      whileTap={disabled ? {} : { scale: 0.98 }}
      className={cn(
        'relative w-full aspect-square',
        'flex items-center justify-center',
        'bg-white dark:bg-[#1C1C1E]',
        'rounded-2xl',
        'text-lg sm:text-xl md:text-2xl font-medium',
        'border-2',
        selected ? 'border-[#007AFF] dark:border-[#0A84FF]' : 'border-transparent',
        disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:border-[#007AFF] dark:hover:border-[#0A84FF]',
        'shadow-sm hover:shadow-md transition-all duration-200',
        'touch-manipulation select-none',
        'text-[#1C1C1E] dark:text-white'
      )}
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
    >
      <span className="relative z-10 px-4 text-center break-words">{item}</span>
      <div className="absolute inset-0 bg-gradient-to-br from-white to-[#F2F2F7] dark:from-[#1C1C1E] dark:to-[#2C2C2E] rounded-2xl -z-0" />
    </motion.button>
  );
}