import React from 'react';
import { Helmet } from 'react-helmet';
import { AboutPage } from '../components/AboutPage';

export default function AboutRoute() {
  return (
    <>
      <Helmet>
        <title>About 1 Odd Out | Science-Based Brain Training Games</title>
        <meta name="description" content="Learn about our science-based approach to brain training. Discover how 1 Odd Out helps millions improve cognitive skills through engaging puzzles." />
        <meta name="keywords" content="about brain training, cognitive science games, puzzle game development, mental exercise platform, brain training science" />
        <link rel="canonical" href="https://1oddout.com/about" />
      </Helmet>

      <AboutPage />
    </>
  );
}