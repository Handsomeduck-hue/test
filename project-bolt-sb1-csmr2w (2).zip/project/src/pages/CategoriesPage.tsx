import React from 'react';
import { Helmet } from 'react-helmet';
import { Card } from '../modules/ui/components/Card';
import { Brain, Target, Zap, Book } from 'lucide-react';
import { Badge } from '../modules/ui/components/Badge';
import { Button } from '../modules/ui/components/Button';
import { categories } from '../data/categories';

export default function CategoriesPage() {
  return (
    <>
      <Helmet>
        <title>Game Categories | 1 Odd Out Brain Training</title>
        <meta name="description" content="Explore diverse brain training categories: logic puzzles, memory games, pattern recognition, and more. Find the perfect mental workout." />
      </Helmet>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        <h1 className="text-4xl font-bold text-center mb-8">Game Categories</h1>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {categories.map((category) => (
            <Card key={category.name} className="relative overflow-hidden">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Brain className="w-5 h-5 text-system-blue dark:text-system-blue-dark" />
                  <h2 className="text-lg font-semibold">{category.name}</h2>
                </div>
                <Badge variant={category.difficulty === 'EASY' ? 'green' : 
                             category.difficulty === 'MEDIUM' ? 'orange' : 'red'}>
                  {category.difficulty}
                </Badge>
              </div>

              <p className="text-gray-600 dark:text-gray-400 mb-4">
                {category.sets[0].explanation}
              </p>

              <div className="flex items-center gap-2 mb-4">
                <Badge variant="blue">{category.sets.length} Puzzles</Badge>
                <Badge variant="purple">High Score: 2,500</Badge>
              </div>

              <Button className="w-full">Play Now</Button>
            </Card>
          ))}
        </div>
      </div>
    </>
  );
}