import { createClient } from '@supabase/supabase-js';

const supabaseUrl = 'https://your-project.supabase.co';
const supabaseKey = 'your-anon-key';

export const supabase = createClient(supabaseUrl, supabaseKey);

export type LeaderboardEntry = {
  id: string;
  user_id: string;
  username: string;
  score: number;
  created_at: string;
};

export async function getLeaderboard(): Promise<LeaderboardEntry[]> {
  const { data, error } = await supabase
    .from('leaderboard')
    .select('*')
    .order('score', { ascending: false })
    .limit(100);

  if (error) throw error;
  return data || [];
}

export async function submitScore(score: number, username: string): Promise<void> {
  const { error } = await supabase
    .from('leaderboard')
    .insert([{ score, username }]);

  if (error) throw error;
}

export async function getDailyChallenge(): Promise<any> {
  const { data, error } = await supabase
    .from('daily_challenges')
    .select('*')
    .eq('date', new Date().toISOString().split('T')[0])
    .single();

  if (error) throw error;
  return data;
}

export async function getVisitorCount(): Promise<number> {
  const { count, error } = await supabase
    .from('visitors')
    .select('*', { count: 'exact' });

  if (error) throw error;
  return count || 0;
}