import { defineConfig, UserConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import { compression } from 'vite-plugin-compression2';
import { resolve } from 'path';
import { pwaConfig } from './vite/pwa.config';
import { serverConfig } from './vite/server.config';

const config: UserConfig = {
  plugins: [
    react({
      babel: {
        babelrc: false,
        plugins: [
          ['@babel/plugin-transform-react-jsx', { runtime: 'automatic' }]
        ]
      }
    }),
    compression({
      algorithm: 'brotliCompress',
      exclude: [/\.(br)$/, /\.(gz)$/],
      deleteOriginalAssets: false,
      threshold: 1024
    }),
    VitePWA(pwaConfig),
  ],
  build: {
    modulePreload: {
      polyfill: true
    }, 
    emptyOutDir: true,
    target: 'esnext',
    dynamicImportVarsOptions: {
      warnOnError: false
    },
    cssMinify: 'lightningcss',
    assetsDir: 'assets',
    copyPublicDir: true,
    minify: 'terser',
    terserOptions: {
      compress: {
        drop_console: true,
        drop_debugger: true,
        pure_funcs: ['console.log', 'console.info', 'console.debug'],
        passes: 3,
        ecma: 2020,
        module: true,
        toplevel: true,
        reduce_vars: true,
        reduce_funcs: true,
        pure_getters: true,
        keep_fargs: false,
        collapse_vars: true
      },
      mangle: {
        toplevel: true,
        properties: false
      },
      format: {
        comments: false,
        ascii_only: true,
        beautify: false
      }
    },
    rollupOptions: {
      treeshake: true,
      input: {
        main: resolve(__dirname, 'index.html')
      },
      output: {
        compact: true,
        preserveModules: false,
        manualChunks: {
          'react-vendor': ['react', 'react-dom'],
          'router-vendor': ['react-router-dom'],
          'motion-vendor': ['framer-motion'],
          'state-vendor': ['zustand'],
          'ui-components': [
            './src/modules/ui/components/Button',
            './src/modules/ui/components/Card',
            './src/modules/ui/components/Badge',
            './src/modules/ui/components/IconButton'
          ],
          'game-core': [
            './src/modules/game/store/gameStore',
            './src/modules/game/utils/scoring',
            './src/modules/game/utils/difficulty'
          ],
          'analytics': [
            './src/modules/analytics/AnalyticsManager',
            './src/modules/analytics/GoogleAnalytics',
            './src/modules/analytics/MicrosoftClarity'
          ]
        },
        assetFileNames: (assetInfo) => {
          const extType = assetInfo.name.split('.').at(1);
          if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
            return `assets/images/[name]-[hash][extname]`;
          } else if (/woff2?|ttf|otf|eot/i.test(extType)) {
            return `assets/fonts/[name][extname]`;
          }
          return `assets/[name]-[hash][extname]`;
        },
        chunkFileNames: 'assets/js/[name]-[hash].js',
        entryFileNames: 'assets/js/[name]-[hash].js'
      }
    },
    sourcemap: false,
    cssCodeSplit: true,
    assetsInlineLimit: 4096,
    chunkSizeWarningLimit: 500,
    reportCompressedSize: false
  },
  optimizeDeps: {
    include: [
      'react', 
      'react-dom',
      'framer-motion', 
      'zustand',
      'react-router-dom',
      'clsx',
      'tailwind-merge'
    ],
    exclude: []
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, './src')
    }
  },
  server: serverConfig
};

export default defineConfig(config);