import React from 'react';
import { Helmet } from 'react-helmet';
import { AchievementList } from '../components/AchievementList';

export default function AchievementsRoute() {
  return (
    <>
      <Helmet>
        <title>Brain Training Achievements & Rewards | Track Your Success</title>
        <meta name="description" content="Unlock achievements and earn rewards as you train your brain! Track your cognitive milestones and showcase your mental prowess." />
        <meta name="keywords" content="brain training achievements, cognitive milestones, mental exercise rewards, puzzle game badges, brain game progress" />
        <link rel="canonical" href="https://1oddout.com/achievements" />
      </Helmet>

      <AchievementList />
    </>
  );
}