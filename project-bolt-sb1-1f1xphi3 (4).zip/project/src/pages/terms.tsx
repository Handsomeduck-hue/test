import React from 'react';
import { Helmet } from 'react-helmet';
import { TermsOfService } from '../components/TermsOfService';

export default function TermsRoute() {
  return (
    <>
      <Helmet>
        <title>Terms of Service | 1 Odd Out Brain Training Platform</title>
        <meta name="description" content="Review our terms of service for using 1 Odd Out brain training games. Understand our policies for fair play and user conduct." />
        <meta name="keywords" content="brain training terms, puzzle game rules, cognitive training terms, game usage policy, brain games terms" />
        <link rel="canonical" href="https://1oddout.com/terms" />
      </Helmet>

      <TermsOfService />
    </>
  );
}