import React from 'react';
import { Helmet } from 'react-helmet';
import { UserProfile } from '../components/UserProfile';

export default function ProfileRoute() {
  return (
    <>
      <Helmet>
        <title>Your Brain Training Progress | Track Cognitive Improvement</title>
        <meta name="description" content="Track your brain training journey! View detailed progress stats, unlock achievements, and see your cognitive skill improvements over time." />
        <meta name="keywords" content="brain training progress, cognitive improvement tracking, mental skills development, brain exercise stats, achievement tracking" />
        <link rel="canonical" href="https://1oddout.com/profile" />
      </Helmet>

      <UserProfile />
    </>
  );
}