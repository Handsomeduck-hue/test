import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { Difficulty } from '../types/game';
import { 
  calculateTimeLimit,
  calculateTimeBonus,
  calculateStreakBonus,
  calculateDifficultyBonus
} from '../modules/game/utils/scoring';
import { INITIAL_STATE } from '../modules/game/utils/state';
import { getRandomCategory, getRandomSet } from '../modules/game/utils/generators';
import { checkDifficultyProgression } from '../modules/game/utils/progression';

export const useGameStore = create<{
  state: GameState;
  actions: {
    startGame: () => void;
    makeGuess: (item: string) => void;
    useHint: () => void;
    resetGame: () => void;
    updateTimer: () => void;
    addLife: () => void;
    resumeGame: () => void;
  };
}>()(
  persist(
    (set, get) => ({
      state: INITIAL_STATE,
      actions: {
        startGame: () => {
          const category = getRandomCategory();
          const gameSet = getRandomSet(category);
          set({
            state: {
              ...INITIAL_STATE,
              gameStarted: true,
              timeRemaining: calculateTimeLimit(1, Difficulty.Easy),
              currentCategory: category,
              currentSet: gameSet,
              difficulty: Difficulty.Easy
            },
          });
        },
        makeGuess: (item: string) => {
          const { state } = get();
          if (!state.currentSet || !state.currentCategory) return;

          const isCorrect = state.currentSet.oddOneOut === item;
          
          if (isCorrect) {
            const newCategory = getRandomCategory(state.difficulty);
            const newSet = getRandomSet(newCategory);
            
            const timeBonus = calculateTimeBonus(state.timeRemaining);
            const streakBonus = calculateStreakBonus(state.currentStreak);
            const difficultyBonus = calculateDifficultyBonus(state.difficulty);
            const newScore = state.score + timeBonus + streakBonus + difficultyBonus;
            const newLevel = state.currentLevel + 1;
            const newDifficulty = checkDifficultyProgression({ ...state, score: newScore });
            
            set({
              state: {
                ...state,
                score: newScore,
                currentLevel: newLevel,
                currentStreak: state.currentStreak + 1,
                bestStreak: Math.max(state.currentStreak + 1, state.bestStreak),
                timeRemaining: calculateTimeLimit(newLevel, newDifficulty),
                timeBonus,
                streakBonus,
                difficultyBonus,
                currentCategory: newCategory,
                currentSet: newSet,
                showHint: false,
                difficulty: newDifficulty,
                lastResult: {
                  correct: true,
                  bonus: streakBonus + difficultyBonus,
                  message: `Perfect! +${timeBonus} time bonus, +${streakBonus} streak bonus`
                }
              }
            });
          } else {
            const newLives = state.lives - 1;
            set({
              state: {
                ...state,
                lives: newLives,
                gameOver: newLives === 0,
                currentStreak: 0,
                showHint: false,
                lastResult: {
                  correct: false,
                  mistake: item,
                  message: newLives === 0 ? 'Game Over!' : `Wrong! ${newLives} ${newLives === 1 ? 'life' : 'lives'} remaining`
                }
              }
            });
          }
        },
        useHint: () => {
          const { state } = get();
          if (state.hintsRemaining > 0) {
            set({
              state: {
                ...state,
                hintsRemaining: state.hintsRemaining - 1,
                showHint: true,
              },
            });
          }
        },
        resetGame: () => {
          const category = getRandomCategory();
          const gameSet = getRandomSet(category);
          set({
            state: {
              ...INITIAL_STATE,
              gameStarted: true,
              timeRemaining: calculateTimeLimit(1, Difficulty.Easy),
              currentCategory: category,
              currentSet: gameSet,
            },
          });
        },
        updateTimer: () => {
          const { state } = get();
          if (state.timeRemaining > 0 && !state.gameOver && state.gameStarted) {
            const newTimeRemaining = Math.max(0, state.timeRemaining - 0.1);
            set({
              state: {
                ...state,
                timeRemaining: newTimeRemaining,
                gameOver: newTimeRemaining === 0,
              },
            });
          }
        },
        addLife: () => {
          const { state } = get();
          set({
            state: {
              ...state,
              lives: state.lives + 1,
            },
          });
        },
        resumeGame: () => {
          const { state } = get();
          set({
            state: {
              ...state,
              gameOver: false,
              timeRemaining: calculateTimeLimit(state.currentLevel, state.difficulty),
            },
          });
        },
      },
    }),
    {
      name: 'odd-one-out-game',
      partialize: (state) => ({
        highScores: state.state.highScores,
        bestStreak: state.state.bestStreak,
        totalGamesPlayed: state.state.totalGamesPlayed,
        achievements: state.state.achievements,
      }),
    }
  )
);