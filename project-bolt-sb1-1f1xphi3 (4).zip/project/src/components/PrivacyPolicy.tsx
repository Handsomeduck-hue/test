import React from 'react';
import { Card } from '../modules/ui/components/Card';
import { Shield, Lock, Eye, Database, Cookie, UserCheck } from 'lucide-react';

export function PrivacyPolicy() {
  return (
    <div className="max-w-4xl mx-auto p-4 space-y-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-4">Privacy Policy</h1>
        <p className="text-gray-600 dark:text-gray-400">Last updated: March 18, 2024</p>
      </div>

      <Card className="space-y-6">
        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Shield className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Data Protection</h2>
          </div>
          <p>
            1 Odd Out ("we", "us", or "our") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, and safeguard your information when you use our website and game services.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Eye className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Information We Collect</h2>
          </div>
          <div className="space-y-2">
            <p>We collect the following types of information:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Game progress and scores</li>
              <li>Device information (browser type, operating system)</li>
              <li>Usage statistics and analytics data</li>
              <li>Performance metrics to improve game experience</li>
            </ul>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Database className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">How We Use Your Information</h2>
          </div>
          <div className="space-y-2">
            <p>We use collected information to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Provide and improve our game services</li>
              <li>Track game progress and maintain leaderboards</li>
              <li>Analyze game performance and user experience</li>
              <li>Send important updates about the game</li>
            </ul>
          </div>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Cookie className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Cookies and Tracking</h2>
          </div>
          <p>
            We use cookies and similar tracking technologies to enhance your gaming experience and collect usage data. You can control cookie settings through your browser preferences.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <Lock className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Data Security</h2>
          </div>
          <p>
            We implement appropriate security measures to protect your information from unauthorized access, alteration, or disclosure. However, no internet transmission is completely secure.
          </p>
        </section>

        <section className="space-y-4">
          <div className="flex items-center gap-3">
            <UserCheck className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
            <h2 className="text-xl font-semibold">Your Rights</h2>
          </div>
          <div className="space-y-2">
            <p>You have the right to:</p>
            <ul className="list-disc pl-6 space-y-2">
              <li>Access your personal data</li>
              <li>Request data correction or deletion</li>
              <li>Object to data processing</li>
              <li>Request data portability</li>
            </ul>
          </div>
        </section>

        <section className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            For any privacy-related questions or concerns, please contact us at privacy@1oddout.com
          </p>
        </section>
      </Card>
    </div>
  );
}