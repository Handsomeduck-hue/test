import { Category, Difficulty } from '../types/game';

export const categories: Category[] = [
  {
    name: 'Starter',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['🚗 Car', '🐱 Cat', '🐶 Dog', '🐰 Rabbit'],
        oddOneOut: '🚗 Car',
        explanation: 'Car is not an animal, while all others are pets.',
        hint: 'Think about living things.',
      },
      {
        items: ['🌺 Flower', '🎮 Controller', '🌳 Tree', '🌿 Plant'],
        oddOneOut: '🎮 Controller',
        explanation: 'Controller is not a living thing, others are plants.',
        hint: 'Which one is man-made?',
      },
      {
        items: ['🍕 Pizza', '🍔 Burger', '📱 Phone', '🌭 Hot Dog'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not food, others are edible items.',
        hint: 'Which one can\'t you eat?',
      },
      {
        items: ['🎨 Paint', '📚 Book', '✏️ Pencil', '✒️ Pen'],
        oddOneOut: '📚 Book',
        explanation: 'Book is for reading, others are for drawing/writing.',
        hint: 'Which one do you read?',
      },
      {
        items: ['🌞 Sun', '🎭 Mask', '⭐ Star', '🌙 Moon'],
        oddOneOut: '🎭 Mask',
        explanation: 'Mask is not found in space.',
        hint: 'Which one is made by humans?',
      },
      {
        items: ['🚲 Bike', '🏃‍♂️ Runner', '🚶‍♂️ Walker', '🏊‍♂️ Swimmer'],
        oddOneOut: '🚲 Bike',
        explanation: 'Bike is not a human activity, it\'s a vehicle.',
        hint: 'Which isn\'t a person doing something?',
      },
      {
        items: ['🎵 Music', '🎨 Art', '📺 TV', '📚 Book'],
        oddOneOut: '📺 TV',
        explanation: 'TV is electronic entertainment, others are traditional arts.',
        hint: 'Which needs electricity?'
      },
      {
        items: ['🌈 Rainbow', '📱 Phone', '☁️ Cloud', '🌧️ Rain'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is man-made, others are natural phenomena.',
        hint: 'Which isn\'t made by nature?'
      },
      {
        items: ['🎭 Theater', '🎪 Circus', '🏫 School', '🎨 Museum'],
        oddOneOut: '🏫 School',
        explanation: 'School is for education, others are for entertainment.',
        hint: 'Where do you learn math?',
      },
      {
        items: ['🌞 Sun', '📱 Phone', '⭐ Star', '🌙 Moon'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is man-made, others are celestial bodies.',
        hint: 'Which isn\'t in space?',
      },
      {
        items: ['🎨 Paint', '✏️ Pencil', '🎮 Game', '✒️ Pen'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not a writing/drawing tool.',
        hint: 'Which can\'t make marks on paper?'
      }
    ]
  },
  {
    name: 'Mythology & Folklore',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['🦁 Hercules', '🕷️ Spider-Man', '⚔️ Perseus', '🛡️ Achilles'],
        oddOneOut: '🕷️ Spider-Man',
        explanation: 'Spider-Man is a modern superhero, others are mythological heroes.',
        hint: 'Who comes from ancient stories?',
      },
      {
        items: ['🏔️ Olympus', '📱 Smartphone', '🏰 Asgard', '🌳 Avalon'],
        oddOneOut: '📱 Smartphone',
        explanation: 'Smartphone is a modern device, others are mythical places.',
        hint: 'Which is from the modern world?',
      },
      {
        items: ['🦄 Unicorn', '🐎 Horse', '🦁 Griffin', '🔥 Phoenix'],
        oddOneOut: '🐎 Horse',
        explanation: 'Horse is a real animal, others are mythical creatures.',
        hint: 'Which exists in real life?',
      },
      {
        items: ['🏰 Camelot', '🏬 Shopping Mall', '🌟 El Dorado', '🌊 Atlantis'],
        oddOneOut: '🏬 Shopping Mall',
        explanation: 'Shopping Mall is a modern structure, others are legendary places.',
        hint: 'Which is not from ancient tales?',
      },
      {
        items: ['🐍 Medusa', '🧛 Vampire', '🐮 Minotaur', '👁️ Cyclops'],
        oddOneOut: '🧛 Vampire',
        explanation: 'Vampire is folklore, others are from Greek mythology.',
        hint: 'Which isn\'t from ancient Greece?',
      },
      {
        items: ['Dragon Scale', 'Smartphone', 'Phoenix Feather', 'Unicorn Horn'],
        oddOneOut: 'Smartphone',
        explanation: 'Smartphone is modern technology, others are mythical items.',
        hint: 'Which exists today?'
      },
      {
        items: ['Zeus', 'Thor', 'Superman', 'Odin'],
        oddOneOut: 'Superman',
        explanation: 'Superman is a comic book hero, others are mythological gods.',
        hint: 'Who was created in the 20th century?'
      },
      {
        items: ['Pegasus', 'Dragon', 'Bicycle', 'Griffin'],
        oddOneOut: 'Bicycle',
        explanation: 'Bicycle is a real vehicle, others are mythical creatures.',
        hint: 'Which can you buy in a store?',
      },
      {
        items: ['Excalibur', 'Pencil', 'Mjolnir', 'Gae Bolg'],
        oddOneOut: 'Pencil',
        explanation: 'Pencil is a common tool, others are legendary weapons.',
        hint: 'Which isn\'t magical?',
      },
      {
        items: ['Mermaid', 'Centaur', 'Tourist', 'Minotaur'],
        oddOneOut: 'Tourist',
        explanation: 'Tourist is a regular person, others are mythical hybrids.',
        hint: 'Which is fully human?'
      }
    ]
  },
  {
    name: 'Science & Innovation',
    difficulty: Difficulty.Hard,
    sets: [
      {
        items: ['💻 Laptop', '🔬 Microscope', '🔭 Telescope', '🌡️ Thermometer'],
        oddOneOut: '💻 Laptop',
        explanation: 'Laptop is not a scientific measurement tool.',
        hint: 'Which doesn\'t measure natural phenomena?',
      },
      {
        items: ['🔴 Mars', '⭐ Venus', '🌍 Earth', '🌈 Rainbow'],
        oddOneOut: '🌈 Rainbow',
        explanation: 'Rainbow is an atmospheric phenomenon, not a planet.',
        hint: 'Which is not a celestial body?',
      },
      {
        items: ['⚛️ Atom', '🔮 Molecule', '💎 Crystal', '🛹 Skateboard'],
        oddOneOut: '🛹 Skateboard',
        explanation: 'Skateboard is not a scientific structure.',
        hint: 'Which isn\'t studied in science class?',
      },
      {
        items: ['🧪 Beaker', '🧫 Test Tube', '☕ Coffee Cup', '🧪 Flask'],
        oddOneOut: '☕ Coffee Cup',
        explanation: 'Coffee Cup is not laboratory equipment.',
        hint: 'Which isn\'t used in a lab?',
      },
      {
        items: ['🧬 DNA', '🎮 Game Console', '🧬 RNA', '🧫 Protein'],
        oddOneOut: '🎮 Game Console',
        explanation: 'Game Console is not a biological molecule.',
        hint: 'Which isn\'t found in cells?',
      },
      {
        items: ['Newton', 'Einstein', 'Shakespeare', 'Darwin'],
        oddOneOut: 'Shakespeare',
        explanation: 'Shakespeare was not a scientist.',
        hint: 'Who didn\'t study nature?'
      },
      {
        items: ['Laboratory', 'Telescope', 'Playground', 'Observatory'],
        oddOneOut: 'Playground',
        explanation: 'Playground is for recreation, others are for scientific research.',
        hint: 'Where do kids play?'
      },
      {
        items: ['Gravity', 'Energy', 'Basketball', 'Magnetism'],
        oddOneOut: 'Basketball',
        explanation: 'Basketball is a game, others are physics concepts.',
        hint: 'Which is a sport?',
      },
      {
        items: ['🧬 DNA', '📱 Phone', '🦠 Virus', '🔬 Bacteria'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not a biological entity.',
        hint: 'Which isn\'t studied in biology?',
      },
      {
        items: ['⚗️ Chemical', '🎮 Game', '🧪 Molecule', '⚛️ Atom'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not related to chemistry.',
        hint: 'Which isn\'t found in a lab?'
      }
    ]
  },
  // Rest of the file remains unchanged
];

export const difficultyProgression = {
  scoreThresholds: {
    [Difficulty.Easy]: 0,
    [Difficulty.Medium]: 500,
    [Difficulty.Hard]: 1500,
    [Difficulty.Expert]: 3000
  },
  timeMultipliers: {
    [Difficulty.Easy]: 1.2,
    [Difficulty.Medium]: 1,
    [Difficulty.Hard]: 0.8,
    [Difficulty.Expert]: 0.6
  },
  bonusMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 1.3,
    [Difficulty.Hard]: 1.6,
    [Difficulty.Expert]: 2
  }
};