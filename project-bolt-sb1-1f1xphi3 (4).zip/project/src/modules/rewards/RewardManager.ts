import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type RewardState = {
  availableRewards: number;
  lastRewardTime: number | null;
};

type RewardStore = {
  state: RewardState;
  actions: {
    addReward: () => void;
    useReward: () => boolean;
    canEarnReward: () => boolean;
  };
};

const REWARD_COOLDOWN = 5 * 60 * 1000; // 5 minutes

export const useRewardStore = create<RewardStore>()(
  persist(
    (set, get) => ({
      state: {
        availableRewards: 0,
        lastRewardTime: null,
      },
      actions: {
        addReward: () => {
          set((state) => ({
            state: {
              ...state.state,
              availableRewards: state.state.availableRewards + 1,
              lastRewardTime: Date.now(),
            },
          }));
        },
        useReward: () => {
          const { state } = get();
          if (state.availableRewards > 0) {
            set((state) => ({
              state: {
                ...state.state,
                availableRewards: state.state.availableRewards - 1,
              },
            }));
            return true;
          }
          return false;
        },
        canEarnReward: () => {
          const { state } = get();
          if (!state.lastRewardTime) return true;
          return Date.now() - state.lastRewardTime >= REWARD_COOLDOWN;
        },
      },
    }),
    {
      name: 'game-rewards',
      partialize: (state) => ({
        state: {
          availableRewards: state.state.availableRewards,
          lastRewardTime: state.state.lastRewardTime,
        },
      }),
    }
  )
);