export interface AdSize {
  width: number;
  height: number;
}

export interface AdConfig {
  adUnit: string;
  adSize: AdSize;
  targeting: Record<string, string>;
  testMode: boolean;
  timeout: number;
  retryAttempts: number;
  retryDelay: number;
}

export interface AdResources {
  container?: HTMLElement;
  videoElement?: HTMLVideoElement;
  adDisplayContainer?: any;
  adsLoader?: any;
  adsManager?: any;
  visibilityHandler?: (e: Event) => void;
}

export interface AdResult {
  success: boolean;
  error?: string;
  revenue?: number;
}