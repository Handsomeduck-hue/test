import { create } from 'zustand';
import { trackAdInteraction } from '../analytics/AnalyticsManager';
import { adConfig } from './config/adConfig';
import { buildAdTagUrl } from './utils/adTagBuilder';
import { COOLDOWN_PERIOD, ADMOB_APP_ID, REWARDED_AD_UNIT_ID, VIDEO_AD_CLIENT, ADSENSE_CLIENT_ID } from './constants';
import { handleAdError } from './utils';
import { validateAdRequirements } from './utils/validation';
import { cleanupAdResources } from './utils/cleanup';
import { retryWithBackoff } from './utils/retry';
import { preloadAd } from './utils/preload';
import { validateNetworkForAds } from './utils/network';
import { createAdContainer } from './utils/adContainer';
import { checkAdEnvironment } from './utils/debug';
import { logAdEvent, logAdError } from './utils/logging';
import type { AdStore, AdState, AdResources, AdResult } from './types';

const loadIMAScript = async (): Promise<void> => {
  if (window.google?.ima) return;
  
  logAdEvent('Loading IMA SDK');
  const scriptPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error('Failed to load IMA SDK'));
    document.head.appendChild(script);
  });

  // Add timeout to script loading
  const timeoutPromise = new Promise((_, reject) => {
    setTimeout(() => reject(new Error('IMA SDK load timeout')), 10000);
  });

  return Promise.race([scriptPromise, timeoutPromise]);
};
const loadAdSenseScript = async (): Promise<void> => {
  if (document.querySelector('script[src*="pagead2.googlesyndication.com"]')) {
    logAdEvent('AdSense script already loaded');
    return;
  }

  logAdEvent('Loading AdSense script');
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT_ID}`;
    script.crossOrigin = 'anonymous';
    script.onload = () => {
      logAdEvent('AdSense script loaded successfully');
      resolve();
    };
    script.onerror = (e) => {
      logAdError(e, 'Error loading AdSense script');
      reject(new Error('Failed to load AdSense script'));
    };
    document.head.appendChild(script);
  });
};

const initialState: AdState = {
  isLoading: false,
  isRewarded: false,
  lastRewardTime: null,
  error: null,
  adUnit: null,
  revenue: 0, 
  impressions: 0,
  isPreloading: false,
  preloadedAd: null
};

export const useAdStore = create<AdStore>((set, get) => ({
  state: initialState,
  actions: {
    initializeAds: async () => {
      try {
        logAdEvent('Initializing ads');
        
        // Load both IMA SDK and AdSense
        await Promise.all([
          loadIMAScript(),
          loadAdSenseScript()
        ]);
        
        // Validate network conditions first
        const networkValidation = await validateNetworkForAds();
        if (!networkValidation.isValid) {
          const error = new Error(networkValidation.errors.join(', '));
          error.name = 'NetworkError';
          throw error;
        }
        
        // Check if IMA SDK is available first
        await loadIMAScript();

        const envChecks = checkAdEnvironment();
        if (!envChecks.imaSDK || !envChecks.autoplay) {
          throw new Error('Required ad capabilities not available');
        }

        const { isValid, errors } = validateAdRequirements();
        set({ state: { ...get().state, isPreloading: true, error: null } });

        // Wait for IMA SDK to be ready
        await new Promise<void>(resolve => {
          if (window.google?.ima) {
            resolve();
          } else {
            const checkInterval = setInterval(() => {
              if (window.google?.ima) {
                clearInterval(checkInterval);
                resolve();
              }
            }, 100);
          }
        });

        if (!isValid) {
          throw new Error(errors.join(', '));
        }

        // Attempt to preload ad
        const preloadedAd = await retryWithBackoff(
          async () => {
            try {
              const ad = await preloadAd();
              return ad;
            } catch (error) {
              throw error;
            }
          }
        );

        window.gtag('config', ADMOB_APP_ID, {
          ads_enabled: true,
          allow_ad_personalization_signals: false
        });

        window.gtag('event', 'ad_request', {
          ad_unit_id: REWARDED_AD_UNIT_ID,
          ad_type: 'rewarded'
        });

        trackAdInteraction('rewarded', 'init');

        set({ state: {
          ...initialState,
          adUnit: REWARDED_AD_UNIT_ID,
          preloadedAd: preloadedAd,
          isPreloading: false
        }});
      } catch (error) {
        set({ state: {
          ...initialState,
          error: handleAdError(error),
          isPreloading: false
        }});
        trackAdInteraction('rewarded', 'init_error');
      }
    },

    showRewardedAd: async () => {
      const { state } = get();
      
      // Check if already loading
      if (state.isLoading) {
        logAdEvent('Ad request rejected - already loading');
        return false;
      }

      // Validate requirements first
      const { isValid, errors } = validateAdRequirements();
      if (!isValid) {
        logAdEvent('Ad requirements validation failed', { errors });
        set({ state: { ...state, error: errors.join(', ') } });
        return {
          success: false,
          error: errors.join(', ')
        };
      }

      // Check cooldown period
      if (state.lastRewardTime && Date.now() - state.lastRewardTime < COOLDOWN_PERIOD) {
        const remainingTime = Math.ceil((COOLDOWN_PERIOD - (Date.now() - state.lastRewardTime)) / 1000);
        logAdEvent('Ad request rejected - cooldown period', { remainingTime });
        set({ state: { ...state, error: `Please wait ${remainingTime} seconds` } });
        return {
          success: false,
          error: `Please wait ${remainingTime} seconds`
        };
      }

      // Start loading ad
      set({ state: { ...state, isLoading: true, error: null } });
      let adResources: AdResources = {};

      try {
        // Check network conditions
        const networkValidation = await validateNetworkForAds();
        if (!networkValidation.isValid) {
          throw new Error(networkValidation.errors.join(', '));
        }
        // Use preloaded ad if available
        if (state.preloadedAd) {
          try {
            const result = await state.preloadedAd.start();
            if (result) {
              set({
                state: {
                  ...state,
                  isLoading: false,
                  lastRewardTime: Date.now(),
                  preloadedAd: null
                }
              });
              return {
                success: true,
                revenue: 0.01 // Example revenue for test ads
              };
            }
          } catch (error) {
            logAdError(error, 'Preloaded ad start error');
            throw error;
          }
        }

        return await new Promise<AdResult>((resolve, reject) => {
          const timeoutId = setTimeout(() => {
            logAdError(new Error('Ad load timeout'), 'Ad request timed out');
            reject(new Error('Ad load timeout'));
          }, adConfig.timeout);

          try {
            // Create container and video element
            const adContainer = createAdContainer('ad-container', adConfig.adSize);
            const videoElement = document.createElement('video');
            Object.assign(videoElement.style, {
              width: '100%',
              height: '100%',
              maxWidth: '640px',
              maxHeight: '480px',
              position: 'absolute',
              top: '0',
              left: '0',
              backgroundColor: '#000'
            });
            videoElement.muted = true;
            videoElement.playsInline = true;
            videoElement.setAttribute('playsinline', '');
            videoElement.setAttribute('webkit-playsinline', '');
            videoElement.setAttribute('x-webkit-airplay', 'deny');
            videoElement.setAttribute('disablePictureInPicture', '');
            videoElement.setAttribute('controlsList', 'nodownload nofullscreen noremoteplayback');
            
            adContainer.appendChild(videoElement);
            document.body.appendChild(adContainer);
            
            adResources.container = adContainer;
            adResources.videoElement = videoElement;

            // Set up ad display container with video element
            const adDisplayContainer = new google.ima.AdDisplayContainer(
              adContainer,
              videoElement
            );
            
            // Initialize container
            try {
              // Must initialize before loading ads
              adDisplayContainer.initialize();
            } catch (error) {
              logAdError(error, 'Failed to initialize ad container');
              return resolve({
                success: false,
                error: 'Failed to initialize ad container'
              });
            }
            
            adResources.adDisplayContainer = adDisplayContainer;

            // Calculate dimensions while maintaining aspect ratio
            const maxWidth = Math.min(window.innerWidth - 32, 640);
            const width = maxWidth;
            const height = Math.round(width * (9/16)); // Maintain 16:9 aspect ratio

            adContainer.style.width = `${width}px`;
            adContainer.style.height = `${height}px`;

            // Add visibility change handler
            const handleVisibilityChange = () => {
              if (document.hidden) {
                if (adResources.adsManager) {
                  logAdEvent('Tab hidden - pausing ad');
                  try {
                    adResources.adsManager.pause();
                  } catch (e) {
                    logAdError(e, 'Error pausing ad on visibility change');
                  }
                }
              } else {
                if (adResources.adsManager) {
                  logAdEvent('Tab visible - resuming ad');
                  try {
                    adResources.adsManager.resume();
                  } catch (e) {
                    logAdError(e, 'Error resuming ad on visibility change');
                  }
                }
              }
            };
            
            document.addEventListener('visibilitychange', handleVisibilityChange);
            adResources.visibilityHandler = handleVisibilityChange;
            
            // Force focus on ad container
            adContainer.focus();
            
            // Request user attention if supported
            if ('userActivation' in navigator) {
              logAdEvent('Requesting user attention');
            }
            // Configure ad request
            const adsRequest = new google.ima.AdsRequest();
            // Set exact dimensions from config
            adsRequest.linearAdSlotWidth = adConfig.adSize.width;
            adsRequest.linearAdSlotHeight = adConfig.adSize.height;
            adsRequest.nonLinearAdSlotWidth = adConfig.adSize.width;
            adsRequest.nonLinearAdSlotHeight = adConfig.adSize.height;
            adsRequest.adTagUrl = buildAdTagUrl(adConfig);
            if (adsRequest.setAdWillAutoPlay) {
              adsRequest.setAdWillAutoPlay(true);
            }
            if (adsRequest.setAdWillPlayMuted) {
              adsRequest.setAdWillPlayMuted(false); // Allow sound since user initiated
            }
            adsRequest.forceNonLinearFullSlot = true;
            
            // Log ad request configuration
            logAdEvent('Ad request configuration', {
              width,
              height,
              adTagUrl: adsRequest.adTagUrl,
              autoplay: adsRequest.setAdWillAutoPlay ? true : 'unsupported',
              muted: adsRequest.setAdWillPlayMuted ? false : 'unsupported'
            });

            const adsLoader = new google.ima.AdsLoader(adDisplayContainer);
            adResources.adsLoader = adsLoader;

            adsLoader.addEventListener(
              google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
              (event) => {
                clearTimeout(timeoutId);
                logAdEvent('Ads manager loaded');
                
                const adsManager = event.getAdsManager(videoElement);
                adResources.adsManager = adsManager;

                try {
                  adsManager.init(width, height, google.ima.ViewMode.NORMAL);

                  // Add error event listener
                  adsManager.addEventListener(
                    google.ima.AdErrorEvent.Type.AD_ERROR,
                    (error) => {
                      logAdError(error, 'Ad playback error');
                      cleanupAdResources(adResources);
                      reject(error);
                    }
                  );

                  // Add additional event listeners for debugging
                  adsManager.addEventListener(
                    google.ima.AdEvent.Type.LOADED,
                    () => logAdEvent('Ad loaded')
                  );

                  adsManager.addEventListener(
                    google.ima.AdEvent.Type.STARTED,
                    () => {
                      logAdEvent('Ad started');
                      // Unmute once ad starts playing
                      if (videoElement) {
                        videoElement.muted = false;
                      }
                    }
                  );

                  adsManager.addEventListener(
                    google.ima.AdEvent.Type.FIRST_QUARTILE,
                    () => logAdEvent('Ad first quartile')
                  );

                  adsManager.addEventListener(
                    google.ima.AdEvent.Type.MIDPOINT,
                    () => logAdEvent('Ad midpoint')
                  );

                  adsManager.addEventListener(
                    google.ima.AdEvent.Type.THIRD_QUARTILE,
                    () => logAdEvent('Ad third quartile')
                  );
                  adsManager.addEventListener(google.ima.AdEvent.Type.COMPLETE, () => {
                    logAdEvent('Ad completed');
                    cleanupAdResources(adResources);
                    set({
                      state: {
                        ...state,
                        isLoading: false,
                        lastRewardTime: Date.now(),
                        preloadedAd: null
                      }
                    });
                    resolve({
                      success: true,
                      revenue: 0.01 // Example revenue for test ads
                    });
                  });

                  adsManager.addEventListener(google.ima.AdEvent.Type.STARTED, () => {
                    logAdEvent('Ad started');
                    set({ state: { ...state, isLoading: false } });
                  });

                  adsManager.addEventListener(google.ima.AdEvent.Type.ALL_ADS_COMPLETED, () => {
                    logAdEvent('All ads completed');
                    cleanupAdResources(adResources);
                    resolve({
                      success: true,
                      revenue: 0.01 // Example revenue for test ads
                    });
                  });

                  adsManager.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, (error) => {
                    logAdError(error, 'Ad manager error');
                    cleanupAdResources(adResources);
                    reject(new Error(error.getError().getMessage()));
                  });
                  
                  logAdEvent('Starting ad playback');
                  adsManager.start();
                } catch (error) {
                  logAdError(error, 'Ad manager initialization/start error');
                  cleanupAdResources(adResources);
                  reject(error);
                }
              }
            );

            adsLoader.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, (error) => {
              clearTimeout(timeoutId);
              logAdError(error, 'Ad loader error');
              cleanupAdResources(adResources);
              reject(error);
            });

            // Log ad request details after configuration
            logAdEvent('Ad request configuration', {
              width: width,
              height: height,
              linearSlotSize: `${width}x${height}`,
              adTagUrl: adsRequest.adTagUrl
            });

            logAdEvent('Requesting ad with URL', adsRequest.adTagUrl);
            
            adsLoader.requestAds(adsRequest);
          } catch (error) {
            cleanupAdResources(adResources);
            reject(error);
          }
        });
      } catch (error) {
        cleanupAdResources(adResources);
        set({ state: { ...state, isLoading: false, error: error.message } });
        return {
          success: false,
          error: error.message
        };
      }
    },

    resetError: () => {
      const { state } = get();
      set({ state: { ...state, error: null } });
    }
  },
}));