import { AdConfig } from '../types';
import { VIDEO_AD_CLIENT, REWARDED_AD_UNIT_ID } from '../constants';

export function buildAdTagUrl(config: AdConfig): string {
  const baseParams = new URLSearchParams({
    client: VIDEO_AD_CLIENT,
    iu: REWARDED_AD_UNIT_ID,
    sz: '640x480',
    ad_type: 'video_reward',
    format: 'vast',
    env: 'vp',
    impl: 's',
    unviewed_position_start: '1',
    description_url: encodeURIComponent(window.location.href),
    url: encodeURIComponent(window.location.href),
    correlator: Date.now().toString(),
    nofb: '1',
    videoad_start_delay: '0',
    vpmute: '0',
    vpa: '1',
    gdfp_req: '1',
    output: 'vast'
  });

  // Add custom targeting parameters
  const custParams = new URLSearchParams();
  Object.entries(config.targeting).forEach(([key, value]) => {
    custParams.append(key, value);
  });
  baseParams.append('cust_params', encodeURIComponent(custParams.toString()));

  // Add test mode parameter if enabled
  if (config.testMode) {
    baseParams.append('adtest', 'on');
  }

  return `https://pubads.g.doubleclick.net/gampad/ads?${baseParams.toString()}`;
}