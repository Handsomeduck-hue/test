import { AD_RETRY_ATTEMPTS, AD_RETRY_DELAY, AD_ERROR_MESSAGES, AD_TIMEOUT } from '../constants';
import { logAdEvent } from './logging';

type RetryOperation<T> = () => Promise<T>;

export const retryWithBackoff = async <T>(
  operation: RetryOperation<T>,
  maxAttempts = AD_RETRY_ATTEMPTS,
  baseDelay = AD_RETRY_DELAY
): Promise<T> => {
  let lastError: Error | undefined;
  const maxDelay = baseDelay * Math.pow(2, maxAttempts - 1);
  let attempt = 0;

  for (; attempt < maxAttempts; attempt++) {
    try {
      logAdEvent('Retry attempt', {
        attempt: attempt + 1,
        maxAttempts,
        baseDelay
      });

      const result = await Promise.race([
        operation(),
        new Promise<never>((_, reject) => {
          setTimeout(() => {
            reject(new Error('Operation timed out'));
          }, AD_TIMEOUT);
        })
      ]);

      return result;
    } catch (error) {
      lastError = error as Error;
      logAdEvent('Operation failed', {
        attempt: attempt + 1,
        error: error.message,
        remaining: maxAttempts - (attempt + 1)
      });

      if (attempt < maxAttempts - 1) {
        const delay = Math.min(
          baseDelay * Math.pow(2, attempt) + Math.random() * 1000,
          maxDelay
        );
        logAdEvent('Scheduling retry', {
          nextAttempt: attempt + 2,
          delayMs: delay,
          delaySeconds: Math.round(delay/1000)
        });

        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }

  logAdEvent('All retry attempts exhausted', {
    attempts: maxAttempts,
    maxAttempts,
    finalError: lastError?.message
  });

  const finalError = new Error(
    lastError?.message || AD_ERROR_MESSAGES.GENERIC
  );
  finalError.name = 'AdRetryError';
  finalError.cause = lastError;
  throw finalError;
};