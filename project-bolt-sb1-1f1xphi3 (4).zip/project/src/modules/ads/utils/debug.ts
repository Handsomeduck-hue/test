// Import from logging module
import { logAdEvent } from './logging';

export function checkAdEnvironment() {
  const checks = {
    imaSDK: !!window.google?.ima,
    autoplay: document.createElement('video').canPlayType !== undefined,
    localStorage: (() => {
      try {
        localStorage.setItem('test', 'test');
        localStorage.removeItem('test');
        return true;
      } catch {
        return false;
      }
    })(),
    adBlocker: !window.google?.ima && !document.querySelector('script[src*="imasdk.googleapis.com"]'),
    networkOnline: navigator.onLine,
    secureContext: window.isSecureContext,
    permissions: {
      autoplay: document.createElement('video').autoplay !== undefined,
      fullscreen: document.fullscreenEnabled,
      mediaSession: 'mediaSession' in navigator
    }
  };

  logAdEvent('Environment Check', checks);
  return checks;
}

// Export logging functions to avoid circular dependencies
export { logAdEvent, logAdError } from './logging';