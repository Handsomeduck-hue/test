import { logAdEvent } from './logging';

export function checkAutoplaySupport() {
  const video = document.createElement('video');
  const details = {
    autoplay: 'autoplay' in video,
    playsInline: 'playsInline' in video,
    muted: 'muted' in video
  };

  logAdEvent('Autoplay support check', details);

  return {
    supported: details.autoplay && details.playsInline,
    details
  };
}