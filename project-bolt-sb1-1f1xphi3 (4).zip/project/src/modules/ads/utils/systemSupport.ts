import { logAdEvent } from './logging';

export function checkSystemResources() {
  const errors: string[] = [];
  const details = {
    memory: performance?.memory ? {
      total: performance.memory.jsHeapSizeLimit,
      used: performance.memory.usedJSHeapSize,
      available: performance.memory.jsHeapSizeLimit - performance.memory.usedJSHeapSize
    } : null
  };

  logAdEvent('System resources check', details);

  if (details.memory && details.memory.available < 50 * 1024 * 1024) {
    errors.push('Low memory detected. Please close other apps and try again.');
  }

  return {
    isValid: errors.length === 0,
    errors,
    details
  };
}