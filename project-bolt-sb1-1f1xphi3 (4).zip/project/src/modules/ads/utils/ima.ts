import { logAdEvent, logAdError } from './logging';

export async function initializeIMA(): Promise<void> {
  if (window.google?.ima) {
    logAdEvent('IMA SDK already loaded');
    return;
  }

  logAdEvent('Loading IMA SDK');
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';
    script.async = true;
    script.onload = () => {
      logAdEvent('IMA SDK loaded successfully');
      resolve();
    };
    script.onerror = (error) => {
      logAdError(error, 'Failed to load IMA SDK');
      reject(new Error('Failed to load IMA SDK'));
    };
    document.head.appendChild(script);
  });
}

export function configureIMASettings(): void {
  if (!window.google?.ima) return;

  try {
    // Configure IMA SDK settings
    window.google.ima.settings.setVpaidMode(google.ima.ImaSdkSettings.VpaidMode.ENABLED);
    window.google.ima.settings.setLocale('en_US');
    window.google.ima.settings.setDisableCustomPlaybackForIOS10Plus(true);

    logAdEvent('IMA settings configured');
  } catch (error) {
    logAdError(error, 'Error configuring IMA settings');
  }
}