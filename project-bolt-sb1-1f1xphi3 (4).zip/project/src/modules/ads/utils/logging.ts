// Centralized logging module for ads
const DEBUG = process.env.NODE_ENV !== 'production';

type AdEventData = {
  timestamp: number;
  eventName: string;
  data?: any;
  browserInfo?: {
    userAgent: string;
    platform: string;
    vendor: string;
  };
  networkInfo?: {
    online: boolean;
    connection?: string;
    downlink?: number;
  };
};

const adEvents: AdEventData[] = [];

export function logAdEvent(event: string, data?: any) {
  const eventData = {
    timestamp: Date.now(),
    eventName: event,
    data,
    browserInfo: {
      userAgent: navigator.userAgent,
      platform: navigator.platform,
      vendor: navigator.vendor
    },
    networkInfo: {
      online: navigator.onLine,
      connection: (navigator as any).connection?.effectiveType,
      downlink: (navigator as any).connection?.downlink
    },
    documentVisible: !document.hidden,
    documentState: document.visibilityState,
    imaSDK: !!window.google?.ima,
    networkOnline: navigator.onLine,
    url: window.location.href
  };
  
  adEvents.push(eventData);

  if (DEBUG) {
    console.debug(
      `[Ad Event ${new Date().toISOString()}] ${event}`,
      JSON.stringify(eventData, null, 2)
    );
  }
}

export function logAdError(error: any, context: string) {
  const errorData = {
    message: error?.message || error,
    name: error?.name,
    stack: error?.stack,
    networkInfo: {
      online: navigator.onLine,
      connection: (navigator as any).connection?.effectiveType,
      downlink: (navigator as any).connection?.downlink
    },
    imaError: error?.getError?.() ? {
      message: error.getError().getMessage(),
      type: error.getError().getType(),
      code: error.getError().getErrorCode(),
      vastErrorCode: error.getError().getVastErrorCode()
    } : null,
    context,
    timestamp: Date.now()
  };

  if (DEBUG) {
    console.error(
      `[Ad Error ${new Date().toISOString()}] ${context}:`,
      JSON.stringify(errorData, null, 2)
    );
  }

  adEvents.push({
    timestamp: Date.now(),
    eventName: 'ERROR',
    data: errorData
  });
}

export function getAdEventLog(): AdEventData[] {
  return [...adEvents];
}

export function clearAdEventLog(): void {
  adEvents.length = 0;
}