import { logAdError } from './logging';

export function cleanupAdContainer(containerId: string): void {
  const container = document.getElementById(containerId);
  if (container) {
    container.remove();
  }
}

export function cleanupAdResources(resources: {
  container?: HTMLElement;
  adDisplayContainer?: any;
  adsLoader?: any;
  adsManager?: any;
  videoElement?: HTMLVideoElement;
  visibilityHandler?: (e: Event) => void;
}): void {
  try {
    // Remove visibility change listener first
    if (resources.visibilityHandler) {
      document.removeEventListener('visibilitychange', resources.visibilityHandler);
    }

    // Clean up video element
    if (resources.videoElement) {
      try {
        resources.videoElement.pause();
        resources.videoElement.remove();
      } catch (e) {
        logAdError(e, 'Error cleaning up video element');
      }
    }

    if (resources.adsManager) {
      try {
        resources.adsManager.destroy();
      } catch (e) {
        logAdError(e, 'Error destroying ads manager');
      }
    }

    if (resources.adsLoader) {
      try {
        resources.adsLoader.destroy();
      } catch (e) {
        logAdError(e, 'Error destroying ads loader');
      }
    }

    if (resources.adDisplayContainer) {
      try {
        resources.adDisplayContainer.destroy();
      } catch (e) {
        logAdError(e, 'Error destroying display container');
      }
    }

    if (resources.container?.parentElement) {
      try {
        resources.container.parentElement.removeChild(resources.container);
      } catch (e) {
        logAdError(e, 'Error removing container');
      }
    }
  } catch (error) {
    logAdError(error, 'Ad cleanup error');
  }
}