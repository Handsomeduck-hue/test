import { AD_ERROR_MESSAGES } from '../constants';
import { logAdEvent, logAdError } from './logging';
import { checkAutoplaySupport } from './autoplaySupport';
import { checkNetworkConditions } from './networkSupport';
import { checkSystemResources } from './systemSupport';

export function validateAdRequirements(): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Check secure context
  if (!window.isSecureContext) {
    logAdError(new Error('Not secure context'), 'Ad validation failed - Insecure context');
    errors.push(AD_ERROR_MESSAGES.SECURE_CONTEXT);
    return { isValid: false, errors };
  }

  // Check IMA SDK
  const hasImaSDK = !!(window.google?.ima);
  if (!hasImaSDK) {
    logAdError(new Error('IMA SDK missing'), 'Ad validation failed - No IMA SDK');
    errors.push(AD_ERROR_MESSAGES.INIT);
    return { isValid: false, errors };
  }

  // Log IMA SDK status
  logAdEvent('IMA SDK check', {
    available: hasImaSDK,
    imaVersion: window.google?.ima?.Version,
    imaSettings: window.google?.ima?.settings
  });

  // Check autoplay support
  const autoplaySupport = checkAutoplaySupport();
  if (!autoplaySupport.supported) {
    logAdError(new Error('No autoplay support'), 'Ad validation failed - Autoplay not supported');
    errors.push(AD_ERROR_MESSAGES.UNSUPPORTED);
    return { isValid: false, errors };
  }

  // Check network conditions
  const networkStatus = checkNetworkConditions();
  if (!networkStatus.isValid) {
    errors.push(...networkStatus.errors);
    return { isValid: false, errors };
  }

  // Check system resources
  const systemStatus = checkSystemResources();
  if (!systemStatus.isValid) {
    errors.push(...systemStatus.errors);
    return { isValid: false, errors };
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}