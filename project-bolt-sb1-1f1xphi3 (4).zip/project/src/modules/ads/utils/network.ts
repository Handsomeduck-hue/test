import { AD_ERROR_MESSAGES } from '../constants';
import { TEST_AD_TAG_URL, VIDEO_AD_CLIENT, REWARDED_AD_UNIT_ID } from '../constants';
import { logAdEvent, logAdError } from './logging';

export const getNetworkInfo = () => {
  return {
    online: navigator.onLine,
    connectionType: (navigator as any).connection?.type,
    effectiveType: (navigator as any).connection?.effectiveType,
    downlink: (navigator as any).connection?.downlink,
    rtt: (navigator as any).connection?.rtt
  };
};

export const checkNetworkConnectivity = async (): Promise<boolean> => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);
    
    try {
      const response = await fetch('https://www.google.com/generate_204', {
        mode: 'no-cors',
        cache: 'no-cache',
        credentials: 'omit',
        signal: controller.signal
      });
      return response.type === 'opaque';
    } finally {
      clearTimeout(timeoutId);
    }
  } catch (error) {
    logAdError(error, 'Network connectivity check failed');
    return false;
  }
};

export const checkAdServerConnectivity = async (): Promise<boolean> => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 5000);

    try {
      const testUrl = TEST_AD_TAG_URL;
      const response = await fetch(testUrl, {
        mode: 'no-cors',
        cache: 'no-cache',
        credentials: 'omit',
        signal: controller.signal,
        headers: {
          'Content-Type': 'application/javascript'
        }
      });

      const isConnected = response.type === 'opaque';
      logAdEvent('Ad server connectivity check', {
        success: isConnected,
        url: testUrl,
        responseType: response.type
      });

      return isConnected;
    } finally {
      clearTimeout(timeoutId);
    }
  } catch (error) {
    logAdError(error, 'Ad server connectivity check failed');
    return false;
  }
};

export const validateNetworkForAds = async (): Promise<{ isValid: boolean; errors: string[] }> => {
  const errors: string[] = [];
  const networkInfo = getNetworkInfo();
  
  logAdEvent('Starting network validation', {
    ...networkInfo,
    userAgent: navigator.userAgent,
    https: window.location.protocol === 'https:',
    host: window.location.hostname,
    timestamp: Date.now()
  });

  if (!networkInfo.online) {
    errors.push(AD_ERROR_MESSAGES.OFFLINE);
    logAdError(new Error('Device is offline'), 'Network validation failed - Offline status');
    return { isValid: false, errors };
  }
  
  try {
    const hasAdServerAccess = await checkAdServerConnectivity();

    logAdEvent('Ad server connectivity check complete', {
      hasAccess: hasAdServerAccess,
      networkInfo: getNetworkInfo(),
      timestamp: Date.now()
    });

    if (!hasAdServerAccess) {
      errors.push(AD_ERROR_MESSAGES.AD_SERVER);
      logAdError(new Error('Cannot reach ad server'), 'Network validation failed - No ad server access');
      return { isValid: false, errors };
    }
  } catch (error) {
    logAdError(error, 'Ad server connectivity check failed');
    errors.push(AD_ERROR_MESSAGES.AD_SERVER);
    return { isValid: false, errors };
  }

  const slowConnection = networkInfo.effectiveType === 'slow-2g' || 
                        networkInfo.effectiveType === '2g' ||
                        (networkInfo.downlink && networkInfo.downlink < 1.5);

  if (slowConnection) {
    errors.push(AD_ERROR_MESSAGES.SLOW_NETWORK);
    logAdError(
      new Error(`Slow network detected: ${networkInfo.effectiveType}, downlink: ${networkInfo.downlink}Mbps`),
      'Network validation failed - Insufficient bandwidth'
    );
    return { isValid: false, errors };
  }
  
  logAdEvent('Network validation successful', {
    effectiveType: networkInfo.effectiveType,
    downlink: networkInfo.downlink,
    rtt: networkInfo.rtt,
    timestamp: Date.now()
  });

  return { isValid: true, errors: [] };
};