import { AD_CONTAINER_STYLES } from '../constants';
import { createVideoElement } from './video';
import { logAdEvent } from './logging';

export function createAdContainer(id: string): HTMLDivElement {
  // Create outer container
  const container = document.createElement('div');
  container.id = id;
  
  // Apply container styles
  Object.assign(container.style, {
    position: 'fixed',
    zIndex: '9999',
    top: '0',
    left: '0',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.95)',
    padding: '0',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden'
  });

  // Create inner container for video
  const videoContainer = document.createElement('div');
  Object.assign(videoContainer.style, {
    position: 'relative',
    width: '100%',
    maxWidth: '640px',
    aspectRatio: '16/9',
    margin: 'auto'
  });

  container.appendChild(videoContainer);
  
  logAdEvent('Ad container created', {
    id,
    dimensions: {
      width: videoContainer.style.width,
      maxWidth: videoContainer.style.maxWidth,
      aspectRatio: videoContainer.style.aspectRatio
    }
  });

  return videoContainer;
}