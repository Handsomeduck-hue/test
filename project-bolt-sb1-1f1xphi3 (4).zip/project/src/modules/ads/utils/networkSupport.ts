import { AD_ERROR_MESSAGES } from '../constants';
import { logAdEvent } from './logging';

export function checkNetworkConditions() {
  const errors: string[] = [];
  const details = {
    online: navigator.onLine,
    connectionType: (navigator as any).connection?.type,
    effectiveType: (navigator as any).connection?.effectiveType,
    downlink: (navigator as any).connection?.downlink,
    rtt: (navigator as any).connection?.rtt
  };

  logAdEvent('Network conditions check', details);

  if (!details.online) {
    errors.push(AD_ERROR_MESSAGES.NETWORK);
  }

  // Check for slow connections
  if (details.effectiveType === 'slow-2g' || details.effectiveType === '2g') {
    errors.push(AD_ERROR_MESSAGES.SLOW_NETWORK);
  }

  return {
    isValid: errors.length === 0,
    errors,
    details
  };
}