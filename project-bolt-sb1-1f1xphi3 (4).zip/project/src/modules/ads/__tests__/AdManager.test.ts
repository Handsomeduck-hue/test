import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useAdStore } from '../AdManager';
import { AD_ERROR_MESSAGES, AD_TIMEOUT } from '../constants';

describe('AdManager', () => {
  beforeEach(() => {
    // Mock IMA SDK
    window.google = {
      ima: {
        AdDisplayContainer: vi.fn(() => ({
          initialize: vi.fn(),
          destroy: vi.fn()
        })),
        AdsLoader: vi.fn(() => ({
          addEventListener: vi.fn(),
          requestAds: vi.fn(),
          destroy: vi.fn()
        })),
        AdsRequest: vi.fn(() => ({
          setAdWillAutoPlay: vi.fn(),
          setAdWillPlayMuted: vi.fn()
        })),
        AdsManagerLoadedEvent: {
          Type: { ADS_MANAGER_LOADED: 'adsManagerLoaded' }
        },
        AdEvent: {
          Type: {
            STARTED: 'start',
            COMPLETE: 'complete',
            ALL_ADS_COMPLETED: 'allAdsCompleted'
          }
        },
        AdErrorEvent: {
          Type: { AD_ERROR: 'adError' }
        },
        ViewMode: {
          NORMAL: 'normal',
          FULLSCREEN: 'fullscreen'
        }
      }
    };

    // Mock navigator
    Object.defineProperty(navigator, 'onLine', {
      configurable: true,
      value: true
    });
  });

  afterEach(() => {
    vi.clearAllMocks();
    document.body.innerHTML = '';
  });

  it('should initialize ads successfully', async () => {
    const { result } = renderHook(() => useAdStore());

    await act(async () => {
      await result.current.actions.initializeAds();
    });

    expect(result.current.state.error).toBeNull();
    expect(result.current.state.adUnit).toBeTruthy();
  });

  it('should handle initialization errors', async () => {
    // Simulate IMA SDK load failure
    window.google = undefined;

    const { result } = renderHook(() => useAdStore());

    await act(async () => {
      await result.current.actions.initializeAds();
    });

    expect(result.current.state.error).toBe(AD_ERROR_MESSAGES.INIT);
  });

  it('should respect cooldown period between ads', async () => {
    const { result } = renderHook(() => useAdStore());

    // Set a recent reward time
    act(() => {
      result.current.state.lastRewardTime = Date.now();
    });

    await act(async () => {
      const canShow = await result.current.actions.showRewardedAd();
      expect(canShow).toBe(false);
      expect(result.current.state.error).toContain('Please wait');
    });
  });

  it('should handle ad load timeout', async () => {
    vi.useFakeTimers();
    const { result } = renderHook(() => useAdStore());

    const showAdPromise = act(async () => {
      const canShow = await result.current.actions.showRewardedAd();
      expect(canShow).toBe(false);
    });

    // Fast-forward past timeout
    await act(async () => {
      vi.advanceTimersByTime(AD_TIMEOUT + 100);
    });

    await showAdPromise;
    expect(result.current.state.error).toBe(AD_ERROR_MESSAGES.TIMEOUT);
    vi.useRealTimers();
  });

  it('should clean up resources after ad completion', async () => {
    const mockAdsManager = {
      init: vi.fn(),
      start: vi.fn(),
      addEventListener: vi.fn(),
      destroy: vi.fn()
    };

    const { result } = renderHook(() => useAdStore());

    // Mock successful ad load
    window.google.ima.AdsLoader = vi.fn(() => ({
      addEventListener: (event, handler) => {
        if (event === 'adsManagerLoaded') {
          handler({ getAdsManager: () => mockAdsManager });
        }
      },
      requestAds: vi.fn()
    }));

    await act(async () => {
      await result.current.actions.showRewardedAd();
    });

    expect(mockAdsManager.destroy).toHaveBeenCalled();
  });

  it('should handle network errors gracefully', async () => {
    // Simulate offline
    Object.defineProperty(navigator, 'onLine', {
      configurable: true,
      value: false
    });

    const { result } = renderHook(() => useAdStore());

    await act(async () => {
      const canShow = await result.current.actions.showRewardedAd();
      expect(canShow).toBe(false);
      expect(result.current.state.error).toBe(AD_ERROR_MESSAGES.NETWORK);
    });
  });
});