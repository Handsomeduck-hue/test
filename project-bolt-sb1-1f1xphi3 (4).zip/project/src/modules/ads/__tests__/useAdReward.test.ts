import { describe, it, expect, vi, beforeEach } from 'vitest';
import { renderHook, act } from '@testing-library/react';
import { useAdReward } from '../hooks/useAdReward';

describe('useAdReward', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  it('initializes with correct default state', () => {
    const { result } = renderHook(() => useAdReward());
    
    expect(result.current.canWatchAd).toBe(true);
    expect(result.current.timeRemaining).toBe(0);
    expect(result.current.isLoading).toBe(false);
  });

  it('updates state after watching ad', async () => {
    const { result } = renderHook(() => useAdReward());
    
    await act(async () => {
      await result.current.watchAd();
    });
    
    expect(result.current.canWatchAd).toBe(false);
    expect(result.current.timeRemaining).toBeGreaterThan(0);
  });

  it('enforces cooldown period', async () => {
    const { result } = renderHook(() => useAdReward());
    
    await act(async () => {
      await result.current.watchAd();
    });
    
    // Try watching another ad immediately
    const secondAttempt = result.current.watchAd();
    await expect(secondAttempt).rejects.toThrow('Please wait');
  });

  it('updates time remaining correctly', async () => {
    const { result } = renderHook(() => useAdReward());
    
    await act(async () => {
      await result.current.watchAd();
    });
    
    // Fast forward 1 minute
    act(() => {
      vi.advanceTimersByTime(60000);
    });
    
    expect(result.current.timeRemaining).toBe(240); // 4 minutes remaining
  });

  it('resets state after cooldown period', async () => {
    const { result } = renderHook(() => useAdReward());
    
    await act(async () => {
      await result.current.watchAd();
    });
    
    // Fast forward past cooldown
    act(() => {
      vi.advanceTimersByTime(300000); // 5 minutes
    });
    
    expect(result.current.canWatchAd).toBe(true);
    expect(result.current.timeRemaining).toBe(0);
  });

  it('handles errors gracefully', async () => {
    const { result } = renderHook(() => useAdReward());
    
    // Mock ad failure
    vi.spyOn(window, 'fetch').mockRejectedValueOnce(new Error('Ad failed'));
    
    await act(async () => {
      try {
        await result.current.watchAd();
      } catch (error) {
        expect(error.message).toBe('Ad failed');
      }
    });
    
    expect(result.current.canWatchAd).toBe(true);
    expect(result.current.error).toBeTruthy();
  });

  it('cleans up on unmount', () => {
    const { unmount } = renderHook(() => useAdReward());
    
    unmount();
    
    // Verify cleanup
    expect(vi.getTimerCount()).toBe(0);
  });
});