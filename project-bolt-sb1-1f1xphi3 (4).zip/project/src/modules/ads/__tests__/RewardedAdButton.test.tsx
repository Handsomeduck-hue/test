import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { RewardedAdButton } from '../components/RewardedAdButton';
import { useAdStore } from '../AdManager';

// Mock the store
vi.mock('../AdManager', () => ({
  useAdStore: vi.fn()
}));

describe('RewardedAdButton', () => {
  const mockOnReward = vi.fn();
  const mockShowRewardedAd = vi.fn();
  const mockResetError = vi.fn();

  beforeEach(() => {
    vi.clearAllMocks();
    
    // Default mock implementation
    (useAdStore as any).mockReturnValue({
      state: {
        isLoading: false,
        error: null,
        lastRewardTime: null
      },
      actions: {
        showRewardedAd: mockShowRewardedAd,
        resetError: mockResetError
      }
    });
  });

  it('renders in initial state correctly', () => {
    render(<RewardedAdButton onReward={mockOnReward} />);
    
    expect(screen.getByText('Watch Ad for Extra Life')).toBeInTheDocument();
    expect(screen.getByRole('button')).not.toBeDisabled();
  });

  it('shows loading state while ad is loading', () => {
    (useAdStore as any).mockReturnValue({
      state: { isLoading: true },
      actions: { showRewardedAd: mockShowRewardedAd }
    });

    render(<RewardedAdButton onReward={mockOnReward} />);
    
    expect(screen.getByText('Loading Video...')).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });

  it('handles successful ad view', async () => {
    mockShowRewardedAd.mockResolvedValue(true);
    
    render(<RewardedAdButton onReward={mockOnReward} />);
    
    fireEvent.click(screen.getByRole('button'));
    
    await waitFor(() => {
      expect(mockShowRewardedAd).toHaveBeenCalledTimes(1);
      expect(mockOnReward).toHaveBeenCalledTimes(1);
    });
  });

  it('handles failed ad view', async () => {
    mockShowRewardedAd.mockResolvedValue(false);
    
    render(<RewardedAdButton onReward={mockOnReward} />);
    
    fireEvent.click(screen.getByRole('button'));
    
    await waitFor(() => {
      expect(mockShowRewardedAd).toHaveBeenCalledTimes(1);
      expect(mockOnReward).not.toHaveBeenCalled();
    });
  });

  it('shows cooldown timer when recently rewarded', () => {
    (useAdStore as any).mockReturnValue({
      state: {
        isLoading: false,
        lastRewardTime: Date.now() - 60000 // 1 minute ago
      },
      actions: { showRewardedAd: mockShowRewardedAd }
    });

    render(<RewardedAdButton onReward={mockOnReward} />);
    
    expect(screen.getByText(/Wait/)).toBeInTheDocument();
    expect(screen.getByRole('button')).toBeDisabled();
  });

  it('shows error message when ad fails to load', () => {
    const errorMessage = 'Failed to load ad';
    (useAdStore as any).mockReturnValue({
      state: {
        isLoading: false,
        error: errorMessage
      },
      actions: { showRewardedAd: mockShowRewardedAd }
    });

    render(<RewardedAdButton onReward={mockOnReward} />);
    
    expect(screen.getByText(errorMessage)).toBeInTheDocument();
  });

  it('prevents multiple clicks while loading', async () => {
    mockShowRewardedAd.mockImplementation(() => new Promise(resolve => setTimeout(() => resolve(true), 100)));
    
    render(<RewardedAdButton onReward={mockOnReward} />);
    
    const button = screen.getByRole('button');
    fireEvent.click(button);
    fireEvent.click(button);
    fireEvent.click(button);
    
    await waitFor(() => {
      expect(mockShowRewardedAd).toHaveBeenCalledTimes(1);
    });
  });
});