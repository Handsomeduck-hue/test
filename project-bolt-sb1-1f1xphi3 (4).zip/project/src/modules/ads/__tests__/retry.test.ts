import { describe, it, expect, vi } from 'vitest';
import { retryWithBackoff } from '../utils/retry';
import { AD_ERROR_MESSAGES } from '../constants';

describe('retryWithBackoff', () => {
  it('should succeed on first attempt if operation succeeds', async () => {
    const operation = vi.fn().mockResolvedValue('success');
    const result = await retryWithBackoff(operation);
    
    expect(result).toBe('success');
    expect(operation).toHaveBeenCalledTimes(1);
  });

  it('should retry failed operations up to max attempts', async () => {
    const operation = vi.fn()
      .mockRejectedValueOnce(new Error('fail'))
      .mockRejectedValueOnce(new Error('fail'))
      .mockResolvedValue('success');

    const result = await retryWithBackoff(operation, 3);
    
    expect(result).toBe('success');
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it('should throw after max attempts are exhausted', async () => {
    const operation = vi.fn().mockRejectedValue(new Error('fail'));

    await expect(retryWithBackoff(operation, 3))
      .rejects
      .toThrow('fail');
    
    expect(operation).toHaveBeenCalledTimes(3);
  });

  it('should use exponential backoff between retries', async () => {
    vi.useFakeTimers();
    const operation = vi.fn()
      .mockRejectedValueOnce(new Error('fail'))
      .mockResolvedValue('success');

    const retryPromise = retryWithBackoff(operation, 2, 1000);
    
    // First attempt fails immediately
    expect(operation).toHaveBeenCalledTimes(1);
    
    // Should wait exponentially before second attempt
    await vi.advanceTimersByTime(2000);
    expect(operation).toHaveBeenCalledTimes(2);
    
    await retryPromise;
    vi.useRealTimers();
  });

  it('should use generic error message if none provided', async () => {
    const operation = vi.fn().mockRejectedValue(null);

    await expect(retryWithBackoff(operation, 1))
      .rejects
      .toThrow(AD_ERROR_MESSAGES.GENERIC);
  });
});