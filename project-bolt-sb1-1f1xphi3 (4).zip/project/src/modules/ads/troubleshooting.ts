import { isAdBlockEnabled } from './utils';
import { AD_RETRY_ATTEMPTS, AD_RETRY_DELAY, AD_PRELOAD_TIMEOUT, AD_CONTAINER_ID, VIDEO_AD_CLIENT } from './constants';

export type AdErrorCode = 
  | 'NO_FILL'
  | 'NETWORK_ERROR' 
  | 'TIMEOUT'
  | 'INVALID_STATE'
  | 'AD_BLOCKER'
  | 'INITIALIZATION_ERROR'
  | 'LOAD_ERROR';

export type AdErrorDetails = {
  code: AdErrorCode;
  message: string;
  timestamp: number;
  adUnit?: string;
  retryAttempts?: number;
};

export const AD_ERROR_MESSAGES = {
  NO_FILL: 'No ads are currently available. Please try again later.',
  NETWORK_ERROR: 'Unable to load ad due to network connectivity issues.',
  TIMEOUT: 'Ad request timed out. Please check your connection and try again.',
  INVALID_STATE: 'Ad system is in an invalid state. Please restart the app.',
  AD_BLOCKER: 'Ad blocker detected. Please disable it to watch ads.',
  INITIALIZATION_ERROR: 'Failed to initialize ad services.',
  LOAD_ERROR: 'Failed to load advertisement. Please try again.'
};

export const USER_FRIENDLY_SOLUTIONS = {
  NO_FILL: [
    'Wait a few minutes before trying again',
    'Check that you have a stable internet connection',
    'Try closing and reopening the app'
  ],
  NETWORK_ERROR: [
    'Check your internet connection',
    'Try switching between Wi-Fi and mobile data',
    'Ensure you\'re not in airplane mode'
  ],
  TIMEOUT: [
    'Check your internet speed',
    'Close other apps running in the background',
    'Try moving to an area with better signal'
  ],
  INVALID_STATE: [
    'Force close and restart the app',
    'Clear the app cache',
    'Update to the latest version'
  ],
  AD_BLOCKER: [
    'Disable any ad blocking apps or browser extensions',
    'Add this site to your ad blocker\'s whitelist',
    'Try using a different browser'
  ],
  INITIALIZATION_ERROR: [
    'Ensure you have the latest version of the app',
    'Clear app data and cache',
    'Try uninstalling and reinstalling the app'
  ]
};

export const troubleshootAdError = async (error: AdErrorDetails): Promise<string> => {
  // Log error for analytics
  console.error('Ad Error:', {
    code: error.code,
    message: error.message,
    timestamp: error.timestamp,
    adUnit: error.adUnit
  });

  // Check for ad blocker
  if (await isAdBlockEnabled()) {
    return AD_ERROR_MESSAGES.AD_BLOCKER;
  }

  // Verify network connectivity
  try {
    const response = await fetch('https://www.google.com/generate_204');
    if (!response.ok) {
      return AD_ERROR_MESSAGES.NETWORK_ERROR;
    }
  } catch {
    return AD_ERROR_MESSAGES.NETWORK_ERROR;
  }

  // Return appropriate error message
  return AD_ERROR_MESSAGES[error.code] || 'An unknown error occurred. Please try again.';
};

export const getAdErrorSolutions = (errorCode: AdErrorCode): string[] => {
  return USER_FRIENDLY_SOLUTIONS[errorCode] || [
    'Try again later',
    'Check your internet connection',
    'Restart the app'
  ];
};

export const checkAdRequirements = (): { ready: boolean; issues: string[] } => {
  const issues: string[] = [];

  // Check network connectivity
  if (!navigator.onLine) {
    issues.push('No internet connection detected');
  }

  // Check for ad blockers
  if (isAdBlockEnabled()) {
    issues.push('Ad blocker detected');
  }

  // Check Google IMA SDK
  if (!window.google?.ima) {
    issues.push('Ad service not initialized');
  }

  // Check if in background tab
  if (document.hidden) {
    issues.push('Application is in background');
  }

  return {
    ready: issues.length === 0,
    issues
  };
};

export const preloadAd = async () => {
  try {
    // Verify IMA SDK is available
    if (!window.google?.ima) {
      throw new Error('Ad service not available - please refresh the page');
    }

    // Check if AdSense is loaded
    if (!window.adsbygoogle) {
      throw new Error('Ad service not initialized - please refresh the page');
    }

    return await new Promise((resolve, reject) => {
      let timeoutId = setTimeout(() => {
        cleanup();
        reject(new Error('Ad preload timed out - please try again'));
      }, AD_PRELOAD_TIMEOUT);

      // Create a hidden container for the ad
      const container = document.createElement('div');
      container.id = AD_CONTAINER_ID;
      container.style.display = 'none';
      container.style.width = '100%';
      container.style.height = '100%';
      container.style.position = 'absolute';
      container.style.top = '0';
      container.style.left = '0';
      document.body.appendChild(container);

      // Initialize the ad display container
      const adDisplayContainer = new google.ima.AdDisplayContainer(
        container
      );

      try {
        // Initialize the container
        adDisplayContainer.initialize();
        
        // Add error event listener for initialization
        window.addEventListener('error', (e) => {
          if (e.message.includes('ima')) {
            cleanup();
            reject(new Error('Ad initialization failed - please try again'));
          }
        }, { once: true });
        
      } catch (error) {
        document.body.removeChild(container);
        reject(new Error('Failed to initialize ad container'));
        return;
      }
      
      const adsLoader = new google.ima.AdsLoader(adDisplayContainer);
      
      adsLoader.addEventListener(
        google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
        (event) => {
          try {
            const adsManager = event.getAdsManager({
              currentTime: 0,
              duration: 0,
              volume: 1
            });
            // Clean up container after getting the manager
            document.body.removeChild(container);
            adDisplayContainer.destroy();
            adsLoader.destroy();
            resolve(adsManager);
          } catch (error) {
            cleanup();
            reject(error);
          }
        }
      );

      adsLoader.addEventListener(
        google.ima.AdErrorEvent.Type.AD_ERROR,
        (error) => {
          cleanup();
          reject(new Error(error.getError().getMessage() || 'Failed to preload ad'));
        }
      );

      const cleanup = () => {
        try {
          if (document.body.contains(container)) {
            document.body.removeChild(container);
          }
          if (adDisplayContainer) adDisplayContainer.destroy();
          if (adsLoader) adsLoader.destroy();
          clearTimeout(timeoutId);
        } catch (error) {
          // Silent cleanup errors to avoid user confusion
        }
      };

      const adsRequest = new google.ima.AdsRequest();
      adsRequest.adTagUrl = `https://googleads.g.doubleclick.net/pagead/ads?` +
        `client=${VIDEO_AD_CLIENT}` +
        `&ad_type=video_reward` +
        `&format=video` +
        `&sz=640x480` +
        `&iu=/21775744923/rewarded_video_example` +
        `&env=vp` +
        `&gdfp_req=1` +
        `&output=vast` +
        `&correlator=${Date.now()}` +
        `&unviewed_position_start=1` +
        `&description_url=${encodeURIComponent(window.location.href)}` +
        `&nofb=1` +
        `&url=${encodeURIComponent(window.location.href)}` +
        `&videoad_start_delay=0` +
        `&vpmute=0` +
        `&vpa=1`;

      // Set additional ad request properties
      adsRequest.linearAdSlotWidth = 640;
      adsRequest.linearAdSlotHeight = 480;
      adsRequest.setAdWillAutoPlay(true);
      adsRequest.setAdWillPlayMuted(false);

      adsLoader.requestAds(adsRequest);
    });
  } catch (error) {
    const enhancedError = new Error(
      `Ad preload failed: ${error.message || 'Unknown error'}`,
      { cause: error }
    );
    console.error('Ad preload error:', enhancedError);
    throw enhancedError;
  }
};

export const retryAdWithBackoff = async (
  attemptAd: () => Promise<boolean>,
  maxAttempts = AD_RETRY_ATTEMPTS,
  baseDelay = AD_RETRY_DELAY
): Promise<boolean> => {
  let attempt = 0;
  
  while (attempt < maxAttempts) {
    try {
      const result = await attemptAd();
      if (result) {
        return true;
      }
    } catch (error) {
      console.error(`Ad attempt ${attempt + 1} failed:`, error);
    }

    attempt++;
    if (attempt < maxAttempts) {
      // Exponential backoff with jitter
      const delay = baseDelay * Math.pow(2, attempt) + Math.random() * 1000;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }

  return false;
};