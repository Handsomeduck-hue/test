export const COOLDOWN_PERIOD = 5 * 60 * 1000; // 5 minutes

// Test ad tag URL that's guaranteed to work
export const TEST_AD_TAG_URL = 'https://pubads.g.doubleclick.net/gampad/ads?' +
  'iu=/21775744923/external/single_preroll_skippable&' +
  'sz=640x480&' +
  'ciu_szs=300x250%2C728x90&' +
  'gdfp_req=1&' +
  'output=vast&' +
  'unviewed_position_start=1&' +
  'env=vp&' +
  'impl=s&' +
  'correlator=' + Date.now() +
  '&description_url=' + encodeURIComponent(window.location.href);

// Test credentials
export const VIDEO_AD_CLIENT = 'ca-video-pub-3940256099942544';
export const ADMOB_APP_ID = 'ca-app-pub-3940256099942544';
export const ADSENSE_CLIENT_ID = 'ca-pub-3940256099942544';
export const REWARDED_AD_UNIT_ID = 'ca-video-pub-3940256099942544/8691691433';
export const AD_TIMEOUT = 30000; // 30 second timeout
export const AD_RETRY_ATTEMPTS = 2; // Two retries for better reliability
export const AD_RETRY_DELAY = 3000; // Longer delay between retries
export const AD_PRELOAD_TIMEOUT = 15000; // Reduced preload timeout
export const AD_CONTAINER_ID = 'ad-container';
export const AD_LOAD_TIMEOUT = 25000; // Increased initial load timeout
export const NETWORK_TIMEOUT = 5000; // Network request timeout
export const AD_SERVER_TIMEOUT = 8000; // Ad server specific timeout

export const AD_ERROR_MESSAGES = {
  TIMEOUT: 'Ad request timed out. Please check your connection and try again.',
  NETWORK: 'Unable to load ad due to network issues. Please check your connection.',
  SLOW_NETWORK: 'Your network connection is too slow for video ads. Please try again with a better connection.',
  BLOCKED: 'Ad blocker detected. Please disable it to watch ads.',
  INIT: 'Failed to initialize ad services. Please refresh the page.',
  GENERIC: 'Unable to load ad. Please try again.',
  PLAYBACK: 'Video playback failed. Please try again.',
  UNSUPPORTED: 'Video ads are not supported on this device.',
  OFFLINE: 'You appear to be offline. Please check your internet connection.',
  AD_SERVER: 'Cannot reach ad server. Please check your connection and try again.',
  CONNECTION_ERROR: 'Connection error occurred. Please check your network and try again.',
  VISIBILITY: 'Please keep the tab active while watching ads',
  SECURE_CONTEXT: 'Secure context required for video playback'
};

export const AD_CONTAINER_STYLES = {
  position: 'fixed',
  zIndex: '9999',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%',
  background: 'rgba(0,0,0,0.8)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
};