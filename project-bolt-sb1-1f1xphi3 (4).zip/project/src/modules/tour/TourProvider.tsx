import React from 'react';
import { useLocalStorage } from '../hooks/useLocalStorage';

type TourProviderProps = {
  children: React.ReactNode;
};

export function TourProvider({ children }: TourProviderProps) {
  const [hasSeenTour] = useLocalStorage('hasSeenThemeTour', false);

  return (
    <div data-tour-completed={hasSeenTour}>
      {children} 
    </div>
  );
}