import React, { useEffect } from 'react';
type ClarityProviderProps = {
  children: React.ReactNode;
};

declare global {
  interface Window {
    clarity?: (method: string, ...args: any[]) => void;
  }
}

export function ClarityProvider({ children }: ClarityProviderProps) {
  useEffect(() => {
    if (process.env.NODE_ENV === 'production') {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.async = true;
      script.crossOrigin = 'anonymous';
      script.src = 'https://www.clarity.ms/tag/p4ny0e4ww8';
      
      // Initialize clarity function before loading script
      window.clarity = window.clarity || function(...args) {
        (window.clarity.q = window.clarity.q || []).push(args);
      };
      
      document.head.appendChild(script);
    }
  }, []);

  return <>{children}</>;
}