import React from 'react';
import { motion } from 'framer-motion';
import { cn } from '../utils/cn';

type ButtonProps = {
  variant?: 'primary' | 'secondary' | 'success' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  children: React.ReactNode;
  className?: string;
} & React.ButtonHTMLAttributes<HTMLButtonElement>;

export function Button({
  variant = 'primary',
  size = 'md',
  children,
  className,
  disabled,
  ...props
}: ButtonProps) {
  const baseStyles = cn(
    'w-full font-semibold rounded-2xl',
    'transition-all duration-200',
    'transform touch-manipulation',
    'focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-offset-2',
    'disabled:opacity-50 disabled:cursor-not-allowed',
    'select-none'
  );
  
  const variants = {
    primary: cn(
      'bg-[#007AFF] text-white',
      'hover:bg-[#0040DD] active:bg-[#0040DD]',
      'dark:bg-[#0A84FF] dark:hover:bg-[#0066CC]',
      'focus-visible:ring-[#007AFF] dark:focus-visible:ring-[#0A84FF]'
    ),
    secondary: cn(
      'bg-[#F2F2F7] text-[#1C1C1E]',
      'hover:bg-[#E5E5EA] active:bg-[#E5E5EA]',
      'dark:bg-[#2C2C2E] dark:text-white dark:hover:bg-[#3A3A3C]'
    ),
    success: cn(
      'bg-[#34C759] text-white',
      'hover:bg-[#248A3D] active:bg-[#248A3D]',
      'dark:bg-[#30D158] dark:hover:bg-[#248A3D]'
    ),
    danger: cn(
      'bg-[#FF3B30] text-white',
      'hover:bg-[#D70015] active:bg-[#D70015]',
      'dark:bg-[#FF453A] dark:hover:bg-[#D70015]'
    )
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg'
  };

  return (
    <motion.button
      whileTap={disabled ? {} : { scale: 0.98 }}
      className={cn(
        baseStyles,
        variants[variant],
        sizes[size],
        disabled && 'opacity-50 cursor-not-allowed',
        className
      )}
      disabled={disabled}
      {...props}
    >
      {children}
    </motion.button>
  );
}