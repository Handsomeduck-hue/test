import { debounce } from './debounce';

export function measureFrameTime(): number {
  return performance.now();
}

export function calculateFPS(startTime: number, endTime: number): number {
  const duration = endTime - startTime;
  return Math.round(1000 / duration);
}

export const optimizeAnimationFrame = (callback: () => void): number => {
  return requestAnimationFrame(() => {
    const start = measureFrameTime();
    callback();
    const end = measureFrameTime();
    
    if (calculateFPS(start, end) < 30) {
      console.warn('Low FPS detected, optimizing animations');
    }
  });
};

export const debouncedFrame = debounce((callback: () => void) => {
  requestAnimationFrame(callback);
}, 16);

export function optimizeImageLoading(img: HTMLImageElement): void {
  img.decoding = 'async';
  img.loading = 'lazy';
  
  if ('fetchPriority' in img) {
    img.fetchPriority = 'high';
  }
}

export function optimizeAssetPreloading(): void {
  const preloadLinks = [
    { href: '/assets/fonts/inter-var.woff2', as: 'font', type: 'font/woff2' },
    { href: '/assets/images/logo.svg', as: 'image' }
  ];

  preloadLinks.forEach(({ href, as, type }) => {
    const link = document.createElement('link');
    link.rel = 'preload';
    link.href = href;
    link.as = as;
    if (type) link.type = type;
    if (as === 'font') link.crossOrigin = 'anonymous';
    document.head.appendChild(link);
  });
}