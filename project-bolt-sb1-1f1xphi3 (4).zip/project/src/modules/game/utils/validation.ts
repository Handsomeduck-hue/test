import { GameSet, Category } from '../types';

export function validateGameSet(gameSet: GameSet): boolean {
  if (!gameSet.items || !Array.isArray(gameSet.items)) {
    console.error('Invalid game set: items must be an array');
    return false;
  }

  if (!gameSet.oddOneOut || !gameSet.items.includes(gameSet.oddOneOut)) {
    console.error('Invalid game set: oddOneOut must be one of the items');
    return false;
  }

  if (!gameSet.explanation || typeof gameSet.explanation !== 'string') {
    console.error('Invalid game set: explanation must be a string');
    return false;
  }

  return true;
}

export function validateCategory(category: Category): boolean {
  if (!category.name || typeof category.name !== 'string') {
    console.error('Invalid category: name must be a string');
    return false;
  }

  if (!category.sets || !Array.isArray(category.sets)) {
    console.error('Invalid category: sets must be an array');
    return false;
  }

  return category.sets.every(validateGameSet);
}