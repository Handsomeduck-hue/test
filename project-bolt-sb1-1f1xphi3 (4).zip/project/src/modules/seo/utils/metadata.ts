import { SEO_CONFIG } from '../constants';

export function generateTitle(pageTitle?: string): string {
  if (!pageTitle) return `${SEO_CONFIG.siteName} ${SEO_CONFIG.titleTemplate.replace('%s', '')}`;
  return SEO_CONFIG.titleTemplate.replace('%s', pageTitle);
}

export function generateMetaTags({
  title,
  description = SEO_CONFIG.defaultDescription,
  image = SEO_CONFIG.defaultImage,
  url,
  type = 'website'
}: {
  title?: string;
  description?: string;
  image?: string;
  url?: string;
  type?: string;
}) {
  const metaTags = [
    { name: 'description', content: description },
    { property: 'og:title', content: title || generateTitle() },
    { property: 'og:description', content: description },
    { property: 'og:image', content: image },
    { property: 'og:url', content: url || SEO_CONFIG.siteUrl },
    { property: 'og:type', content: type },
    { name: 'twitter:card', content: 'summary_large_image' },
    { name: 'twitter:site', content: SEO_CONFIG.twitterHandle },
    { name: 'twitter:title', content: title || generateTitle() },
    { name: 'twitter:description', content: description },
    { name: 'twitter:image', content: image }
  ];

  return metaTags;
}