import { Category, Difficulty } from '../types/game';

export const categories: Category[] = [
  {
    name: 'Starter',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['🚗 Car', '🐱 Cat', '🐶 Dog', '🐰 Rabbit'],
        oddOneOut: '🚗 Car',
        explanation: 'Car is not an animal, while all others are pets.',
        hint: 'Think about living things.',
      },
      {
        items: ['✏️ Pencil', '📱 Phone', '✒️ Pen', '🎨 Paint'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not a drawing tool.',
        hint: 'Which one cannot make marks on paper?',
      },
      {
        items: ['👕 Shirt', '🎮 Controller', '👖 Pants', '👟 Shoes'],
        oddOneOut: '🎮 Controller',
        explanation: 'Controller is not a clothing item.',
        hint: 'What do you wear?',
      },
      {
        items: ['📚 Book', '🍎 Apple', '🍌 Banana', '🥕 Carrot'],
        oddOneOut: '📚 Book',
        explanation: 'Book is not edible, others are foods.',
        hint: 'What can you eat?',
      },
      {
        items: ['⭐ Star', '🚲 Bicycle', '🌞 Sun', '🌙 Moon'],
        oddOneOut: '🚲 Bicycle',
        explanation: 'Bicycle is not a celestial body.',
        hint: 'Think about objects in space.',
      }
    ]
  },
  {
    name: 'Mythology & Folklore',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['Thor', 'Batman', 'Zeus', 'Amaterasu'],
        oddOneOut: 'Batman',
        explanation: 'Batman is a fictional superhero, others are ancient deities.',
        hint: 'Think about ancient mythology.',
      },
      {
        items: ['Times Square', 'Mount Olympus', 'Valhalla', 'Temple of Delphi'],
        oddOneOut: 'Times Square',
        explanation: 'Times Square is a modern location, others are mythological places.',
        hint: 'Consider ancient sacred places.',
      },
      {
        items: ['Dragon', 'Elephant', 'Pegasus', 'Phoenix'],
        oddOneOut: 'Elephant',
        explanation: 'Elephant is a real animal, others are mythical creatures.',
        hint: 'Which exists in reality?',
      },
      {
        items: ['Mjolnir', 'Umbrella', 'Excalibur', 'Kusanagi'],
        oddOneOut: 'Umbrella',
        explanation: 'Umbrella is a common object, others are legendary weapons.',
        hint: 'Think about magical items.',
      },
      {
        items: ['Pythia', 'Weather Forecaster', 'Oracle of Delphi', 'Norns'],
        oddOneOut: 'Weather Forecaster',
        explanation: 'Weather Forecaster is a modern profession, others are mythological seers.',
        hint: 'Consider fortune tellers of ancient times.',
      }
    ]
  },
  {
    name: 'Science & Innovation',
    difficulty: Difficulty.Hard,
    sets: [
      {
        items: ['Shakespeare', 'Edison', 'Tesla', 'Newton'],
        oddOneOut: 'Shakespeare',
        explanation: 'Shakespeare was a playwright, others were inventors/scientists.',
        hint: 'Think about scientific contributions.',
      },
      {
        items: ['Star', 'Rainbow', 'Planet', 'Asteroid'],
        oddOneOut: 'Rainbow',
        explanation: 'Rainbow is an atmospheric phenomenon, others are celestial objects.',
        hint: 'Consider objects in space.',
      },
      {
        items: ['Telescope', 'Kaleidoscope', 'Microscope', 'Spectroscope'],
        oddOneOut: 'Kaleidoscope',
        explanation: 'Kaleidoscope is a toy, others are scientific instruments.',
        hint: 'Which is used for entertainment?',
      },
      {
        items: ['RNA', 'PDF', 'DNA', 'ATP'],
        oddOneOut: 'PDF',
        explanation: 'PDF is a file format, others are biological molecules.',
        hint: 'Think about biology.',
      },
      {
        items: ['Neutron', 'Crayon', 'Proton', 'Electron'],
        oddOneOut: 'Crayon',
        explanation: 'Crayon is an art supply, others are subatomic particles.',
        hint: 'Consider atomic structure.',
      }
    ]
  },
  {
    name: 'Music & Sound',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['Violin', 'Microphone', 'Piano', 'Guitar'],
        oddOneOut: 'Microphone',
        explanation: 'Microphone is an audio device, not a musical instrument.',
        hint: 'Which one doesn\'t create music on its own?',
      },
      {
        items: ['Classical', 'Painting', 'Jazz', 'Rock'],
        oddOneOut: 'Painting',
        explanation: 'Painting is a visual art form, not a music genre.',
        hint: 'Think about types of music.',
      },
      {
        items: ['Van Gogh', 'Mozart', 'Beethoven', 'Bach'],
        oddOneOut: 'Van Gogh',
        explanation: 'Van Gogh was a painter, others were composers.',
        hint: 'Who created music?',
      },
      {
        items: ['Opera', 'Novel', 'Symphony', 'Concerto'],
        oddOneOut: 'Novel',
        explanation: 'Novel is literature, others are musical compositions.',
        hint: 'Which involves sound?',
      },
      {
        items: ['Musician', 'Architect', 'Conductor', 'Composer'],
        oddOneOut: 'Architect',
        explanation: 'Architect designs buildings, others are music professionals.',
        hint: 'Think about musical careers.',
      }
    ]
  },
  {
    name: 'Animal Kingdom',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['Ocean', 'Mall', 'Desert', 'Forest'],
        oddOneOut: 'Mall',
        explanation: 'Mall is a human-made structure, others are natural habitats.',
        hint: 'Which is not a natural environment?',
      },
      {
        items: ['Eagle', 'Giraffe', 'Lion', 'Shark'],
        oddOneOut: 'Giraffe',
        explanation: 'Giraffe is herbivorous, others are predators.',
        hint: 'Think about eating habits.',
      },
      {
        items: ['Bat', 'Penguin', 'Ostrich', 'Emu'],
        oddOneOut: 'Bat',
        explanation: 'Bat is a mammal, others are flightless birds.',
        hint: 'Consider animal classifications.',
      },
      {
        items: ['Whale', 'Jellyfish', 'Dolphin', 'Shark'],
        oddOneOut: 'Jellyfish',
        explanation: 'Jellyfish is an invertebrate, others are vertebrates.',
        hint: 'Think about backbones.',
      },
      {
        items: ['Wolf', 'Deer', 'Bear', 'Fox'],
        oddOneOut: 'Deer',
        explanation: 'Deer is an herbivore, others are carnivores.',
        hint: 'Consider diet types.',
      }
    ]
  },
  {
    name: 'Food & Cuisine',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['Freezing', 'Baking', 'Grilling', 'Frying'],
        oddOneOut: 'Freezing',
        explanation: 'Freezing is preservation, not a cooking method.',
        hint: 'Which doesn\'t involve heat?',
      },
      {
        items: ['Whisk', 'Hammer', 'Knife', 'Spatula'],
        oddOneOut: 'Hammer',
        explanation: 'Hammer is a construction tool, not a kitchen utensil.',
        hint: 'What would you find in a kitchen?',
      },
      {
        items: ['Pizza', 'Sofa', 'Sushi', 'Pasta'],
        oddOneOut: 'Sofa',
        explanation: 'Sofa is furniture, not food.',
        hint: 'What can you eat?',
      },
      {
        items: ['Butcher', 'Chef', 'Plumber', 'Baker'],
        oddOneOut: 'Plumber',
        explanation: 'Plumber is not a food-related profession.',
        hint: 'Think about food preparation.',
      },
      {
        items: ['Sugar', 'Sand', 'Salt', 'Pepper'],
        oddOneOut: 'Sand',
        explanation: 'Sand is not a seasoning or ingredient.',
        hint: 'What belongs in food?',
      }
    ]
  },
  {
    name: 'Sports & Games',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['Athletics', 'Chess', 'Swimming', 'Boxing'],
        oddOneOut: 'Chess',
        explanation: 'Chess is not an Olympic sport.',
        hint: 'Think about the Olympics.',
      },
      {
        items: ['Dictionary', 'Ball', 'Racket', 'Net'],
        oddOneOut: 'Dictionary',
        explanation: 'Dictionary is not sports equipment.',
        hint: 'What\'s used in sports?',
      },
      {
        items: ['Coach', 'Librarian', 'Referee', 'Player'],
        oddOneOut: 'Librarian',
        explanation: 'Librarian is not involved in sports.',
        hint: 'Who participates in sports?',
      },
      {
        items: ['Arena', 'Library', 'Stadium', 'Court'],
        oddOneOut: 'Library',
        explanation: 'Library is not a sports venue.',
        hint: 'Where are sports played?',
      },
      {
        items: ['Score', 'Chapter', 'Goal', 'Point'],
        oddOneOut: 'Chapter',
        explanation: 'Chapter is related to books, not sports scoring.',
        hint: 'Think about winning games.',
      }
    ]
  },
  {
    name: 'Technology',
    difficulty: Difficulty.Hard,
    sets: [
      {
        items: ['RAM', 'Coffee', 'CPU', 'GPU'],
        oddOneOut: 'Coffee',
        explanation: 'Coffee is a beverage, not a computer component.',
        hint: 'What belongs in a computer?',
      },
      {
        items: ['Facebook', 'Newspaper', 'Twitter', 'Instagram'],
        oddOneOut: 'Newspaper',
        explanation: 'Newspaper is traditional media, not social media.',
        hint: 'Think about online platforms.',
      },
      {
        items: ['Cobra', 'Python', 'Java', 'Ruby'],
        oddOneOut: 'Cobra',
        explanation: 'Cobra is a snake, others are programming languages.',
        hint: 'What\'s used in coding?',
      },
      {
        items: ['Switch', 'Toaster', 'Router', 'Modem'],
        oddOneOut: 'Toaster',
        explanation: 'Toaster is a kitchen appliance, not networking equipment.',
        hint: 'Think about internet connectivity.',
      },
      {
        items: ['WiFi', 'DNA', 'Bluetooth', 'USB'],
        oddOneOut: 'DNA',
        explanation: 'DNA is biological, others are technology standards.',
        hint: 'Consider digital connections.',
      }
    ]
  },
  {
    name: 'Weather & Climate',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['Traffic', 'Tornado', 'Earthquake', 'Tsunami'],
        oddOneOut: 'Traffic',
        explanation: 'Traffic is human-caused, not a natural disaster.',
        hint: 'Which is not caused by nature?',
      },
      {
        items: ['Barometer', 'Calculator', 'Thermometer', 'Anemometer'],
        oddOneOut: 'Calculator',
        explanation: 'Calculator is not a weather measurement tool.',
        hint: 'What measures weather conditions?',
      },
      {
        items: ['Snow', 'Fire', 'Rain', 'Hail'],
        oddOneOut: 'Fire',
        explanation: 'Fire is not a form of precipitation.',
        hint: 'What falls from the sky naturally?',
      },
      {
        items: ['Typhoon', 'Volcano', 'Hurricane', 'Cyclone'],
        oddOneOut: 'Volcano',
        explanation: 'Volcano is not a storm system.',
        hint: 'Think about wind-based phenomena.',
      },
      {
        items: ['Fahrenheit', 'Pixel', 'Celsius', 'Kelvin'],
        oddOneOut: 'Pixel',
        explanation: 'Pixel measures digital resolution, not temperature.',
        hint: 'Consider temperature scales.',
      }
    ]
  },
  {
    name: 'Transportation',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['Helicopter', 'Submarine', 'Airplane', 'Rocket'],
        oddOneOut: 'Submarine',
        explanation: 'Submarine operates underwater, not in the air.',
        hint: 'Which doesn\'t fly?',
      },
      {
        items: ['KPH', 'Pounds', 'MPH', 'Knots'],
        oddOneOut: 'Pounds',
        explanation: 'Pounds measures weight, not speed.',
        hint: 'Think about measuring speed.',
      },
      {
        items: ['Captain', 'Chef', 'Pilot', 'Driver'],
        oddOneOut: 'Chef',
        explanation: 'Chef is not a transportation professional.',
        hint: 'Who operates vehicles?',
      },
      {
        items: ['Restaurant', 'Airport', 'Harbor', 'Station'],
        oddOneOut: 'Restaurant',
        explanation: 'Restaurant is not a transportation hub.',
        hint: 'Where do vehicles arrive and depart?',
      },
      {
        items: ['Engine', 'Pillow', 'Wheel', 'Brake'],
        oddOneOut: 'Pillow',
        explanation: 'Pillow is not a vehicle component.',
        hint: 'What\'s part of a vehicle?',
      }
    ]
  }
];

export const difficultyProgression = {
  scoreThresholds: {
    [Difficulty.Easy]: 0,
    [Difficulty.Medium]: 1000,
    [Difficulty.Hard]: 2500,
    [Difficulty.Expert]: 5000
  },
  timeMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 0.8,
    [Difficulty.Hard]: 0.6,
    [Difficulty.Expert]: 0.4
  },
  bonusMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 1.5,
    [Difficulty.Hard]: 2,
    [Difficulty.Expert]: 3
  }
};