import type { ServerOptions } from 'vite';

export const serverConfig: ServerOptions = {
  headers: {
    'Cache-Control': 'public, max-age=31536000',
    'X-Content-Type-Options': 'nosniff',
    'X-Frame-Options': 'DENY',
    'X-XSS-Protection': '1; mode=block'
  }
};