import { describe, test, expect, beforeEach } from '@jest/globals';
import { HomePage } from './pages/HomePage';
import { WebDriver } from 'selenium-webdriver';

describe('Browser Compatibility Tests', () => {
  let homePage: HomePage;
  let driver: WebDriver;

  beforeEach(async () => {
    driver = global.driver;
    homePage = new HomePage(driver);
    await homePage.navigate();
  });

  test('should render correctly on different viewport sizes', async () => {
    const viewports = [
      { width: 375, height: 667 },  // iPhone SE
      { width: 768, height: 1024 }, // iPad
      { width: 1366, height: 768 }, // Laptop
      { width: 1920, height: 1080 } // Desktop
    ];

    for (const viewport of viewports) {
      await driver.manage().window().setRect(viewport);
      
      // Check if key elements are visible and properly positioned
      const gameBoard = await driver.findElement(By.css('[data-testid="game-board"]'));
      const isDisplayed = await gameBoard.isDisplayed();
      
      expect(isDisplayed).toBe(true);
    }
  });

  test('should handle touch events', async () => {
    await homePage.startGame();
    
    const gameCard = await driver.findElement(By.css('[data-testid="game-card"]'));
    
    // Simulate touch events
    await driver.executeScript('arguments[0].dispatchEvent(new TouchEvent("touchstart"))', gameCard);
    await driver.executeScript('arguments[0].dispatchEvent(new TouchEvent("touchend"))', gameCard);
    
    // Verify the card was interacted with
    const cardState = await gameCard.getAttribute('aria-pressed');
    expect(cardState).toBe('true');
  });

  test('should work offline', async () => {
    // Enable offline mode
    await driver.executeScript('window.navigator.onLine = false');
    await driver.executeScript('window.dispatchEvent(new Event("offline"))');
    
    // Try to perform game actions
    await homePage.startGame();
    
    // Verify game still functions
    const gameBoard = await driver.findElement(By.css('[data-testid="game-board"]'));
    expect(await gameBoard.isDisplayed()).toBe(true);
    
    // Re-enable online mode
    await driver.executeScript('window.navigator.onLine = true');
    await driver.executeScript('window.dispatchEvent(new Event("online"))');
  });

  test('should handle different color schemes', async () => {
    // Test light mode
    await driver.executeScript(
      'document.documentElement.setAttribute("data-theme", "light")'
    );
    let backgroundColor = await driver.executeScript(
      'return window.getComputedStyle(document.body).backgroundColor'
    );
    expect(backgroundColor).not.toBe('rgb(0, 0, 0)');

    // Test dark mode
    await driver.executeScript(
      'document.documentElement.setAttribute("data-theme", "dark")'
    );
    backgroundColor = await driver.executeScript(
      'return window.getComputedStyle(document.body).backgroundColor'
    );
    expect(backgroundColor).not.toBe('rgb(255, 255, 255)');
  });
});