import type { BuildOptions } from 'vite';

export const buildConfig: BuildOptions = {
  modulePreload: {
    polyfill: true
  },
  target: 'esnext',
  minify: 'terser',
  terserOptions: {
    compress: {
      drop_console: true,
      drop_debugger: true,
      pure_funcs: ['console.log', 'console.info', 'console.debug'],
      passes: 2
    }
  },
  rollupOptions: {
    output: {
      manualChunks: {
        'react-vendor': ['react', 'react-dom'],
        'router-vendor': ['react-router-dom'],
        'motion-vendor': ['framer-motion'],
        'state-vendor': ['zustand'],
        'game-logic': [
          './src/modules/game/store/gameStore.ts',
          './src/modules/game/utils/scoring.ts',
          './src/modules/game/utils/difficulty.ts'
        ],
        'ui-components': [
          './src/modules/ui/components/Button.tsx',
          './src/modules/ui/components/Card.tsx',
          './src/modules/ui/components/Badge.tsx'
        ],
        'analytics': [
          './src/modules/analytics/AnalyticsManager.ts',
          './src/modules/analytics/GoogleAnalytics.tsx',
          './src/modules/analytics/MicrosoftClarity.tsx'
        ]
      },
      assetFileNames: (assetInfo) => {
        const extType = assetInfo.name.split('.').at(1);
        if (/png|jpe?g|svg|gif|tiff|bmp|ico/i.test(extType)) {
          return `assets/images/[name]-[hash][extname]`;
        }
        if (/woff2?|ttf|otf|eot/i.test(extType)) {
          return `assets/fonts/[name]-[hash][extname]`;
        }
        return `assets/[name]-[hash][extname]`;
      },
      chunkFileNames: 'assets/js/[name]-[hash].js',
      entryFileNames: 'assets/js/[name]-[hash].js'
    }
  },
  sourcemap: false,
  cssCodeSplit: true,
  assetsInlineLimit: 4096,
  chunkSizeWarningLimit: 500,
  reportCompressedSize: false
};