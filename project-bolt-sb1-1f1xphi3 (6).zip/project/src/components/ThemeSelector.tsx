import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Palette } from 'lucide-react';
import { useTheme, ColorTheme } from '../modules/ui/hooks/useTheme';
import { cn } from '../modules/ui/utils/cn';

const themes: { id: ColorTheme; name: string; colors: { light: string; dark: string }; description: string }[] = [
  { 
    id: 'white', 
    name: 'Classic White', 
    colors: { light: '#F2F2F7', dark: '#1C1C1E' },
    description: 'Clean and minimal design'
  },
  { 
    id: 'blue', 
    name: 'Ocean Blue', 
    colors: { light: '#EFF6FF', dark: '#1E3A8A' },
    description: 'Calming and focused'
  },
  { 
    id: 'purple', 
    name: 'Royal Purple', 
    colors: { light: '#F5F3FF', dark: '#4C1D95' },
    description: 'Rich and elegant'
  },
  { 
    id: 'pink', 
    name: 'Soft Pink', 
    colors: { light: '#FDF2F8', dark: '#831843' },
    description: 'Warm and inviting'
  },
  { 
    id: 'orange', 
    name: 'Sunset Orange', 
    colors: { light: '#FFF7ED', dark: '#7C2D12' },
    description: 'Energetic and vibrant'
  },
];

export function ThemeSelector() {
  const { colorTheme, setColorTheme } = useTheme();
  const [isOpen, setIsOpen] = React.useState(false);
  const [isDark, setIsDark] = React.useState(() => 
    typeof window !== 'undefined' 
      ? window.matchMedia('(prefers-color-scheme: dark)').matches 
      : false
  );

  React.useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = (e: MediaQueryListEvent) => setIsDark(e.matches);
    
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, []);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="fixed bottom-4 right-4 z-50" 
    >
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className={cn(
            "w-12 h-12 rounded-full shadow-lg",
            "flex items-center justify-center",
            "transition-all duration-200 hover:scale-105",
            "bg-white/80 dark:bg-[#1C1C1E]/80",
            "backdrop-blur-md"
          )}
          aria-label="Change theme"
          aria-expanded={isOpen}
          aria-controls="theme-menu"
        >
          <Palette className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
        </button>

        <AnimatePresence>
          {isOpen && (
            <motion.div
              id="theme-menu"
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              transition={{ duration: 0.15 }}
              className="absolute bottom-full right-0 mb-2"
            >
              <div className={cn(
                "rounded-2xl shadow-xl p-4 min-w-[240px]",
                "bg-white/80 dark:bg-[#1C1C1E]/80",
                "backdrop-blur-md border border-white/20 dark:border-black/20"
              )}>
                <p className="text-sm text-gray-500 dark:text-gray-400 mb-3 font-medium">
                  Select Theme
                </p>
                <div className="space-y-2">
                  {themes.map((theme) => (
                    <button
                      key={theme.id}
                      onClick={() => {
                        setColorTheme(theme.id);
                        setIsOpen(false);
                      }}
                      className={cn(
                        "w-full flex items-center gap-3 px-3 py-2 rounded-xl",
                        "transition-all duration-200",
                        colorTheme === theme.id
                          ? "bg-system-blue/10 dark:bg-system-blue-dark/10"
                          : "hover:bg-black/5 dark:hover:bg-white/5"
                      )}
                    >
                      <div className="relative w-6 h-6 rounded-full border border-black/10 dark:border-white/10 overflow-hidden">
                        <div 
                          className="absolute inset-0"
                          style={{ 
                            backgroundColor: isDark ? theme.colors.dark : theme.colors.light
                          }}
                        />
                      </div>
                      <div className="flex flex-col items-start">
                        <span className={cn(
                          "text-sm font-medium",
                          colorTheme === theme.id
                            ? "text-system-blue dark:text-system-blue-dark"
                            : "text-gray-700 dark:text-gray-300"
                        )}>
                          {theme.name}
                        </span>
                        <span className="text-xs text-gray-500 dark:text-gray-400">
                          {theme.description}
                        </span>
                      </div>
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}