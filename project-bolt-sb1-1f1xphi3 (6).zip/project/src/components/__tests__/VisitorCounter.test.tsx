import React from 'react';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { VisitorCounter } from '../VisitorCounter';

describe('VisitorCounter', () => {
  it('renders visitor count correctly', () => {
    render(<VisitorCounter count={1000} />);
    expect(screen.getByText('1,000 playing')).toBeInTheDocument();
  });

  it('formats large numbers with commas', () => {
    render(<VisitorCounter count={1000000} />);
    expect(screen.getByText('1,000,000 playing')).toBeInTheDocument();
  });

  it('renders with purple badge variant', () => {
    render(<VisitorCounter count={100} />);
    const badge = screen.getByText('100 playing').closest('div');
    expect(badge).toHaveClass('bg-purple-100');
  });

  it('includes users icon', () => {
    render(<VisitorCounter count={100} />);
    const icon = document.querySelector('svg');
    expect(icon).toBeInTheDocument();
  });
});