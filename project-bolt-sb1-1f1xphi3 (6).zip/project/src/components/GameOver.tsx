import React from 'react';
import { motion } from 'framer-motion';
import { Trophy, Zap, RotateCcw, Share2, Star } from 'lucide-react';
import { Button } from '../modules/ui/components/Button';
import { RewardedAdButton } from './RewardedAdButton';
import { Card } from '../modules/ui/components/Card';
import { cn } from '../modules/ui/utils/cn';

type GameOverProps = {
  score: number;
  bestStreak: number;
  level: number;
  timeBonus: number;
  streakBonus: number;
  difficultyBonus: number;
  onRestart: () => void;
  onContinue: () => void;
};

export function GameOver({ 
  score, 
  bestStreak, 
  level,
  timeBonus,
  streakBonus,
  difficultyBonus,
  onRestart,
  onContinue
}: GameOverProps) {
  const shareScore = () => {
    const shareData = {
      title: 'Odd One Out Game',
      text: `🎮 I just scored ${score} points in Odd One Out!\n` +
        `🌟 Level ${level} | 🔥 ${bestStreak}x Streak\n` +
        `Can you beat my score?`,
      url: window.location.origin
    };

    // Try Web Share API first
    if (navigator.share && navigator.canShare?.(shareData)) {
      navigator.share(shareData).catch((error) => {
        if (error.name !== 'AbortError') {
          // Fall back to manual share options if sharing fails
          setShowShareOptions(true);
        }
      });
    } else {
      // Fall back to manual share options if Web Share API not available
      setShowShareOptions(true);
    }
  };

  const [showShareOptions, setShowShareOptions] = React.useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4 z-50"
    >
      <Card variant="elevated" className="max-w-md w-full">
        <div className="text-center mb-8">
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            className={cn(
              "w-16 h-16 mx-auto mb-4 rounded-2xl",
              "bg-gradient-to-br from-system-blue to-system-blue/80",
              "dark:from-system-blue-dark dark:to-system-blue-dark/80",
              "flex items-center justify-center"
            )}
          >
            <Trophy className="w-8 h-8 text-white" />
          </motion.div>
          <h2 className="text-3xl font-bold mb-2 dark:text-white">Game Over!</h2>
          <p className="text-system-gray-1 dark:text-system-gray-dark-1">
            Great effort! Here's how you did:
          </p>
        </div>

        <div className="space-y-4 mb-6">
          <div className={cn(
            "flex items-center justify-between p-3 rounded-xl",
            "bg-system-blue/10 dark:bg-system-blue-dark/10"
          )}>
            <div className="flex items-center gap-2">
              <Trophy className="w-5 h-5 text-system-blue dark:text-system-blue-dark" />
              <span className="font-medium dark:text-white">Final Score</span>
            </div>
            <span className="text-2xl font-bold text-system-blue dark:text-system-blue-dark">
              {score.toLocaleString()}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div className={cn(
              "p-2 rounded-xl text-center",
              "bg-system-green/10 dark:bg-system-green-dark/10"
            )}>
              <div className="text-xs text-system-green dark:text-system-green-dark mb-1">
                Time Bonus
              </div>
              <div className="font-bold text-system-green dark:text-system-green-dark">
                +{timeBonus}
              </div>
            </div>
            <div className={cn(
              "p-2 rounded-xl text-center",
              "bg-system-purple/10 dark:bg-system-purple-dark/10"
            )}>
              <div className="text-xs text-system-purple dark:text-system-purple-dark mb-1">
                Streak Bonus
              </div>
              <div className="font-bold text-system-purple dark:text-system-purple-dark">
                +{streakBonus}
              </div>
            </div>
            <div className={cn(
              "p-2 rounded-xl text-center",
              "bg-system-orange/10 dark:bg-system-orange-dark/10"
            )}>
              <div className="text-xs text-system-orange dark:text-system-orange-dark mb-1">
                Difficulty
              </div>
              <div className="font-bold text-system-orange dark:text-system-orange-dark">
                +{difficultyBonus}
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          <RewardedAdButton onReward={onContinue} />
          
          <Button variant="primary" onClick={onRestart}>
            <RotateCcw className="w-5 h-5 mr-2" />
            Play Again
          </Button>

          <Button 
            variant="secondary" 
            onClick={shareScore}
            aria-haspopup={showShareOptions ? 'true' : undefined}
          >
            <Share2 className="w-5 h-5 mr-2" />
            Share Score
          </Button>
          
          {showShareOptions && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="mt-4 grid grid-cols-2 sm:grid-cols-4 gap-3"
            >
              <Button
                variant="secondary"
                onClick={() => window.open(`https://twitter.com/intent/tweet?text=${encodeURIComponent(shareData.text)}&url=${encodeURIComponent(shareData.url)}`, '_blank')}
              >
                Twitter
              </Button>
              <Button
                variant="secondary"
                onClick={() => window.open(`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(shareData.url)}`, '_blank')}
              >
                Facebook
              </Button>
              <Button
                variant="secondary"
                onClick={() => window.open(`https://wa.me/?text=${encodeURIComponent(shareData.text + ' ' + shareData.url)}`, '_blank')}
              >
                WhatsApp
              </Button>
              <Button
                variant="secondary"
                onClick={() => window.open(`https://t.me/share/url?url=${encodeURIComponent(shareData.url)}&text=${encodeURIComponent(shareData.text)}`, '_blank')}
              >
                Telegram
              </Button>
            </motion.div>
          )}
        </div>
      </Card>
    </motion.div>
  );
}