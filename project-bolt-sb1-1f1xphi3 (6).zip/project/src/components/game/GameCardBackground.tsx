import React from 'react';
import { cn } from '../../modules/ui/utils/cn';

type GameCardBackgroundProps = {
  selected?: boolean;
};

export function GameCardBackground({ selected }: GameCardBackgroundProps) {
  return (
    <div className={cn(
      "absolute inset-0 rounded-2xl -z-0",
      "bg-gradient-to-br from-white to-[#F2F2F7]",
      "dark:from-[#1C1C1E] dark:to-[#2C2C2E]",
      "transition-all duration-300 ease-out will-change-transform",
      selected && "opacity-50"
    )} />
  );
}