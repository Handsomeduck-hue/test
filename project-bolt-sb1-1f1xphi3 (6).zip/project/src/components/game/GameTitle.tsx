import React from 'react';
import { motion } from 'framer-motion';
import { Brain } from 'lucide-react';
import { cn } from '../../modules/ui/utils/cn';

type GameTitleProps = {
  categoryName: string;
};

export function GameTitle({ categoryName }: GameTitleProps) {
  return (
    <motion.div
      initial={{ scale: 0.9 }}
      animate={{ scale: 1 }}
      className={cn(
        "inline-flex items-center gap-1.5 sm:gap-2",
        "px-2 py-1 sm:px-3 sm:py-1.5",
        "bg-system-blue/10 dark:bg-system-blue-dark/10",
        "rounded-full text-system-blue dark:text-system-blue-dark",
        "text-sm sm:text-base lg:text-lg font-medium mb-2",
        "touch-manipulation"
      )}
    >
      <Brain className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
      {categoryName}
    </motion.div>
  );
}