import React from 'react';
import { Check, X } from 'lucide-react';
import { cn } from '../../modules/ui/utils/cn';

type GameCardStatusProps = {
  correct?: boolean;
  incorrect?: boolean;
};

export function GameCardStatus({ correct, incorrect }: GameCardStatusProps) {
  if (!correct && !incorrect) return null;

  return (
    <div className={cn(
      'absolute top-2 sm:top-3 right-2 sm:right-3',
      'w-7 h-7 sm:w-9 sm:h-9 rounded-full',
      'flex items-center justify-center',
      'shadow-lg backdrop-blur-sm',
      'animate-pop-in transform-gpu',
      correct ? 'bg-system-green dark:bg-system-green-dark' : 'bg-system-red dark:bg-system-red-dark',
      'text-white'
    )}>
      {correct ? 
        <Check className="w-4 h-4 sm:w-5 sm:h-5" /> : 
        <X className="w-4 h-4 sm:w-5 sm:h-5" />
      }
    </div>
  );
}