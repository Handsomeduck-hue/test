import { logAdEvent } from './logging';
import { buildAdTagUrl } from './adTagBuilder';
import type { AdConfig } from '../types';

export const createAdsRequest = (adConfig: AdConfig, width: number, height: number) => {
  const adsRequest = new google.ima.AdsRequest();
  
  // Set dimensions
  adsRequest.linearAdSlotWidth = adConfig.adSize.width;
  adsRequest.linearAdSlotHeight = adConfig.adSize.height;
  adsRequest.nonLinearAdSlotWidth = adConfig.adSize.width;
  adsRequest.nonLinearAdSlotHeight = adConfig.adSize.height;
  
  // Set ad tag URL
  adsRequest.adTagUrl = buildAdTagUrl(adConfig);
  
  // Configure autoplay and audio
  if (adsRequest.setAdWillAutoPlay) {
    adsRequest.setAdWillAutoPlay(true);
  }
  if (adsRequest.setAdWillPlayMuted) {
    adsRequest.setAdWillPlayMuted(false); // Allow sound since user initiated
  }
  adsRequest.forceNonLinearFullSlot = true;

  // Log configuration
  logAdEvent('Ad request configuration', {
    width,
    height,
    adTagUrl: adsRequest.adTagUrl,
    autoplay: adsRequest.setAdWillAutoPlay ? true : 'unsupported',
    muted: adsRequest.setAdWillPlayMuted ? false : 'unsupported'
  });

  return adsRequest;
};