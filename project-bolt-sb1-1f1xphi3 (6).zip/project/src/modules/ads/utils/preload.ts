import { AD_PRELOAD_TIMEOUT, TEST_AD_TAG_URL } from '../constants';
import { logAdEvent, logAdError } from './debug';
import { checkAdEnvironment } from './debug';

export async function preloadAd(): Promise<any> {
  const envChecks = checkAdEnvironment();
  if (!envChecks.imaSDK || !envChecks.autoplay) {
    throw new Error('Required ad capabilities not available');
  }

  logAdEvent('Starting ad preload');
  
  return new Promise((resolve, reject) => {
    const timeoutId = setTimeout(() => {
      cleanup();
      reject(new Error('Ad preload timeout'));
    }, AD_PRELOAD_TIMEOUT);

    const container = document.createElement('div');
    container.style.position = 'absolute';
    container.style.left = '-9999px';
    container.style.top = '-9999px';
    document.body.appendChild(container);

    const videoElement = document.createElement('video');
    videoElement.muted = true;
    videoElement.playsInline = true;
    container.appendChild(videoElement);

    try {
      const adDisplayContainer = new google.ima.AdDisplayContainer(container, videoElement);
      const adsLoader = new google.ima.AdsLoader(adDisplayContainer);

      adsLoader.addEventListener(
        google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
        (event) => {
          clearTimeout(timeoutId);
          const adsManager = event.getAdsManager(videoElement);
          cleanup();
          resolve(adsManager);
        }
      );

      adsLoader.addEventListener(
        google.ima.AdErrorEvent.Type.AD_ERROR,
        (error) => {
          clearTimeout(timeoutId);
          cleanup();
          reject(error);
        }
      );

      const adsRequest = new google.ima.AdsRequest();
      adsRequest.adTagUrl = TEST_AD_TAG_URL;
      adsRequest.linearAdSlotWidth = 640;
      adsRequest.linearAdSlotHeight = 480;

      if (adsRequest.setAdWillAutoPlay) {
        adsRequest.setAdWillAutoPlay(true);
      }
      if (adsRequest.setAdWillPlayMuted) {
        adsRequest.setAdWillPlayMuted(true);
      }

      logAdEvent('Requesting ad preload', { adTagUrl: adsRequest.adTagUrl });
      adsLoader.requestAds(adsRequest);
    } catch (error) {
      clearTimeout(timeoutId);
      cleanup();
      reject(error);
    }

    function cleanup() {
      if (container.parentElement) {
        container.parentElement.removeChild(container);
      }
    }
  });
}