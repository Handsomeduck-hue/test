import { logAdEvent, logAdError } from './logging';
import { cleanupAdResources } from './cleanup';
import type { AdResources } from '../types';

const handleVideoError = (event: Event) => {
  const videoElement = event.target as HTMLVideoElement;
  logAdError(
    new Error(`Video error: ${videoElement.error?.message || 'Unknown error'}`),
    'Video playback error'
  );
};

export function setupAdEventHandlers(
  adsManager: any,
  videoElement: HTMLVideoElement,
  adResources: AdResources,
  onComplete: () => void,
  onError: (error: Error) => void
): void {
  // Add video element error handler
  videoElement.addEventListener('error', handleVideoError);

  // Basic ad lifecycle events
  adsManager.addEventListener(
    google.ima.AdEvent.Type.LOADED,
    () => logAdEvent('Ad loaded')
  );

  adsManager.addEventListener(
    google.ima.AdEvent.Type.STARTED,
    () => {
      logAdEvent('Ad started');
      if (videoElement) {
        videoElement.muted = false;
      }
    }
  );

  // Progress events
  adsManager.addEventListener(
    google.ima.AdEvent.Type.FIRST_QUARTILE,
    () => logAdEvent('Ad first quartile')
  );

  adsManager.addEventListener(
    google.ima.AdEvent.Type.MIDPOINT,
    () => logAdEvent('Ad midpoint')
  );

  adsManager.addEventListener(
    google.ima.AdEvent.Type.THIRD_QUARTILE,
    () => logAdEvent('Ad third quartile')
  );

  // Completion events
  adsManager.addEventListener(
    google.ima.AdEvent.Type.COMPLETE,
    () => {
      logAdEvent('Ad completed');
      cleanupAdResources(adResources);
      onComplete();
    }
  );

  adsManager.addEventListener(
    google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
    () => {
      logAdEvent('All ads completed');
      cleanupAdResources(adResources);
      onComplete();
    }
  );

  // User interaction events
  adsManager.addEventListener(
    google.ima.AdEvent.Type.CLICK,
    () => logAdEvent('Ad clicked')
  );

  adsManager.addEventListener(
    google.ima.AdEvent.Type.SKIPPED,
    () => logAdEvent('Ad skipped')
  );

  // Error handling
  adsManager.addEventListener(
    google.ima.AdErrorEvent.Type.AD_ERROR,
    (error: any) => {
      logAdError(error, 'Ad playback error');
      cleanupAdResources(adResources);
      onError(new Error(error.getError().getMessage()));
    }
  );
}