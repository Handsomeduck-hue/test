import { AD_ERROR_MESSAGES } from '../constants';
import { logAdEvent } from './logging';
import type { NetworkStatus, NetworkInfo } from '../types';

export const getNetworkInfo = (): NetworkInfo => {
  return {
    online: navigator.onLine,
    connectionType: (navigator as any).connection?.type,
    effectiveType: (navigator as any).connection?.effectiveType,
    downlink: (navigator as any).connection?.downlink,
    rtt: (navigator as any).connection?.rtt
  };
};

export const checkNetworkConditions = (): NetworkStatus => {
  const errors: string[] = [];
  const details = getNetworkInfo();

  logAdEvent('Network conditions check', details);

  if (!navigator.onLine) {
    errors.push(AD_ERROR_MESSAGES.NETWORK);
  }

  // Check for slow connections
  if (details.effectiveType === 'slow-2g' || details.effectiveType === '2g') {
    errors.push(AD_ERROR_MESSAGES.SLOW_NETWORK);
  }

  // Check minimum bandwidth requirement (1.5 Mbps)
  if (details.downlink && details.downlink < 1.5) {
    errors.push(AD_ERROR_MESSAGES.SLOW_NETWORK);
  }

  return {
    isValid: errors.length === 0,
    errors,
    details
  };
}