import { logAdEvent } from './logging';

export function createVideoElement(): HTMLVideoElement {
  const video = document.createElement('video');
  
  // Critical video element properties
  video.muted = true;
  video.playsInline = true;
  video.autoplay = true;
  
  // iOS/Safari support
  video.setAttribute('playsinline', '');
  video.setAttribute('webkit-playsinline', '');
  video.setAttribute('x-webkit-airplay', 'deny');
  video.setAttribute('disablePictureInPicture', '');
  video.setAttribute('controlsList', 'nodownload nofullscreen noremoteplayback');
  
  // Styling
  Object.assign(video.style, {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: '100%',
    height: '100%',
    maxWidth: '640px',
    maxHeight: '360px',
    backgroundColor: '#000',
    zIndex: '1'
  });

  logAdEvent('Video element created', {
    muted: video.muted,
    autoplay: video.autoplay,
    playsInline: video.playsInline,
    preload: video.preload,
    controls: video.controls
  });

  return video;
}

export function calculateVideoDimensions(containerWidth: number): { width: number; height: number } {
  const maxWidth = Math.min(containerWidth - 32, 640);
  const width = maxWidth;
  const height = Math.round(width * (9/16)); // Maintain 16:9 aspect ratio
  
  return { width, height };
}