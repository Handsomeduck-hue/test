import { ADSENSE_CLIENT_ID } from '../constants';
import { logAdEvent, logAdError } from './logging';

const MAX_RETRIES = 3;
const RETRY_DELAY = 5000;

async function waitForIMA(timeout = 10000): Promise<void> {
  return new Promise((resolve, reject) => {
    if (window.google?.ima?.AdsLoader) {
      resolve();
      return;
    }

    const start = Date.now();
    const interval = setInterval(() => {
      if (window.google?.ima?.AdsLoader) {
        clearInterval(interval);
        resolve();
      } else if (Date.now() - start > timeout) {
        clearInterval(interval);
        reject(new Error('IMA SDK did not initialize in time'));
      }
    }, 100);
  });
}

export const loadIMAScript = async (): Promise<void> => {
  if (window.google?.ima) {
    logAdEvent('IMA SDK already loaded');
    return;
  }
  
  let retryCount = 0;
  const loadScript = async (): Promise<void> => {
    if (retryCount >= MAX_RETRIES) {
      throw new Error('Failed to load IMA SDK after maximum retries');
    }

    const script = document.createElement('script');
    script.src = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';
    script.async = true;
    
    return new Promise<void>((resolve, reject) => {
      script.onload = () => {
        if (window.google?.ima?.AdsLoader) {
          logAdEvent('IMA SDK loaded successfully');
          resolve();
        } else {
          const error = new Error('IMA SDK loaded but required classes are missing');
          logAdError(error, 'IMA SDK load error');
          reject(error);
        }
      };
      
      script.onerror = () => {
        const error = new Error('Failed to load IMA SDK');
        logAdError(error, 'IMA SDK load error');
        reject(error);
      };
      
      document.head.appendChild(script);
    });
  };
  
  try {
    return await loadScript();
  } catch (error) {
    logAdError(error, `IMA SDK loading failed. Attempt ${retryCount + 1} of ${MAX_RETRIES}`);
    retryCount++;
    
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve(loadIMAScript());
      }, RETRY_DELAY);
    });
  }
};

export const loadAdSenseScript = async (): Promise<void> => {
  // Check for existing AdSense script more reliably
  if (document.querySelector('script[src*="pagead2.googlesyndication.com"]')) {
    logAdEvent('AdSense script already loaded');
    return;
  }

  // Check if AdSense is already initialized
  if (window.adsbygoogle) {
    logAdEvent('AdSense already initialized');
    return;
  }

  logAdEvent('Loading AdSense script');
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js';
    script.crossOrigin = 'anonymous';
    script.dataset.adClient = ADSENSE_CLIENT_ID;

    // Add error handling for multiple property codes
    window.adsbygoogle = window.adsbygoogle || [];
    window.adsbygoogle.push({
      google_ad_client: ADSENSE_CLIENT_ID,
      enable_page_level_ads: true
    });

    script.onload = () => {
      logAdEvent('AdSense script loaded successfully');
      resolve();
    };

    script.onerror = (e) => {
      logAdError(e, 'Error loading AdSense script');
      reject(new Error(`Failed to load AdSense script: ${e.message}`));
    };

    document.head.appendChild(script);
  });
};