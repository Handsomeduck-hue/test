import { logAdError } from './logging';

export function validateVisibility(): boolean {
  // Don't check visibility during initialization
  if (document.hidden && window.location.protocol === 'https:') {
    logAdError(new Error('Document hidden'), 'Ad validation failed - Document not visible');
    return false;
  }
  return true;
}

export function isTabVisible(): boolean {
  return !document.hidden;
}

export function setupVisibilityTracking(callback: (isVisible: boolean) => void): () => void {
  const handler = () => callback(!document.hidden);
  document.addEventListener('visibilitychange', handler);
  return () => document.removeEventListener('visibilitychange', handler);
}