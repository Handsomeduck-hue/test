import { 
  AD_ERROR_MESSAGES, 
  NETWORK_TIMEOUT,
  AD_SERVER_TIMEOUT,
  TEST_AD_TAG_URL,
  MIN_BANDWIDTH
} from '../constants';
import { logAdEvent, logAdError } from './logging';
import type { NetworkStatus, NetworkInfo } from '../types';

const checkBandwidth = (): boolean => {
  const connection = (navigator as any).connection;
  if (!connection) return true; // If Connection API not available, assume sufficient bandwidth
  
  const downlink = connection.downlink * 1000; // Convert to Kbps
  return downlink >= MIN_BANDWIDTH;
};

export const checkNetworkConnectivity = async (): Promise<boolean> => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), NETWORK_TIMEOUT);

    try {
      const endpoints = [
        'https://www.google.com/generate_204',
        'https://www.cloudflare.com/cdn-cgi/trace',
        'https://www.apple.com/library/test/success.html'
      ];

      // Try each endpoint until one succeeds
      for (const endpoint of endpoints) {
        try {
          const response = await fetch(endpoint, {
            mode: 'no-cors',
            cache: 'no-cache',
            credentials: 'omit',
            signal: controller.signal
          });

          if (response.type === 'opaque') {
            return true;
          }
        } catch {
          continue;
        }
      }
      return false;
    } finally {
      clearTimeout(timeoutId);
    }
  } catch (error) {
    logAdError(error, 'Network connectivity check failed');
    return false;
  }
};

export const checkAdServerConnectivity = async (): Promise<boolean> => {
  try {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), AD_SERVER_TIMEOUT);

    try {
      const response = await fetch(TEST_AD_TAG_URL, {
        mode: 'no-cors',
        cache: 'no-cache',
        credentials: 'omit',
        signal: controller.signal
      });

      const isConnected = response.type === 'opaque';
      logAdEvent('Ad server connectivity check', {
        success: isConnected,
        url: TEST_AD_TAG_URL
      });

      return isConnected;
    } finally {
      clearTimeout(timeoutId);
    }
  } catch (error) {
    logAdError(error, 'Ad server connectivity check failed');
    return false;
  }
};

export const validateNetworkForAds = async (): Promise<NetworkStatus> => {
  const errors: string[] = [];
  const networkInfo = {
    online: navigator.onLine,
    connectionType: (navigator as any).connection?.type,
    effectiveType: (navigator as any).connection?.effectiveType,
    downlink: (navigator as any).connection?.downlink,
    rtt: (navigator as any).connection?.rtt
  };

  logAdEvent('Starting network validation', {
    ...networkInfo,
    userAgent: navigator.userAgent,
    https: window.location.protocol === 'https:',
    host: window.location.hostname
  });

  if (!networkInfo.online) {
    errors.push(AD_ERROR_MESSAGES.OFFLINE);
    logAdError(new Error('Device is offline'), 'Network validation failed - Offline status');
    return { isValid: false, errors };
  }

  if (!checkBandwidth()) {
    errors.push(AD_ERROR_MESSAGES.SLOW_NETWORK);
    logAdError(
      new Error(`Insufficient bandwidth: ${networkInfo.downlink} Mbps`),
      'Network validation failed - Low bandwidth'
    );
    return { isValid: false, errors };
  }

  try {
    const hasAdServerAccess = await checkAdServerConnectivity();
    if (!hasAdServerAccess) {
      errors.push(AD_ERROR_MESSAGES.AD_SERVER);
      logAdError(new Error('Cannot reach ad server'), 'Network validation failed - No ad server access');
      return { isValid: false, errors };
    }
  } catch (error) {
    logAdError(error, 'Ad server connectivity check failed');
    errors.push(AD_ERROR_MESSAGES.AD_SERVER);
    return { isValid: false, errors };
  }

  logAdEvent('Network validation successful', {
    effectiveType: networkInfo.effectiveType,
    downlink: networkInfo.downlink,
    rtt: networkInfo.rtt
  });

  return { isValid: true, errors: [], details: networkInfo };
};