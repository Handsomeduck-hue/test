import { AdConfig } from '../types';
import { VIDEO_AD_CLIENT } from '../constants';
import { logAdEvent } from './logging';

export function buildAdTagUrl(config: AdConfig): string {
  const baseUrl = 'https://pubads.g.doubleclick.net/gampad/ads?';
  const params = new URLSearchParams({
    iu: config.adUnit,
    description_url: encodeURIComponent(window.location.href),
    env: 'vp',
    gdfp_req: '1',
    unviewed_position_start: '1',
    output: 'vast',
    sz: `${config.adSize.width}x${config.adSize.height}`,
    url: window.location.href,
    correlator: Date.now().toString(),
    client: VIDEO_AD_CLIENT
  });

  // Add targeting parameters
  Object.entries(config.targeting || {}).forEach(([key, value]) => {
    params.append(`cust_params[${key}]`, value.toString());
  });

  const finalUrl = `${baseUrl}${params.toString()}`;
  logAdEvent('Built ad tag URL', { url: finalUrl });
  
  return finalUrl;
}