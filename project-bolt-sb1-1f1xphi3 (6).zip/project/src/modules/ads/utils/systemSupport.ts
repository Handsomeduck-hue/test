import { logAdEvent } from './logging';

export function checkSystemResources() {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check memory usage if available
  if (performance && 'memory' in performance) {
    const memory = (performance as any).memory;
    const usedMemoryPercent = (memory.usedJSHeapSize / memory.jsHeapSizeLimit) * 100;
    
    if (usedMemoryPercent > 90) {
      errors.push('Insufficient memory available');
    } else if (usedMemoryPercent > 70) {
      warnings.push('Low memory available');
    }
  }

  // Check device performance
  const startTime = performance.now();
  let counter = 0;
  for (let i = 0; i < 10000; i++) {
    counter++;
  }
  const endTime = performance.now();
  const performanceTime = endTime - startTime;

  if (performanceTime > 50) {
    warnings.push('Device performance may be insufficient');
  }

  // Check battery status if available
  if ('getBattery' in navigator) {
    (navigator as any).getBattery().then((battery: any) => {
      if (battery.level < 0.15 && !battery.charging) {
        warnings.push('Low battery may affect video playback');
      }
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    warnings
  };
}