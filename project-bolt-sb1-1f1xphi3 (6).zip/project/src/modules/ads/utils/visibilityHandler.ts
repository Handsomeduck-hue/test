import { logAdEvent, logAdError } from './logging';
import type { AdResources } from '../types';

export const createVisibilityHandler = (adResources: AdResources) => {
  const handleVisibilityChange = () => {
    if (document.hidden) {
      if (adResources.adsManager) {
        logAdEvent('Tab hidden - pausing ad');
        try {
          adResources.adsManager.pause();
        } catch (e) {
          logAdError(e, 'Error pausing ad on visibility change');
        }
      }
    } else {
      if (adResources.adsManager) {
        logAdEvent('Tab visible - resuming ad');
        try {
          adResources.adsManager.resume();
        } catch (e) {
          logAdError(e, 'Error resuming ad on visibility change');
        }
      }
    }
  };

  document.addEventListener('visibilitychange', handleVisibilityChange);
  return handleVisibilityChange;
};