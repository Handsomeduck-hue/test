import { logAdEvent } from './logging';

export function checkVideoSupport() {
  const video = document.createElement('video');
  const details = {
    videoElement: !!video.canPlayType,
    h264: video.canPlayType('video/mp4; codecs="avc1.42E01E,mp4a.40.2"') !== "",
    webm: video.canPlayType('video/webm; codecs="vp8,vorbis"') !== "",
    autoplay: 'autoplay' in video,
    playsInline: 'playsInline' in video,
    mediaCapabilities: 'mediaCapabilities' in navigator
  };

  logAdEvent('Video support check', details);

  return {
    supported: details.videoElement && (details.h264 || details.webm),
    details
  };
}