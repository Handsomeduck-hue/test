import { logAdEvent, logAdError } from './logging';
import { ADSENSE_CLIENT_ID } from '../constants';

export async function loadIMAScript(): Promise<void> {
  if (window.google?.ima) {
    logAdEvent('IMA SDK already loaded');
    return;
  }
  
  logAdEvent('Loading IMA SDK');
  const scriptPromise = new Promise<void>((resolve, reject) => {
    const script = document.createElement('script');
    script.src = 'https://imasdk.googleapis.com/js/sdkloader/ima3.js';
    script.async = true;
    script.onload = () => {
      if (window.google?.ima?.AdsLoader) {
        logAdEvent('IMA SDK loaded successfully');
        resolve();
      } else {
        const error = new Error('IMA SDK loaded but required classes are missing');
        logAdError(error, 'IMA SDK load error');
        reject(error);
      }
    };
    script.onerror = () => {
      const error = new Error('Failed to load IMA SDK');
      logAdError(error, 'IMA SDK load error');
      reject(error);
    };
    document.head.appendChild(script);
  });

  const timeoutPromise = new Promise<void>((_, reject) => {
    setTimeout(() => {
      const error = new Error('IMA SDK load timeout');
      logAdError(error, 'IMA SDK load error');
      reject(error);
    }, 10000);
  });

  return Promise.race([scriptPromise, timeoutPromise]);
}

export async function loadAdSenseScript(): Promise<void> {
  const existingScript = document.querySelector(
    `script[src*="pagead2.googlesyndication.com"][data-ad-client="${ADSENSE_CLIENT_ID}"]`
  );
  
  if (existingScript) {
    logAdEvent('AdSense script already loaded');
    return;
  }

  logAdEvent('Loading AdSense script');
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.async = true;
    script.src = `https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${ADSENSE_CLIENT_ID}`;
    script.crossOrigin = 'anonymous';
    script.dataset.adClient = ADSENSE_CLIENT_ID;
    
    script.onload = () => {
      logAdEvent('AdSense script loaded successfully');
      resolve();
    };
    
    script.onerror = (e) => {
      const error = new Error(`Failed to load AdSense script: ${e.message}`);
      logAdError(error, 'AdSense script load error');
      reject(error);
    };
    
    document.head.appendChild(script);
  });
}