import { logAdEvent } from './logging';

export function createAdContainer(id: string): HTMLDivElement {
  const adContainer = document.createElement('div');
  adContainer.id = id;
  adContainer.style.cssText = `
    position: fixed;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    z-index: 9999;
    background: rgba(0, 0, 0, 0.8);
    width: 640px;
    height: 480px;
  `;

  // Add overlay container for better visibility
  const overlay = document.createElement('div');
  overlay.style.cssText = `
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: rgba(0, 0, 0, 0.8);
    z-index: 9998;
  `;
  document.body.appendChild(overlay);

  // Store overlay reference for cleanup
  adContainer.dataset.overlay = overlay.id = `${id}-overlay`;
  
  logAdEvent('Ad container created', {
    id,
    dimensions: {
      width: adContainer.style.width,
      height: adContainer.style.height
    }
  });

  return adContainer;
}