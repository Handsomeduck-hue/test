// Timing constants
export const COOLDOWN_PERIOD = 5 * 60 * 1000;  // 5 minutes

// Timeout constants
export const AD_TIMEOUT = 45000;          // 45 second timeout for overall ad operations
export const AD_LOAD_TIMEOUT = 30000;     // 30 second timeout for initial ad load
export const AD_SERVER_TIMEOUT = 10000;   // 10 second timeout for ad server requests
export const NETWORK_TIMEOUT = 8000;      // 8 second timeout for network checks
export const AD_RETRY_ATTEMPTS = 3;       // Number of retry attempts
export const AD_RETRY_DELAY = 5000;       // 5 second delay between retries
export const AD_PRELOAD_TIMEOUT = 15000;  // Timeout for ad preloading

// Network requirements
export const MIN_BANDWIDTH = 1500;        // 1.5 Mbps minimum for video
export const MIN_RTT = 150;               // Maximum round trip time in ms

// Container identifiers
export const AD_CONTAINER_ID = 'ad-container';

// Ad credentials
export const VIDEO_AD_CLIENT = 'ca-video-pub-1276418176853020';
export const ADMOB_APP_ID = 'ca-app-pub-1276418176853020';
export const ADSENSE_CLIENT_ID = 'ca-pub-3940256099942544'; // Test AdSense client ID
export const REWARDED_AD_UNIT_ID = 'ca-video-pub-1276418176853020/8691691433';

// Test ad configuration
export const TEST_AD_TAG_URL = 'https://pubads.g.doubleclick.net/gampad/ads?' +
  'iu=/21775744923/external/single_preroll_skippable&' +
  'sz=640x480&' +
  'ciu_szs=300x250%2C728x90&' +
  'gdfp_req=1&' +
  'output=vast&' +
  'unviewed_position_start=1&' +
  'env=vp&' +
  'impl=s&' +
  'correlator=' + Date.now() +
  '&description_url=' + encodeURIComponent(window.location.href);

// Error messages
export const AD_ERROR_MESSAGES = {
  TIMEOUT: 'Ad request timed out. Please check your connection and try again.',
  NETWORK: 'Unable to load ad due to network issues. Please check your connection.',
  SLOW_NETWORK: 'Your network connection is too slow for video ads. Please try again with a better connection.',
  BLOCKED: 'Ad blocker detected. Please disable it to watch ads.',
  INIT: 'Failed to initialize ad services. Please refresh the page.',
  GENERIC: 'Unable to load ad. Please try again.',
  PLAYBACK: 'Video playback failed. Please try again.',
  UNSUPPORTED: 'Video ads are not supported on this device.',
  OFFLINE: 'You appear to be offline. Please check your internet connection.',
  AD_SERVER: 'Cannot reach ad server. Please check your connection and try again.',
  CONNECTION_ERROR: 'Connection error occurred. Please check your network and try again.',
  VISIBILITY: 'Please keep the tab active while watching ads',
  SECURE_CONTEXT: 'Secure context required for video playback'
};

// Container styles
export const AD_CONTAINER_STYLES = {
  position: 'fixed',
  zIndex: '9999',
  top: '0',
  left: '0',
  width: '100%',
  height: '100%',
  background: 'rgba(0,0,0,0.8)',
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center'
} as const;