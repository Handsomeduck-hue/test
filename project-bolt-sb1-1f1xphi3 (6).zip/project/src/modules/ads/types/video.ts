export interface VideoAdConfig {
  imaConfig: {
    adTagUrl: string;
    adDisplayContainer: {
      width: number;
      height: number;
      maxWidth: string;
      aspectRatio: string;
    };
  };
  videoConfig: {
    muted: boolean;
    playsInline: boolean;
    controls: boolean;
    autoplay: boolean;
    style: {
      width: string;
      height: string;
      maxWidth: string;
      maxHeight: string;
      backgroundColor: string;
    };
    attributes: Record<string, string>;
  };
  containerConfig: {
    style: {
      position: string;
      zIndex: string;
      top: string;
      left: string;
      width: string;
      height: string;
      backgroundColor: string;
      display: string;
      alignItems: string;
      justifyContent: string;
    };
  };
}

export interface VideoAdResult {
  success: boolean;
  error?: string;
  revenue?: number;
}