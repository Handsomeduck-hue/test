import type { VideoAdConfig } from '../types';

export const videoAdConfig: VideoAdConfig = {
  // IMA SDK Configuration
  imaConfig: {
    adTagUrl: 'https://pubads.g.doubleclick.net/gampad/ads?' +
      'iu=/21775744923/external/single_preroll_skippable&' +
      'sz=640x480&' +
      'ciu_szs=300x250%2C728x90&' +
      'gdfp_req=1&' +
      'output=vast&' +
      'unviewed_position_start=1&' +
      'env=vp&' +
      'impl=s&' +
      'correlator=' + Date.now(),
    adDisplayContainer: {
      width: 640,
      height: 480,
      maxWidth: '100%',
      aspectRatio: '16:9'
    }
  },

  // Video Element Configuration  
  videoConfig: {
    muted: true,
    playsInline: true,
    controls: false,
    autoplay: true,
    style: {
      width: '100%',
      height: '100%',
      maxWidth: '640px',
      maxHeight: '480px',
      backgroundColor: '#000'
    },
    attributes: {
      'playsinline': '',
      'webkit-playsinline': '',
      'x-webkit-airplay': 'deny',
      'disablePictureInPicture': '',
      'controlsList': 'nodownload nofullscreen noremoteplayback'
    }
  },

  // Container Configuration
  containerConfig: {
    style: {
      position: 'fixed',
      zIndex: '9999',
      top: '0',
      left: '0',
      width: '100%',
      height: '100%',
      backgroundColor: 'rgba(0, 0, 0, 0.95)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }
};