import { AdConfig } from '../types';

export const adConfig: AdConfig = {
  adUnit: '/6499/example/rewarded',  // Use rewarded video ad unit
  adSize: {
    width: 640,
    height: 480
  },
  targeting: {
    test: 'true',
    rewarded: 'true',
    position: 'fullscreen'
  },
  testMode: process.env.NODE_ENV !== 'production',
  timeout: 45000, // Increase timeout for slower connections
  retryAttempts: 2,
  retryDelay: 2000
};