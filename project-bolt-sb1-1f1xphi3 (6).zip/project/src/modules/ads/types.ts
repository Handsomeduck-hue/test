declare global {
  interface Window {
    google?: any;
    gtag?: (...args: any[]) => void;
    adsbygoogle?: any[];
  }
}

export interface NetworkInfo {
  online: boolean;
  connectionType?: string;
  effectiveType?: string;
  downlink?: number;
  rtt?: number;
}

export interface NetworkStatus {
  isValid: boolean;
  errors: string[];
  details?: NetworkInfo;
}