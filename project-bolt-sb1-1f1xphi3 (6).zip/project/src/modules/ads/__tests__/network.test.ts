import { describe, it, expect, vi, beforeEach } from 'vitest';
import { validateNetworkForAds, checkNetworkConnectivity, checkAdServerConnectivity } from '../utils/network';
import { AD_ERROR_MESSAGES } from '../constants';

describe('Network Utils', () => {
  beforeEach(() => {
    global.fetch = vi.fn();
    Object.defineProperty(navigator, 'onLine', {
      configurable: true,
      value: true
    });
  });

  describe('validateNetworkForAds', () => {
    it('should validate successfully with good connection', async () => {
      (global.fetch as any).mockImplementation(() => 
        Promise.resolve({ type: 'opaque', status: 204 })
      );

      const result = await validateNetworkForAds();
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('should fail validation when offline', async () => {
      Object.defineProperty(navigator, 'onLine', {
        value: false
      });

      const result = await validateNetworkForAds();
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain(AD_ERROR_MESSAGES.OFFLINE);
    });

    it('should handle ad server timeout', async () => {
      (global.fetch as any).mockImplementation(() => 
        new Promise(resolve => setTimeout(resolve, 6000))
      );

      const result = await validateNetworkForAds();
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain(AD_ERROR_MESSAGES.AD_SERVER);
    });
  });

  describe('checkNetworkConnectivity', () => {
    it('should return true for successful connection', async () => {
      (global.fetch as any).mockImplementation(() => 
        Promise.resolve({ type: 'opaque', status: 204 })
      );

      const result = await checkNetworkConnectivity();
      expect(result).toBe(true);
    });

    it('should return false for failed connection', async () => {
      (global.fetch as any).mockImplementation(() => 
        Promise.reject(new Error('Network error'))
      );

      const result = await checkNetworkConnectivity();
      expect(result).toBe(false);
    });
  });

  describe('checkAdServerConnectivity', () => {
    it('should return true when ad server is accessible', async () => {
      (global.fetch as any).mockImplementation(() => 
        Promise.resolve({ type: 'opaque' })
      );

      const result = await checkAdServerConnectivity();
      expect(result).toBe(true);
    });

    it('should return false when ad server is inaccessible', async () => {
      (global.fetch as any).mockImplementation(() => 
        Promise.reject(new Error('Server error'))
      );

      const result = await checkAdServerConnectivity();
      expect(result).toBe(false);
    });
  });
});