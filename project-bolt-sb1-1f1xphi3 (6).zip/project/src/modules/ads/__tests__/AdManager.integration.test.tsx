import React from 'react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { useAdStore } from '../AdManager';
import { RewardedAdButton } from '../components/RewardedAdButton';

describe('Ad Integration Tests', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    // Reset mock IMA SDK
    window.google = {
      ima: {
        AdDisplayContainer: vi.fn(() => ({
          initialize: vi.fn(),
          destroy: vi.fn()
        })),
        AdsLoader: vi.fn(() => ({
          addEventListener: vi.fn(),
          requestAds: vi.fn(),
          destroy: vi.fn()
        })),
        AdsRequest: vi.fn(() => ({
          setAdWillAutoPlay: vi.fn(),
          setAdWillPlayMuted: vi.fn()
        })),
        AdsManagerLoadedEvent: {
          Type: { ADS_MANAGER_LOADED: 'adsManagerLoaded' }
        },
        AdEvent: {
          Type: {
            STARTED: 'start',
            COMPLETE: 'complete',
            ALL_ADS_COMPLETED: 'allAdsCompleted'
          }
        },
        AdErrorEvent: {
          Type: { AD_ERROR: 'adError' }
        },
        ViewMode: {
          NORMAL: 'normal'
        }
      }
    };
  });

  it('completes full ad flow successfully', async () => {
    const onReward = vi.fn();
    
    render(<RewardedAdButton onReward={onReward} />);
    
    // Click watch ad button
    fireEvent.click(screen.getByText('Watch Ad for Extra Life'));
    
    // Verify loading state
    expect(screen.getByText('Loading Video...')).toBeInTheDocument();
    
    // Simulate successful ad load
    await waitFor(() => {
      expect(window.google.ima.AdsLoader).toHaveBeenCalled();
    });
    
    // Verify reward callback
    await waitFor(() => {
      expect(onReward).toHaveBeenCalled();
    });
  });

  it('handles ad load failure gracefully', async () => {
    // Mock ad loader to fail
    window.google.ima.AdsLoader = vi.fn(() => ({
      addEventListener: (event: string, handler: Function) => {
        if (event === 'adError') {
          handler({ getError: () => ({ getMessage: () => 'Ad failed to load' }) });
        }
      },
      requestAds: vi.fn()
    }));
    
    const onReward = vi.fn();
    render(<RewardedAdButton onReward={onReward} />);
    
    fireEvent.click(screen.getByText('Watch Ad for Extra Life'));
    
    await waitFor(() => {
      expect(screen.getByText('Ad failed to load')).toBeInTheDocument();
      expect(onReward).not.toHaveBeenCalled();
    });
  });

  it('enforces cooldown period between ads', async () => {
    const onReward = vi.fn();
    const { rerender } = render(<RewardedAdButton onReward={onReward} />);
    
    // Watch first ad
    fireEvent.click(screen.getByText('Watch Ad for Extra Life'));
    await waitFor(() => expect(onReward).toHaveBeenCalled());
    
    // Try to watch another ad immediately
    rerender(<RewardedAdButton onReward={onReward} />);
    
    expect(screen.getByRole('button')).toBeDisabled();
    expect(screen.getByText(/Wait/)).toBeInTheDocument();
  });

  it('cleans up ad resources after completion', async () => {
    const mockDestroy = vi.fn();
    const mockAdsManager = {
      destroy: mockDestroy,
      addEventListener: vi.fn(),
      init: vi.fn(),
      start: vi.fn()
    };

    window.google.ima.AdsLoader = vi.fn(() => ({
      addEventListener: (event: string, handler: Function) => {
        if (event === 'adsManagerLoaded') {
          handler({ getAdsManager: () => mockAdsManager });
        }
      },
      requestAds: vi.fn(),
      destroy: vi.fn()
    }));

    const onReward = vi.fn();
    render(<RewardedAdButton onReward={onReward} />);
    
    fireEvent.click(screen.getByText('Watch Ad for Extra Life'));
    
    await waitFor(() => {
      expect(mockDestroy).toHaveBeenCalled();
    });
  });
});