import { describe, it, expect, vi } from 'vitest';
import { validateAdRequirements, checkNetworkConditions, checkSystemResources } from '../utils/validation';
import { cleanupAdResources } from '../utils/cleanup';
import { retryWithBackoff } from '../utils/retry';

describe('Ad Utility Functions', () => {
  describe('validateAdRequirements', () => {
    it('validates successfully with all requirements met', () => {
      // Mock required conditions
      Object.defineProperty(document, 'hidden', { value: false });
      Object.defineProperty(window, 'isSecureContext', { value: true });
      window.google = { ima: {} };

      const result = validateAdRequirements();
      expect(result.isValid).toBe(true);
      expect(result.errors).toHaveLength(0);
    });

    it('fails validation with missing requirements', () => {
      // Mock missing IMA SDK
      window.google = undefined;

      const result = validateAdRequirements();
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Google IMA SDK not loaded');
    });
  });

  describe('checkNetworkConditions', () => {
    it('passes with good connection', () => {
      Object.defineProperty(navigator, 'onLine', { value: true });
      Object.defineProperty(navigator, 'connection', {
        value: { effectiveType: '4g', downlink: 10 }
      });

      const result = checkNetworkConditions();
      expect(result.isValid).toBe(true);
    });

    it('fails with poor connection', () => {
      Object.defineProperty(navigator, 'connection', {
        value: { effectiveType: '2g', downlink: 0.5 }
      });

      const result = checkNetworkConditions();
      expect(result.isValid).toBe(false);
      expect(result.errors).toContain('Network connection too slow');
    });
  });

  describe('checkSystemResources', () => {
    it('passes with sufficient resources', () => {
      const result = checkSystemResources();
      expect(result.isValid).toBe(true);
    });

    it('warns with low memory', () => {
      // Mock low memory condition
      Object.defineProperty(performance, 'memory', {
        value: {
          jsHeapSizeLimit: 2000000000,
          totalJSHeapSize: 1900000000,
          usedJSHeapSize: 1800000000
        }
      });

      const result = checkSystemResources();
      expect(result.warnings).toContain('Low memory available');
    });
  });

  describe('cleanupAdResources', () => {
    it('cleans up all ad-related resources', () => {
      const mockResources = {
        container: document.createElement('div'),
        adDisplayContainer: { destroy: vi.fn() },
        adsLoader: { destroy: vi.fn() },
        adsManager: { destroy: vi.fn() },
        videoElement: document.createElement('video'),
        visibilityHandler: vi.fn()
      };

      document.body.appendChild(mockResources.container);
      document.addEventListener('visibilitychange', mockResources.visibilityHandler);

      cleanupAdResources(mockResources);

      expect(mockResources.adDisplayContainer.destroy).toHaveBeenCalled();
      expect(mockResources.adsLoader.destroy).toHaveBeenCalled();
      expect(mockResources.adsManager.destroy).toHaveBeenCalled();
      expect(document.body.contains(mockResources.container)).toBe(false);
    });
  });

  describe('retryWithBackoff', () => {
    it('succeeds after retries', async () => {
      const operation = vi.fn()
        .mockRejectedValueOnce(new Error('fail'))
        .mockRejectedValueOnce(new Error('fail'))
        .mockResolvedValue('success');

      const result = await retryWithBackoff(operation, 3);
      expect(result).toBe('success');
      expect(operation).toHaveBeenCalledTimes(3);
    });

    it('respects max retries', async () => {
      const operation = vi.fn().mockRejectedValue(new Error('fail'));

      await expect(retryWithBackoff(operation, 2))
        .rejects
        .toThrow('fail');
      
      expect(operation).toHaveBeenCalledTimes(2);
    });
  });
});