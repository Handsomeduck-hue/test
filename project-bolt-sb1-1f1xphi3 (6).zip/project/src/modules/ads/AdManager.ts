import { create } from 'zustand';
import { trackAdInteraction } from '../analytics/AnalyticsManager';
import { adConfig } from './config/adConfig';
import { buildAdTagUrl } from './utils/adTagBuilder';
import { COOLDOWN_PERIOD, ADMOB_APP_ID, REWARDED_AD_UNIT_ID } from './constants';
import { handleAdError } from './utils';
import { validateAdRequirements, validateVisibility } from './utils/validation';
import { cleanupAdResources } from './utils/cleanup';
import { retryWithBackoff } from './utils/retry';
import { validateNetworkForAds } from './utils/network';
import { loadIMAScript } from './utils/scriptLoader';

interface AdState {
  isLoading: boolean;
  isAvailable: boolean;
  lastRewardTime: number | null;
  error: string | null;
  adUnit: string | null;
  adResources: any | null;
}

interface AdActions {
  initializeAds: () => Promise<void>;
  showRewardedAd: () => Promise<boolean>;
  resetError: () => void;
}

export const useAdStore = create<{ state: AdState; actions: AdActions }>((set, get) => ({
  state: {
    isLoading: false,
    isAvailable: false,
    lastRewardTime: null,
    error: null,
    adUnit: null,
    adResources: null
  },
  actions: {
    initializeAds: async () => {
      try {
        const currentState = get().state;
        set({ state: { ...currentState, isLoading: true, error: null } });
        
        // Load IMA SDK first
        await loadIMAScript();
        
        // Validate network conditions
        const networkValidation = await validateNetworkForAds();
        if (!networkValidation.isValid) {
          throw new Error(networkValidation.errors.join(', '));
        }
        
        // Check if IMA SDK is available
        if (!window.google?.ima) {
          throw new Error('IMA SDK failed to initialize');
        }

        // Validate requirements
        const { isValid, errors } = validateAdRequirements();
        if (!isValid) {
          throw new Error(errors.join(', '));
        }

        window.gtag('config', ADMOB_APP_ID, {
          ads_enabled: true,
          allow_ad_personalization_signals: false
        });

        trackAdInteraction('rewarded', 'init');

        set({ 
          state: {
            ...currentState,
            isLoading: false,
            adUnit: REWARDED_AD_UNIT_ID,
            error: null
          }
        });
      } catch (error) {
        const errorMessage = handleAdError(error);
        set((state) => ({
          state: {
            ...state.state,
            isLoading: false,
            error: errorMessage,
            isAvailable: false
          }
        }));
        trackAdInteraction('rewarded', 'init_error');
      }
    },

    showRewardedAd: async () => {
      const { state } = get();
      
      // Check visibility before showing ad
      if (!validateVisibility()) {
        return false;
      }

      // Don't allow multiple concurrent requests
      if (state.isLoading) {
        return false;
      }

      set({ state: { ...state, isLoading: true, error: null } });

      let adResources = null;
      try {
        const { isValid, errors } = validateAdRequirements();
        if (!isValid) {
          throw new Error(errors.join(', '));
        }

        return new Promise((resolve, reject) => {
          try {
            const adContainer = document.createElement('div');
            adContainer.id = 'ad-container';
            Object.assign(adContainer.style, {
              position: 'fixed',
              zIndex: '9999',
              top: '0',
              left: '0',
              width: '100%',
              height: '100%',
              backgroundColor: 'rgba(0, 0, 0, 0.8)'
            });
            document.body.appendChild(adContainer);

            const videoElement = document.createElement('video');
            videoElement.style.width = '100%';
            videoElement.style.height = '100%';
            adContainer.appendChild(videoElement);

            const adDisplayContainer = new google.ima.AdDisplayContainer(adContainer, videoElement);
            adDisplayContainer.initialize();

            const adsLoader = new google.ima.AdsLoader(adDisplayContainer);
            
            adsLoader.addEventListener(
              google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
              (event) => {
                const adsManager = event.getAdsManager(videoElement);
                adResources = { adContainer, videoElement, adDisplayContainer, adsLoader, adsManager };

                adsManager.addEventListener(google.ima.AdEvent.Type.COMPLETE, () => {
                  cleanupAdResources(adResources);
                  trackAdInteraction('rewarded', 'complete');
                  set({ state: { ...state, isLoading: false, error: null }});
                  resolve(true);
                });

                adsManager.addEventListener(google.ima.AdErrorEvent.Type.AD_ERROR, (error) => {
                  cleanupAdResources(adResources);
                  reject(error.getError());
                });

                try {
                  adsManager.init(640, 360, google.ima.ViewMode.NORMAL);
                  adsManager.start();
                } catch (error) {
                  reject(error);
                }
              }
            );

            adsLoader.addEventListener(
              google.ima.AdErrorEvent.Type.AD_ERROR,
              (error) => {
                cleanupAdResources(adResources);
                reject(error.getError());
              }
            );

            const adsRequest = new google.ima.AdsRequest();
            adsRequest.adTagUrl = buildAdTagUrl(adConfig);
            adsRequest.linearAdSlotWidth = 640;
            adsRequest.linearAdSlotHeight = 360;
            adsRequest.nonLinearAdSlotWidth = 640;
            adsRequest.nonLinearAdSlotHeight = 150;

            adsLoader.requestAds(adsRequest);
          } catch (error) {
            cleanupAdResources(adResources);
            reject(error);
          }
        });
      } catch (error) {
        const errorMessage = handleAdError(error);
        set({
          state: {
            ...state,
            isLoading: false,
            error: errorMessage,
            isAvailable: false,
            adResources: null
          }
        });
        trackAdInteraction('rewarded', 'error');
        return false;
      }
    },

    resetError: () => {
      const { state } = get();
      set({ state: { ...state, error: null } });
    }
  }
}));