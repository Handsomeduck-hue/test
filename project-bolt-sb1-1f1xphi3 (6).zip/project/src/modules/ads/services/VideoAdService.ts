import { videoAdConfig } from '../config/videoAds';
import { logAdEvent, logAdError } from '../utils/logging';
import { createVideoElement } from '../utils/video';
import { validateAdRequirements } from '../utils/validation';
import type { VideoAdResult } from '../types';

export class VideoAdService {
  private adDisplayContainer: google.ima.AdDisplayContainer | null = null;
  private adsLoader: google.ima.AdsLoader | null = null;
  private adsManager: google.ima.AdsManager | null = null;
  private videoElement: HTMLVideoElement | null = null;
  private container: HTMLElement | null = null;

  async initialize(): Promise<void> {
    const { isValid, errors } = validateAdRequirements();
    if (!isValid) {
      throw new Error(errors.join(', '));
    }

    // Create video element and container
    this.videoElement = createVideoElement();
    this.container = this.createAdContainer();
    this.container.appendChild(this.videoElement);
    document.body.appendChild(this.container);

    // Initialize IMA SDK components
    this.adDisplayContainer = new google.ima.AdDisplayContainer(
      this.container,
      this.videoElement
    );

    this.adsLoader = new google.ima.AdsLoader(this.adDisplayContainer);
    this.setupEventListeners();
  }

  private createAdContainer(): HTMLElement {
    const container = document.createElement('div');
    Object.assign(container.style, videoAdConfig.containerConfig.style);
    return container;
  }

  private setupEventListeners(): void {
    if (!this.adsLoader) return;

    this.adsLoader.addEventListener(
      google.ima.AdsManagerLoadedEvent.Type.ADS_MANAGER_LOADED,
      (event) => this.onAdsManagerLoaded(event),
      false
    );

    this.adsLoader.addEventListener(
      google.ima.AdErrorEvent.Type.AD_ERROR,
      (error) => this.onAdError(error),
      false
    );
  }

  private onAdsManagerLoaded(event: google.ima.AdsManagerLoadedEvent): void {
    if (!this.videoElement) return;

    this.adsManager = event.getAdsManager(this.videoElement);
    this.setupAdsManagerListeners();
  }

  private setupAdsManagerListeners(): void {
    if (!this.adsManager) return;

    this.adsManager.addEventListener(
      google.ima.AdErrorEvent.Type.AD_ERROR,
      (error) => this.onAdError(error)
    );

    this.adsManager.addEventListener(
      google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
      () => this.onAllAdsCompleted()
    );
  }

  private onAdError(error: google.ima.AdErrorEvent): void {
    logAdError(error, 'Ad error occurred');
    this.cleanup();
  }

  private onAllAdsCompleted(): void {
    logAdEvent('All ads completed');
    this.cleanup();
  }

  private cleanup(): void {
    if (this.adsManager) {
      this.adsManager.destroy();
      this.adsManager = null;
    }

    if (this.adsLoader) {
      this.adsLoader.destroy();
      this.adsLoader = null;
    }

    if (this.container && document.body.contains(this.container)) {
      document.body.removeChild(this.container);
      this.container = null;
    }

    this.videoElement = null;
    this.adDisplayContainer = null;
  }

  async requestAd(): Promise<VideoAdResult> {
    try {
      if (!this.adDisplayContainer || !this.adsLoader) {
        throw new Error('Ad service not initialized');
      }

      this.adDisplayContainer.initialize();
      
      const adsRequest = new google.ima.AdsRequest();
      adsRequest.adTagUrl = videoAdConfig.imaConfig.adTagUrl;
      adsRequest.linearAdSlotWidth = videoAdConfig.imaConfig.adDisplayContainer.width;
      adsRequest.linearAdSlotHeight = videoAdConfig.imaConfig.adDisplayContainer.height;

      if (adsRequest.setAdWillAutoPlay) {
        adsRequest.setAdWillAutoPlay(true);
      }

      if (adsRequest.setAdWillPlayMuted) {
        adsRequest.setAdWillPlayMuted(false);
      }

      this.adsLoader.requestAds(adsRequest);

      return new Promise((resolve, reject) => {
        const timeoutId = setTimeout(() => {
          this.cleanup();
          reject(new Error('Ad request timeout'));
        }, 30000);

        if (this.adsManager) {
          this.adsManager.addEventListener(
            google.ima.AdEvent.Type.ALL_ADS_COMPLETED,
            () => {
              clearTimeout(timeoutId);
              resolve({ success: true });
            }
          );

          this.adsManager.addEventListener(
            google.ima.AdErrorEvent.Type.AD_ERROR,
            (error) => {
              clearTimeout(timeoutId);
              reject(error);
            }
          );
        }
      });
    } catch (error) {
      this.cleanup();
      throw error;
    }
  }
}