import type { GameState } from '../../game/types';
import { trackEvent } from '../core/events';

export const trackGameStart = () => {
  trackEvent({
    action: 'game_start',
    category: 'Game'
  });
};

export const trackGameOver = (state: GameState) => {
  trackEvent({
    action: 'game_over',
    category: 'Game',
    label: 'Game Over',
    value: state.score
  });
};

export const trackLevelComplete = (level: number, score: number) => {
  trackEvent({
    action: 'level_complete',
    category: 'Game',
    label: `Level ${level}`,
    value: score
  });
};