export function debounce<T extends (...args: any[]) => void>(
  callback: T,
  delay: number = 16
): T {
  let timeoutId: number;

  return ((...args: any[]) => {
    clearTimeout(timeoutId);
    timeoutId = window.setTimeout(() => callback(...args), delay);
  }) as T;
}