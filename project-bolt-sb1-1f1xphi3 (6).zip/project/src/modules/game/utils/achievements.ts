import { GameState, Achievement } from '../types';

export const checkAchievements = (state: GameState): Achievement[] => {
  const newAchievements: Achievement[] = [];

  // Quick Thinker Achievement
  if (state.timeRemaining > 20 && state.currentLevel > 3) {
    newAchievements.push({
      id: 'quick_thinker',
      name: 'Quick Thinker',
      description: 'Complete 3 rounds with more than 20 seconds remaining'
    });
  }

  // Perfect Streak Achievement
  if (state.currentStreak >= 5 && !state.showHint) {
    newAchievements.push({
      id: 'perfect_streak',
      name: 'Perfect Streak',
      description: 'Maintain a 5x streak without using hints'
    });
  }

  // Master Puzzler Achievement
  if (state.currentLevel >= 20) {
    newAchievements.push({
      id: 'master_puzzler',
      name: 'Master Puzzler',
      description: 'Reach level 20 in a single game'
    });
  }

  return newAchievements.filter(
    achievement => !state.achievements.some(a => a.id === achievement.id)
  );
};