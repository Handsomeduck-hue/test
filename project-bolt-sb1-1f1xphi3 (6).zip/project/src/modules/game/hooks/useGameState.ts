import { useCallback } from 'react';
import { GameSet, GameResult, Category } from '../types';
import { calculateScore } from '../utils/scoring';
import { getDifficultyMultiplier } from '../utils/difficulty';

export function useGameState() {
  const evaluateGuess = useCallback((
    gameSet: GameSet, 
    category: Category,
    guess: string, 
    timeRemaining: number, 
    streak: number
  ): GameResult => {
    const isCorrect = gameSet.oddOneOut === guess;
    
    if (isCorrect) {
      const timeBonus = calculateScore(timeRemaining);
      const streakBonus = streak * getDifficultyMultiplier(category);
      
      return {
        correct: true,
        bonus: streakBonus + timeBonus,
        message: `Perfect! +${timeBonus} time bonus, +${streakBonus} streak bonus`
      };
    }

    return {
      correct: false,
      mistake: guess,
      message: 'Try again!'
    };
  }, []);

  return { evaluateGuess };
}