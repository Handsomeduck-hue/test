import React from 'react';
import { Helmet } from 'react-helmet';
import { SitemapPage } from '../components/SitemapPage';

export default function SitemapRoute() {
  return (
    <>
      <Helmet>
        <title>Sitemap | Navigate 1 Odd Out Brain Training Games</title>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1276418176853020" crossOrigin="anonymous"></script>
        <meta name="description" content="Find all our brain training games, cognitive exercises, and resources in one place. Easy navigation through our complete site structure." />
        <meta name="keywords" content="brain training sitemap, puzzle game navigation, cognitive games index, brain exercise directory" />
        <link rel="canonical" href="https://1oddout.com/sitemap" />
      </Helmet>

      <SitemapPage />
    </>
  );
}