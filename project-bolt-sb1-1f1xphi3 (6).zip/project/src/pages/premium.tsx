import React from 'react';
import { Helmet } from 'react-helmet';
import { PremiumFeatures } from '../components/PremiumFeatures';

export default function PremiumRoute() {
  return (
    <>
      <Helmet>
        <title>Premium Brain Training Features | Advanced Cognitive Exercises</title>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1276418176853020" crossOrigin="anonymous"></script>
        <meta name="description" content="Unlock advanced brain training features! Get personalized cognitive exercises, detailed progress tracking, and exclusive puzzle categories." />
        <meta name="keywords" content="premium brain training, advanced cognitive exercises, personalized mental training, exclusive brain games, premium puzzle features" />
        <link rel="canonical" href="https://1oddout.com/premium" />
      </Helmet>

      <PremiumFeatures />
    </>
  );
}