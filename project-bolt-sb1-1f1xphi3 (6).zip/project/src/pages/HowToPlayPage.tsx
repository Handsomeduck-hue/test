import React from 'react';
import { Helmet } from 'react-helmet';
import { Card } from '../modules/ui/components/Card';
import { Brain, Target, Zap, Clock } from 'lucide-react';

export default function HowToPlayPage() {
  return (
    <>
      <Helmet>
        <title>How to Play 1 Odd Out | Game Guide & Tips</title>
        <meta name="description" content="Learn how to play 1 Odd Out and maximize your brain training experience. Get tips, strategies, and understand game mechanics." />
      </Helmet>

      <div className="max-w-4xl mx-auto p-4 space-y-8">
        <h1 className="text-4xl font-bold text-center mb-8">How to Play</h1>

        <Card className="space-y-8">
          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Brain className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Game Objective</h2>
            </div>
            <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
              In each round, you'll be presented with four items. Your task is to identify the one item that doesn't belong 
              with the others. This "odd one out" will have a characteristic that makes it different from the rest.
            </p>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Target className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">How to Score</h2>
            </div>
            <ul className="space-y-3 text-gray-600 dark:text-gray-400">
              <li className="flex items-center gap-2">
                • Base points for each correct answer
              </li>
              <li className="flex items-center gap-2">
                • Time bonus for quick answers
              </li>
              <li className="flex items-center gap-2">
                • Streak multiplier for consecutive correct answers
              </li>
              <li className="flex items-center gap-2">
                • Difficulty bonus based on the category
              </li>
            </ul>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Zap className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Power-ups & Features</h2>
            </div>
            <ul className="space-y-3 text-gray-600 dark:text-gray-400">
              <li className="flex items-center gap-2">
                • Hints: Get a clue about what makes an item different
              </li>
              <li className="flex items-center gap-2">
                • Extra Lives: Continue playing after mistakes
              </li>
              <li className="flex items-center gap-2">
                • Daily Challenges: Special puzzles updated daily
              </li>
              <li className="flex items-center gap-2">
                • Achievement System: Unlock rewards as you play
              </li>
            </ul>
          </section>

          <section className="space-y-4">
            <div className="flex items-center gap-3">
              <Clock className="w-6 h-6 text-system-blue dark:text-system-blue-dark" />
              <h2 className="text-2xl font-semibold">Tips for Success</h2>
            </div>
            <ul className="space-y-3 text-gray-600 dark:text-gray-400">
              <li className="flex items-center gap-2">
                • Take your time on harder puzzles
              </li>
              <li className="flex items-center gap-2">
                • Look for patterns and relationships between items
              </li>
              <li className="flex items-center gap-2">
                • Use hints strategically to maintain streaks
              </li>
              <li className="flex items-center gap-2">
                • Practice daily to improve your cognitive skills
              </li>
            </ul>
          </section>
        </Card>
      </div>
    </>
  );
}