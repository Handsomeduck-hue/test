import React from 'react';
import { Helmet } from 'react-helmet';
import { Tutorial } from '../components/Tutorial';

export default function HowToPlayRoute() {
  return (
    <>
      <Helmet>
        <title>How to Play 1 Odd Out | Brain Training Game Guide</title>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1276418176853020" crossOrigin="anonymous"></script>
        <meta name="description" content="Learn how to play 1 Odd Out and maximize your brain training! Get tips, strategies, and understand how our cognitive training puzzles work." />
        <meta name="keywords" content="how to play brain games, puzzle game tutorial, brain training guide, cognitive exercise tips, mind game strategies" />
        <link rel="canonical" href="https://1oddout.com/how-to-play" />
      </Helmet>

      <Tutorial />
    </>
  );
}