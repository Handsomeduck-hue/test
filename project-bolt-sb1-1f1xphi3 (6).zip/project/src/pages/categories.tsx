import React from 'react';
import { Helmet } from 'react-helmet';
import { CategoryList } from '../components/CategoryList';

export default function CategoriesRoute() {
  return (
    <>
      <Helmet>
        <title>Brain Training Categories | Logic, Memory & Pattern Recognition Games</title>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1276418176853020" crossOrigin="anonymous"></script>
        <meta name="description" content="Explore diverse brain training categories: logic puzzles, memory games, pattern recognition, and more. Find the perfect mental workout for your cognitive goals." />
        <meta name="keywords" content="brain training categories, cognitive skill games, memory training, logic puzzles, pattern recognition games, mental exercises" />
        <link rel="canonical" href="https://1oddout.com/categories" />
      </Helmet>

      <CategoryList />
    </>
  );
}