import React from 'react';
import { Helmet } from 'react-helmet';
import { PrivacyPolicy } from '../components/PrivacyPolicy';

export default function PrivacyRoute() {
  return (
    <>
      <Helmet>
        <title>Privacy Policy | 1 Odd Out Brain Training Games</title>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-1276418176853020" crossOrigin="anonymous"></script>
        <meta name="description" content="Read our privacy policy to understand how we protect your data while you enjoy our brain training games and cognitive exercises." />
        <meta name="keywords" content="brain training privacy, game data protection, cognitive training security, puzzle game privacy policy" />
        <link rel="canonical" href="https://1oddout.com/privacy" />
      </Helmet>

      <PrivacyPolicy />
    </>
  );
}