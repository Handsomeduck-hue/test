import { Category, Difficulty } from '../../types/game';

export const mythologyCategory: Category = {
  name: 'Mythology & Folklore',
  difficulty: Difficulty.Medium,
  sets: [
    {
      items: ['⚡ Thor', '🦇 Batman', '⚡ Zeus', '☀️ Amaterasu'],
      oddOneOut: '🦇 Batman',
      explanation: 'Batman is a fictional superhero, others are ancient deities.',
      hint: 'Think about ancient mythology.',
    },
    {
      items: ['🌆 Times Square', '🏔️ Mount Olympus', '🏰 Valhalla', '🏛️ Temple of Delphi'],
      oddOneOut: '🌆 Times Square',
      explanation: 'Times Square is a modern location, others are mythological places.',
      hint: 'Consider ancient sacred places.',
    },
    {
      items: ['🐉 Dragon', '🐘 Elephant', '🦄 Pegasus', '🔥 Phoenix'],
      oddOneOut: '🐘 Elephant',
      explanation: 'Elephant is a real animal, others are mythical creatures.',
      hint: 'Which exists in reality?',
    },
    {
      items: ['🔨 Mjolnir', '☔ Umbrella', '⚔️ Excalibur', '🗡️ Kusanagi'],
      oddOneOut: '☔ Umbrella',
      explanation: 'Umbrella is a common object, others are legendary weapons.',
      hint: 'Think about magical items.',
    },
    {
      items: ['🔮 Pythia', '📺 Weather Forecaster', '🏺 Oracle of Delphi', '⌛ Norns'],
      oddOneOut: '📺 Weather Forecaster',
      explanation: 'Weather Forecaster is a modern profession, others are mythological seers.',
      hint: 'Consider fortune tellers of ancient times.',
    }
  ]
};