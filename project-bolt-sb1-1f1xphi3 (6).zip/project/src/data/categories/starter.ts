import { Category, Difficulty } from '../../types/game';

export const starterCategory: Category = {
  name: 'Starter',
  difficulty: Difficulty.Easy,
  sets: [
    {
      items: ['🚗 Car', '🐱 Cat', '🐶 Dog', '🐰 Rabbit'],
      oddOneOut: '🚗 Car',
      explanation: 'Car is not an animal, while all others are pets.',
      hint: 'Think about living things.',
    },
    {
      items: ['✏️ Pencil', '📱 Phone', '✒️ Pen', '🎨 Paint Brush'],
      oddOneOut: '📱 Phone',
      explanation: 'Phone is not a drawing tool.',
      hint: 'Which one cannot make marks on paper?',
    },
    {
      items: ['👕 Shirt', '🎮 Controller', '👖 Pants', '👟 Shoes'],
      oddOneOut: '🎮 Controller',
      explanation: 'Controller is not a clothing item.',
      hint: 'What do you wear?',
    },
    {
      items: ['📚 Book', '🍎 Apple', '🍌 Banana', '🥕 Carrot'],
      oddOneOut: '📚 Book',
      explanation: 'Book is not edible, others are foods.',
      hint: 'What can you eat?',
    },
    {
      items: ['⭐ Star', '🚲 Bicycle', '🌞 Sun', '🌙 Moon'],
      oddOneOut: '🚲 Bicycle',
      explanation: 'Bicycle is not a celestial body.',
      hint: 'Think about objects in space.',
    },
    {
      items: ['🎵 Music', '🎨 Art', '📺 TV', '📚 Book'],
      oddOneOut: '📺 TV',
      explanation: 'TV is electronic entertainment, others are traditional arts.',
      hint: 'Which needs electricity?'
    },
    {
      items: ['🌈 Rainbow', '📱 Phone', '☁️ Cloud', '🌧️ Rain'],
      oddOneOut: '📱 Phone',
      explanation: 'Phone is not a natural phenomenon.',
      hint: 'Which isn\'t made by nature?',
    },
    {
      items: ['🎭 Theater', '🎪 Circus', '🏫 School', '🏛️ Museum'],
      oddOneOut: '🏫 School',
      explanation: 'School is for education, others are for entertainment.',
      hint: 'Where do you learn math?',
    },
    {
      items: ['🌞 Sun', '📱 Phone', '⭐ Star', '🌙 Moon'],
      oddOneOut: '📱 Phone',
      explanation: 'Phone is man-made, others are celestial bodies.',
      hint: 'Which isn\'t in space?',
    },
    {
      items: ['🎨 Paint', '✏️ Pencil', '🎮 Game', '✒️ Pen'],
      oddOneOut: '🎮 Game',
      explanation: 'Game is not a writing/drawing tool.',
      hint: 'Which can\'t make marks on paper?'
    }
  ]
};