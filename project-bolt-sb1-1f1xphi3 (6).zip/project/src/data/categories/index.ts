import { Category, Difficulty } from '../../types/game';
import { starterCategory } from './starter';
import { mythologyCategory } from './mythology';
import { scienceCategory } from './science';

export const categories: Category[] = [
  starterCategory,
  mythologyCategory,
  scienceCategory
];

export const difficultyProgression = {
  scoreThresholds: {
    [Difficulty.Easy]: 0,
    [Difficulty.Medium]: 1000,
    [Difficulty.Hard]: 2500,
    [Difficulty.Expert]: 5000
  },
  timeMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 0.8,
    [Difficulty.Hard]: 0.6,
    [Difficulty.Expert]: 0.4
  },
  bonusMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 1.5,
    [Difficulty.Hard]: 2,
    [Difficulty.Expert]: 3
  }
};