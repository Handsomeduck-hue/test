import { By, until, WebDriver } from 'selenium-webdriver';

export class HomePage {
  constructor(private driver: WebDriver) {}

  private selectors = {
    startButton: By.xpath("//button[contains(text(), 'Start Playing')]"),
    gameBoard: By.css('[data-testid="game-board"]'),
    gameCard: By.css('[data-testid="game-card"]'),
    score: By.css('[data-testid="score"]'),
    lives: By.css('[data-testid="lives"]'),
    hintButton: By.css('[data-testid="hint-button"]'),
    themeSelector: By.css('[data-testid="theme-selector"]'),
    gameOver: By.css('[data-testid="game-over"]'),
  };

  async navigate() {
    await this.driver.get('http://localhost:5173');
  }

  async startGame() {
    const startButton = await this.driver.findElement(this.selectors.startButton);
    await startButton.click();
    await this.driver.wait(until.elementLocated(this.selectors.gameBoard), 5000);
  }

  async selectCard(index: number) {
    const cards = await this.driver.findElements(this.selectors.gameCard);
    await cards[index].click();
  }

  async getScore(): Promise<string> {
    const scoreElement = await this.driver.findElement(this.selectors.score);
    return scoreElement.getText();
  }

  async getLives(): Promise<string> {
    const livesElement = await this.driver.findElement(this.selectors.lives);
    return livesElement.getText();
  }

  async useHint() {
    const hintButton = await this.driver.findElement(this.selectors.hintButton);
    await hintButton.click();
  }

  async changeTheme() {
    const themeButton = await this.driver.findElement(this.selectors.themeSelector);
    await themeButton.click();
  }

  async isGameOver(): Promise<boolean> {
    try {
      await this.driver.findElement(this.selectors.gameOver);
      return true;
    } catch {
      return false;
    }
  }
}