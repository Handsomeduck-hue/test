import { describe, test, expect, beforeEach } from '@jest/globals';
import { HomePage } from './pages/HomePage';
import { WebDriver } from 'selenium-webdriver';

describe('Performance Tests', () => {
  let homePage: HomePage;
  let driver: WebDriver;

  beforeEach(async () => {
    driver = global.driver;
    homePage = new HomePage(driver);
    await homePage.navigate();
  });

  test('should load initial page within 2 seconds', async () => {
    const startTime = Date.now();
    await homePage.navigate();
    const loadTime = Date.now() - startTime;
    
    expect(loadTime).toBeLessThan(2000);
  });

  test('should start game within 500ms', async () => {
    const startTime = Date.now();
    await homePage.startGame();
    const loadTime = Date.now() - startTime;
    
    expect(loadTime).toBeLessThan(500);
  });

  test('should respond to card selection within 100ms', async () => {
    await homePage.startGame();
    
    const startTime = Date.now();
    await homePage.selectCard(0);
    const responseTime = Date.now() - startTime;
    
    expect(responseTime).toBeLessThan(100);
  });

  test('should maintain performance after multiple rounds', async () => {
    await homePage.startGame();
    
    const rounds = 10;
    const responseTimes: number[] = [];
    
    for (let i = 0; i < rounds; i++) {
      const startTime = Date.now();
      await homePage.selectCard(0);
      responseTimes.push(Date.now() - startTime);
      await driver.sleep(500); // Wait for next round
    }
    
    const averageResponseTime = responseTimes.reduce((a, b) => a + b) / rounds;
    expect(averageResponseTime).toBeLessThan(100);
  });

  test('should handle rapid card selections', async () => {
    await homePage.startGame();
    
    const clicks = 10;
    const startTime = Date.now();
    
    for (let i = 0; i < clicks; i++) {
      await homePage.selectCard(i % 4);
    }
    
    const totalTime = Date.now() - startTime;
    const averageClickTime = totalTime / clicks;
    
    expect(averageClickTime).toBeLessThan(50);
  });

  test('should maintain FPS during animations', async () => {
    await homePage.startGame();
    
    // Get FPS metrics before animations
    const baseMetrics = await driver.executeScript(() => {
      return window.performance.now();
    });
    
    // Trigger multiple animations
    for (let i = 0; i < 5; i++) {
      await homePage.selectCard(i % 4);
      await driver.sleep(100);
    }
    
    // Get FPS metrics after animations
    const animationMetrics = await driver.executeScript(() => {
      return window.performance.now();
    });
    
    const timeDiff = animationMetrics - baseMetrics;
    const expectedFrames = (timeDiff / 1000) * 60; // 60fps target
    
    // Allow for some frame drops, but maintain at least 45fps
    expect(expectedFrames).toBeGreaterThan(45);
  });

  test('should handle window resizing smoothly', async () => {
    const viewports = [
      { width: 375, height: 667 },  // Mobile
      { width: 768, height: 1024 }, // Tablet
      { width: 1366, height: 768 }, // Laptop
      { width: 1920, height: 1080 } // Desktop
    ];

    await homePage.startGame();
    
    for (const viewport of viewports) {
      const startTime = Date.now();
      await driver.manage().window().setRect(viewport);
      const resizeTime = Date.now() - startTime;
      
      expect(resizeTime).toBeLessThan(200);
      
      // Verify game is still playable
      await homePage.selectCard(0);
      await driver.sleep(100);
    }
  });

  test('should handle background tab performance', async () => {
    await homePage.startGame();
    
    // Simulate tab blur
    await driver.executeScript(() => {
      window.dispatchEvent(new Event('blur'));
    });
    
    await driver.sleep(1000);
    
    // Simulate tab focus
    await driver.executeScript(() => {
      window.dispatchEvent(new Event('focus'));
    });
    
    // Verify game is still responsive
    const startTime = Date.now();
    await homePage.selectCard(0);
    const responseTime = Date.now() - startTime;
    
    expect(responseTime).toBeLessThan(100);
  });
});