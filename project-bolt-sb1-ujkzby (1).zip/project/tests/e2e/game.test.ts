import { describe, test, expect, beforeEach } from '@jest/globals';
import { HomePage } from './pages/HomePage';

describe('Odd One Out Game E2E Tests', () => {
  let homePage: HomePage;

  beforeEach(async () => {
    homePage = new HomePage(global.driver);
    await homePage.navigate();
  });

  test('should start a new game', async () => {
    await homePage.startGame();
    const lives = await homePage.getLives();
    const score = await homePage.getScore();
    
    expect(lives).toBe('3');
    expect(score).toBe('0');
  });

  test('should be able to select cards', async () => {
    await homePage.startGame();
    await homePage.selectCard(0);
    
    // Verify game state changed (score or lives updated)
    const score = await homePage.getScore();
    expect(score).not.toBe('0');
  });

  test('should be able to use hints', async () => {
    await homePage.startGame();
    await homePage.useHint();
    
    // Verify hint was displayed
    // Add specific assertions based on your UI
  });

  test('should end game after losing all lives', async () => {
    await homePage.startGame();
    
    // Deliberately make wrong choices
    await homePage.selectCard(0);
    await homePage.selectCard(1);
    await homePage.selectCard(2);
    
    const isGameOver = await homePage.isGameOver();
    expect(isGameOver).toBe(true);
  });

  test('should be able to change theme', async () => {
    await homePage.changeTheme();
    // Add assertions to verify theme change
    // This might involve checking CSS properties or theme-specific classes
  });
});