/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  darkMode: 'media',
  theme: {
    extend: {
      colors: {
        // System Colors - Light Mode
        'system-blue': '#007AFF',
        'system-green': '#34C759',
        'system-indigo': '#5856D6',
        'system-orange': '#FF9500',
        'system-pink': '#FF2D55',
        'system-purple': '#AF52DE',
        'system-red': '#FF3B30',
        'system-teal': '#5AC8FA',
        'system-yellow': '#FFCC00',
        
        // System Colors - Dark Mode
        'system-blue-dark': '#0A84FF',
        'system-green-dark': '#30D158',
        'system-indigo-dark': '#5E5CE6',
        'system-orange-dark': '#FF9F0A',
        'system-pink-dark': '#FF375F',
        'system-purple-dark': '#BF5AF2',
        'system-red-dark': '#FF453A',
        'system-teal-dark': '#64D2FF',
        'system-yellow-dark': '#FFD60A',
        
        // System Gray Colors - Light Mode
        'system-gray': {
          1: '#8E8E93',
          2: '#AEAEB2',
          3: '#C7C7CC',
          4: '#D1D1D6',
          5: '#E5E5EA',
          6: '#F2F2F7',
        },
        
        // System Gray Colors - Dark Mode
        'system-gray-dark': {
          1: '#8E8E93',
          2: '#636366',
          3: '#48484A',
          4: '#3A3A3C',
          5: '#2C2C2E',
          6: '#1C1C1E',
        },
      },
      backgroundImage: {
        'gradient-game': 'linear-gradient(180deg, var(--tw-gradient-from) 0%, var(--tw-gradient-to) 100%)',
      },
    },
  },
  plugins: [],
};