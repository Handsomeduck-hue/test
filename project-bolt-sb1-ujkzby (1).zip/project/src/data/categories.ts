import { Category, Difficulty } from '../types/game';

export const categories: Category[] = [
  {
    name: 'Starter',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['🐱 Cat', '🐶 Dog', '📱 Phone', '🐰 Rabbit'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not an animal, while all others are pets.',
        hint: 'Which one is not alive?',
      },
      {
        items: ['🎨 Paint', '✏️ Pencil', '📚 Book', '✒️ Pen'],
        oddOneOut: '📚 Book',
        explanation: 'Book is for reading, others are for drawing/writing.',
        hint: 'Which one do you read?',
      },
      {
        items: ['👕 Shirt', '👖 Pants', '🎮 Controller', '👟 Shoes'],
        oddOneOut: '🎮 Controller',
        explanation: 'Controller is not clothing.',
        hint: 'What do you wear?',
      },
      {
        items: ['🍎 Apple', '⚽ Ball', '🍌 Banana', '🍊 Orange'],
        oddOneOut: '⚽ Ball',
        explanation: 'Ball is not a fruit.',
        hint: 'Which one can you eat?',
      },
      {
        items: ['🌞 Sun', '🎭 Mask', '⭐ Star', '🌙 Moon'],
        oddOneOut: '🎭 Mask',
        explanation: 'Mask is not found in space.',
        hint: 'Which one is made by humans?',
      }
    ]
  },
  {
    name: 'Animals',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['🦁 Lion', '🐯 Tiger', '🎪 Circus', '🐆 Cheetah'],
        oddOneOut: '🎪 Circus',
        explanation: 'Circus is a place, not a big cat.',
        hint: 'Which is not an animal?',
      },
      {
        items: ['🐘 Elephant', '🦒 Giraffe', '🚗 Car', '🦛 Hippo'],
        oddOneOut: '🚗 Car',
        explanation: 'Car is not an animal.',
        hint: 'Which one has an engine?',
      },
      {
        items: ['🐧 Penguin', '🦆 Duck', '🎈 Balloon', '🦢 Swan'],
        oddOneOut: '🎈 Balloon',
        explanation: 'Balloon is not a bird.',
        hint: 'Which one cannot lay eggs?',
      },
      {
        items: ['🐠 Fish', '🦈 Shark', '⛵ Boat', '🐋 Whale'],
        oddOneOut: '⛵ Boat',
        explanation: 'Boat is not a sea creature.',
        hint: 'Which one is man-made?',
      },
      {
        items: ['🦊 Fox', '🎨 Paint', '🐺 Wolf', '🦁 Lion'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not a predator.',
        hint: 'Which one is not a hunter?',
      }
    ]
  },
  {
    name: 'Food & Drinks',
    difficulty: Difficulty.Easy,
    sets: [
      {
        items: ['🥤 Soda', '📱 Phone', '🧃 Juice', '🥛 Milk'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not a beverage.',
        hint: 'Which one can\'t you drink?',
      },
      {
        items: ['🍕 Pizza', '🍔 Burger', '🎨 Paint', '🌭 Hot Dog'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not food.',
        hint: 'Which one would make you sick?',
      },
      {
        items: ['🍦 Ice Cream', '🧁 Cupcake', '🎮 Game', '🍪 Cookie'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not a dessert.',
        hint: 'Which one isn\'t sweet?',
      },
      {
        items: ['🥗 Salad', '🎸 Guitar', '🥪 Sandwich', '🌮 Taco'],
        oddOneOut: '🎸 Guitar',
        explanation: 'Guitar is not food.',
        hint: 'Which one can\'t you eat?',
      },
      {
        items: ['🍜 Noodles', '🍚 Rice', '⚽ Ball', '🥖 Bread'],
        oddOneOut: '⚽ Ball',
        explanation: 'Ball is not a carbohydrate food.',
        hint: 'Which isn\'t eaten?',
      }
    ]
  },
  {
    name: 'Technology',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['💻 Laptop', '📱 Phone', '🎸 Guitar', '⌚ Watch'],
        oddOneOut: '🎸 Guitar',
        explanation: 'Guitar is not an electronic device.',
        hint: 'Which one has no screen?',
      },
      {
        items: ['🖨️ Printer', '📷 Camera', '🌺 Flower', '🎮 Console'],
        oddOneOut: '🌺 Flower',
        explanation: 'Flower is not a tech device.',
        hint: 'Which is natural?',
      },
      {
        items: ['📺 TV', '🖥️ Monitor', '🎪 Circus', '💻 Laptop'],
        oddOneOut: '🎪 Circus',
        explanation: 'Circus is not a display device.',
        hint: 'Which can\'t show images?',
      },
      {
        items: ['🔋 Battery', '💡 Bulb', '🌙 Moon', '⚡ Power'],
        oddOneOut: '🌙 Moon',
        explanation: 'Moon is not related to electricity.',
        hint: 'Which isn\'t powered?',
      },
      {
        items: ['🎮 Controller', '🕹️ Joystick', '🎨 Paint', '⌨️ Keyboard'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not an input device.',
        hint: 'Which doesn\'t control computers?',
      }
    ]
  },
  {
    name: 'Sports',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['⚽ Soccer', '🏀 Basketball', '🎨 Painting', '🏈 Football'],
        oddOneOut: '🎨 Painting',
        explanation: 'Painting is not a sport.',
        hint: 'Which isn\'t physical?',
      },
      {
        items: ['🏸 Badminton', '📚 Book', '🎾 Tennis', '🏓 Ping Pong'],
        oddOneOut: '📚 Book',
        explanation: 'Book is not a racket sport.',
        hint: 'Which has no racket?',
      },
      {
        items: ['⛳ Golf', '🎳 Bowling', '🎭 Theater', '🎱 Pool'],
        oddOneOut: '🎭 Theater',
        explanation: 'Theater is not a precision sport.',
        hint: 'Which isn\'t a game?',
      },
      {
        items: ['🏊‍♂️ Swimming', '🚴‍♂️ Cycling', '🎪 Circus', '🏃‍♂️ Running'],
        oddOneOut: '🎪 Circus',
        explanation: 'Circus is not an endurance sport.',
        hint: 'Which isn\'t exercise?',
      },
      {
        items: ['⚾ Baseball', '🏑 Hockey', '🎨 Art', '⚽ Soccer'],
        oddOneOut: '🎨 Art',
        explanation: 'Art is not a ball sport.',
        hint: 'Which has no ball or puck?',
      }
    ]
  },
  {
    name: 'Music',
    difficulty: Difficulty.Medium,
    sets: [
      {
        items: ['🎸 Guitar', '🎹 Piano', '📱 Phone', '🎺 Trumpet'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not a musical instrument.',
        hint: 'Which isn\'t for music?',
      },
      {
        items: ['🥁 Drums', '🎻 Violin', '🎨 Paint', '🎺 Trumpet'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not a musical instrument.',
        hint: 'Which makes no sound?',
      },
      {
        items: ['🎵 Note', '🎼 Score', '⚽ Ball', '🎶 Music'],
        oddOneOut: '⚽ Ball',
        explanation: 'Ball is not related to music.',
        hint: 'Which isn\'t musical?',
      },
      {
        items: ['🎸 Guitar', '🎺 Trumpet', '📚 Book', '🎻 Violin'],
        oddOneOut: '📚 Book',
        explanation: 'Book is not a musical instrument.',
        hint: 'Which makes no music?',
      },
      {
        items: ['🎹 Piano', '🥁 Drums', '🎨 Paint', '🎸 Guitar'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not for making music.',
        hint: 'Which isn\'t played?',
      }
    ]
  },
  {
    name: 'Nature',
    difficulty: Difficulty.Hard,
    sets: [
      {
        items: ['🌳 Tree', '🌺 Flower', '📱 Phone', '🌿 Plant'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not from nature.',
        hint: 'Which isn\'t alive?',
      },
      {
        items: ['🌊 Wave', '🌋 Volcano', '🎮 Game', '🏔️ Mountain'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not a natural formation.',
        hint: 'Which is man-made?',
      },
      {
        items: ['☀️ Sun', '🌙 Moon', '💡 Bulb', '⭐ Star'],
        oddOneOut: '💡 Bulb',
        explanation: 'Bulb is not a celestial body.',
        hint: 'Which isn\'t in space?',
      },
      {
        items: ['🌧️ Rain', '❄️ Snow', '📺 TV', '⚡ Lightning'],
        oddOneOut: '📺 TV',
        explanation: 'TV is not a weather phenomenon.',
        hint: 'Which isn\'t weather?',
      },
      {
        items: ['🌺 Flower', '🌳 Tree', '🎮 Game', '🌿 Plant'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not a living plant.',
        hint: 'Which doesn\'t grow?',
      }
    ]
  },
  {
    name: 'Transportation',
    difficulty: Difficulty.Hard,
    sets: [
      {
        items: ['✈️ Plane', '🚗 Car', '📱 Phone', '🚂 Train'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not a vehicle.',
        hint: 'Which doesn\'t move people?',
      },
      {
        items: ['🚢 Ship', '🛥️ Boat', '🎨 Paint', '🚤 Speedboat'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not a water vehicle.',
        hint: 'Which doesn\'t float?',
      },
      {
        items: ['🚁 Helicopter', '✈️ Plane', '🎪 Circus', '🛩️ Jet'],
        oddOneOut: '🎪 Circus',
        explanation: 'Circus is not an aircraft.',
        hint: 'Which doesn\'t fly?',
      },
      {
        items: ['🚗 Car', '🏎️ Race Car', '🎸 Guitar', '🚙 SUV'],
        oddOneOut: '🎸 Guitar',
        explanation: 'Guitar is not an automobile.',
        hint: 'Which has no wheels?',
      },
      {
        items: ['🚲 Bicycle', '🛵 Scooter', '📚 Book', '🏍️ Motorcycle'],
        oddOneOut: '📚 Book',
        explanation: 'Book is not a two-wheeler.',
        hint: 'Which isn\'t ridden?',
      }
    ]
  },
  {
    name: 'Art & Creativity',
    difficulty: Difficulty.Expert,
    sets: [
      {
        items: ['🎨 Paint', '✏️ Pencil', '⚽ Ball', '🖌️ Brush'],
        oddOneOut: '⚽ Ball',
        explanation: 'Ball is not an art tool.',
        hint: 'Which can\'t create art?',
      },
      {
        items: ['🖼️ Painting', '🎭 Mask', '📱 Phone', '🎨 Canvas'],
        oddOneOut: '📱 Phone',
        explanation: 'Phone is not art-related.',
        hint: 'Which isn\'t artistic?',
      },
      {
        items: ['✏️ Pencil', '🖌️ Brush', '🎮 Game', '🖍️ Crayon'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not an art supply.',
        hint: 'Which doesn\'t draw?',
      },
      {
        items: ['🎭 Theater', '🎨 Paint', '🎬 Cinema', '🎪 Circus'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not a performance art.',
        hint: 'Which isn\'t a show?',
      },
      {
        items: ['🖼️ Frame', '🎨 Canvas', '⚽ Ball', '🖌️ Easel'],
        oddOneOut: '⚽ Ball',
        explanation: 'Ball is not used in painting.',
        hint: 'Which isn\'t for art?',
      }
    ]
  },
  {
    name: 'Science',
    difficulty: Difficulty.Expert,
    sets: [
      {
        items: ['🔬 Microscope', '⚗️ Beaker', '🎮 Game', '🧪 Test Tube'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not lab equipment.',
        hint: 'Which isn\'t scientific?',
      },
      {
        items: ['🧬 DNA', '🦠 Microbe', '🎨 Paint', '🔬 Cell'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not biological.',
        hint: 'Which isn\'t living?',
      },
      {
        items: ['⚡ Electron', '⚛️ Atom', '🎪 Circus', '🧲 Magnet'],
        oddOneOut: '🎪 Circus',
        explanation: 'Circus is not physics-related.',
        hint: 'Which isn\'t scientific?',
      },
      {
        items: ['🧪 Chemical', '⚗️ Solution', '🎮 Game', '🧬 Molecule'],
        oddOneOut: '🎮 Game',
        explanation: 'Game is not chemistry-related.',
        hint: 'Which isn\'t chemical?',
      },
      {
        items: ['🔭 Telescope', '📡 Satellite', '🎨 Paint', '🛸 Space'],
        oddOneOut: '🎨 Paint',
        explanation: 'Paint is not astronomy-related.',
        hint: 'Which isn\'t space-related?',
      }
    ]
  }
];

export const difficultyProgression = {
  scoreThresholds: {
    [Difficulty.Easy]: 0,
    [Difficulty.Medium]: 500,
    [Difficulty.Hard]: 1500,
    [Difficulty.Expert]: 3000
  },
  timeMultipliers: {
    [Difficulty.Easy]: 1.2,
    [Difficulty.Medium]: 1,
    [Difficulty.Hard]: 0.8,
    [Difficulty.Expert]: 0.6
  },
  bonusMultipliers: {
    [Difficulty.Easy]: 1,
    [Difficulty.Medium]: 1.3,
    [Difficulty.Hard]: 1.6,
    [Difficulty.Expert]: 2
  }
};