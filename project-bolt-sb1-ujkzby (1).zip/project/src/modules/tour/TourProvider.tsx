import React, { useState, useEffect } from 'react';
import Joyride, { EVENTS, CallBackProps, Step } from 'react-joyride';

const steps: Step[] = [
  {
    target: '[data-tour="theme-selector"]',
    content: 'Click here to change the theme',
    placement: 'left',
    disableBeacon: false,
    spotlightPadding: 8
  }
];

export function TourProvider({ children }: { children: React.ReactNode }) {
  const [run, setRun] = useState(false);
  
  useEffect(() => {
    const hasSeenTour = localStorage.getItem('hasSeenThemeTour');
    if (!hasSeenTour) {
      setRun(true);
    }
  }, []);

  const handleJoyrideCallback = (data: CallBackProps) => {
    const { type } = data;
    if ([EVENTS.TOUR_END, EVENTS.SKIP, EVENTS.TARGET_NOT_FOUND].includes(type)) {
      setRun(false);
      localStorage.setItem('hasSeenThemeTour', 'true');
    }
  };

  return (
    <>
      <Joyride
        steps={steps}
        run={run}
        showSkipButton={false}
        showProgress={false}
        spotlightClicks
        hideCloseButton
        callback={handleJoyrideCallback}
        styles={{
          options: {
            primaryColor: '#007AFF',
            textColor: '#1C1C1E',
            backgroundColor: '#FFFFFF',
            arrowColor: '#FFFFFF',
            overlayColor: 'rgba(0, 0, 0, 0.5)',
            zIndex: 1000,
          },
          tooltip: {
            borderRadius: '1rem',
            padding: '1rem',
          },
          spotlight: {
            borderRadius: '1rem',
          }
        }}
      />
      {children}
    </>
  );
}