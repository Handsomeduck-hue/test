import { create } from 'zustand';
import { trackAdInteraction } from '../analytics/AnalyticsManager';

interface AdState {
  isLoading: boolean;
  isRewarded: boolean;
  lastRewardTime: number | null;
  error: string | null;
  adUnit: string | null;
  revenue: number;
  impressions: number;
}

interface AdStore {
  state: AdState;
  actions: {
    showRewardedAd: () => Promise<boolean>;
    resetError: () => void;
    initializeAds: () => Promise<void>;
  };
}

const COOLDOWN_PERIOD = 5 * 60 * 1000; // 5 minutes
const ADMOB_APP_ID = 'ca-app-pub-1276418176853020~7645322031';
const REWARDED_AD_UNIT_ID = 'ca-app-pub-1276418176853020/5332240369';

declare global {
  interface Window {
    adsbygoogle: any;
    gtag: (...args: any[]) => void;
  }
}

export const useAdStore = create<AdStore>((set, get) => ({
  state: {
    isLoading: false,
    isRewarded: false,
    lastRewardTime: null,
    error: null,
    adUnit: null,
    revenue: 0,
    impressions: 0,
  },
  actions: {
    initializeAds: async () => {
      try {
        // Initialize Google AdMob
        window.gtag('config', ADMOB_APP_ID, {
          'ads_enabled': true,
          'allow_ad_personalization_signals': false
        });

        // Load rewarded ad unit
        window.gtag('event', 'ad_request', {
          'ad_unit_id': REWARDED_AD_UNIT_ID,
          'ad_type': 'rewarded'
        });

        trackAdInteraction('rewarded', 'init');

        set((state) => ({
          state: {
            ...state,
            adUnit: REWARDED_AD_UNIT_ID,
            error: null
          }
        }));
      } catch (error) {
        console.error('Ad initialization error:', error);
        set((state) => ({
          state: {
            ...state,
            error: 'Failed to initialize ads'
          }
        }));
        trackAdInteraction('rewarded', 'init_error');
      }
    },
    showRewardedAd: async () => {
      const { state } = get();
      
      // Check cooldown
      if (state.lastRewardTime && Date.now() - state.lastRewardTime < COOLDOWN_PERIOD) {
        const remainingTime = Math.ceil((COOLDOWN_PERIOD - (Date.now() - state.lastRewardTime)) / 1000);
        set({ state: { ...state, error: `Please wait ${remainingTime} seconds before watching another ad` } });
        return false;
      }

      set({ state: { ...state, isLoading: true, error: null } });
      trackAdInteraction('rewarded', 'request');

      try {
        return new Promise<boolean>((resolve) => {
          window.gtag('event', 'ad_reward', {
            'ad_unit_id': REWARDED_AD_UNIT_ID,
            'reward_type': 'extra_life',
            'value': 1,
            'callback': (reward: any) => {
              if (reward) {
                // Track successful ad view and revenue
                trackAdInteraction('rewarded', 'complete');
                window.gtag('event', 'ad_revenue', {
                  'ad_unit_id': REWARDED_AD_UNIT_ID,
                  'value': reward.amount,
                  'currency': 'USD'
                });

                set({ 
                  state: { 
                    ...state, 
                    isLoading: false,
                    isRewarded: true,
                    lastRewardTime: Date.now(),
                    revenue: state.revenue + (reward.amount || 0),
                    impressions: state.impressions + 1,
                    error: null 
                  } 
                });
                resolve(true);
              } else {
                trackAdInteraction('rewarded', 'incomplete');
                set({ 
                  state: { 
                    ...state, 
                    isLoading: false,
                    error: 'Ad did not complete successfully' 
                  } 
                });
                resolve(false);
              }
            },
            'error_callback': (error: any) => {
              console.error('Ad error:', error);
              trackAdInteraction('rewarded', 'error');
              set({ 
                state: { 
                  ...state, 
                  isLoading: false,
                  error: 'Failed to load ad' 
                } 
              });
              resolve(false);
            }
          });
        });
      } catch (error) {
        console.error('Ad display error:', error);
        trackAdInteraction('rewarded', 'error');
        set({ 
          state: { 
            ...state, 
            isLoading: false,
            error: 'Failed to show ad' 
          } 
        });
        return false;
      }
    },
    resetError: () => {
      const { state } = get();
      set({ state: { ...state, error: null } });
    },
  },
}));