import { Difficulty } from '../types';
import { difficultyProgression } from '../../../data/categories';

export const calculateScore = (
  timeRemaining: number,
  difficulty: Difficulty,
  streak: number
): number => {
  const baseScore = Math.ceil(timeRemaining * 10);
  const difficultyMultiplier = difficultyProgression.bonusMultipliers[difficulty];
  const streakBonus = streak * 50;

  return Math.ceil((baseScore + streakBonus) * difficultyMultiplier);
};

export const calculateTimeLimit = (level: number, difficulty: Difficulty): number => {
  const baseTime = Math.max(30 - Math.floor(level / 5), 15);
  return Math.ceil(baseTime * difficultyProgression.timeMultipliers[difficulty]);
};

export const calculateStreak = (currentStreak: number, correct: boolean): number => {
  if (!correct) return 0;
  return currentStreak + 1;
};

export const getStreakBonus = (streak: number): number => {
  if (streak < 3) return 0;
  if (streak < 5) return 50;
  if (streak < 10) return 100;
  return 200;
};