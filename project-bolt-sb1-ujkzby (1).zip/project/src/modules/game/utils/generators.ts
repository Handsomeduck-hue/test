import { categories } from '../../../data/categories';
import { Category, GameSet } from '../types';

export const getRandomSet = (category: Category): GameSet => {
  const availableSets = category.sets;
  return availableSets[Math.floor(Math.random() * availableSets.length)];
};

export const getRandomCategory = (): Category => {
  return categories[Math.floor(Math.random() * categories.length)];
};