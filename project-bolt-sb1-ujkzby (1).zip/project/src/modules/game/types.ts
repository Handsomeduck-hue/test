export type Achievement = {
  id: string;
  name: string;
  description: string;
  icon: string;
  reward: Reward;
};

export type Reward = {
  type: 'extra_life' | 'hint' | 'time_bonus' | 'score_multiplier';
  value: number;
};

export type AchievementProgress = {
  id: string;
  progress: number;
  completed: boolean;
  claimed: boolean;
};