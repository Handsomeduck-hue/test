import { useCallback, useRef, useEffect } from 'react';

export function useGamePerformance() {
  const frameTimeRef = useRef<number[]>([]);
  const lastFrameTimeRef = useRef<number>(performance.now());
  const animationFrameRef = useRef<number>();

  const measureFrameTime = useCallback(() => {
    const now = performance.now();
    const frameDuration = now - lastFrameTimeRef.current;
    lastFrameTimeRef.current = now;

    frameTimeRef.current.push(frameDuration);
    if (frameTimeRef.current.length > 60) {
      frameTimeRef.current.shift();
    }

    animationFrameRef.current = requestAnimationFrame(measureFrameTime);
  }, []);

  const getPerformanceMetrics = useCallback(() => {
    const frameTimes = frameTimeRef.current;
    if (frameTimes.length === 0) return null;

    const avgFrameTime = frameTimes.reduce((a, b) => a + b, 0) / frameTimes.length;
    const fps = 1000 / avgFrameTime;
    const minFps = 1000 / Math.max(...frameTimes);
    const maxFps = 1000 / Math.min(...frameTimes);

    return {
      fps: Math.round(fps),
      minFps: Math.round(minFps),
      maxFps: Math.round(maxFps),
      avgFrameTime: Math.round(avgFrameTime * 100) / 100,
      frameTimeVariance: Math.round(
        Math.sqrt(
          frameTimes.reduce((acc, time) => acc + Math.pow(time - avgFrameTime, 2), 0) / frameTimes.length
        ) * 100
      ) / 100
    };
  }, []);

  useEffect(() => {
    animationFrameRef.current = requestAnimationFrame(measureFrameTime);
    
    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [measureFrameTime]);

  return { getPerformanceMetrics };
}