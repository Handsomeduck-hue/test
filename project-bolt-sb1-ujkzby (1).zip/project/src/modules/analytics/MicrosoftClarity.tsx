import React, { useEffect } from 'react';

declare global {
  interface Window {
    clarity: (...args: any[]) => void;
  }
}

type ClarityProviderProps = {
  children: React.ReactNode;
};

export function ClarityProvider({ children }: ClarityProviderProps) {
  useEffect(() => {
    // Load Clarity script
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.innerHTML = `
      (function(c,l,a,r,i,t,y){
        c[a]=c[a]||function(){(c[a].q=c[a].q||[]).push(arguments)};
        t=l.createElement(r);t.async=1;t.src="https://www.clarity.ms/tag/"+i;
        y=l.getElementsByTagName(r)[0];y.parentNode.insertBefore(t,y);
      })(window, document, "clarity", "script", "p4ny0e4ww8");
    `;
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  return <>{children}</>;
}

// Custom hook for tracking events
export function useClarity() {
  const trackEvent = (event: string, properties?: Record<string, any>) => {
    if (window.clarity) {
      window.clarity('event', event, properties);
    }
  };

  const setCustomData = (key: string, value: string) => {
    if (window.clarity) {
      window.clarity('set', key, value);
    }
  };

  return {
    trackEvent,
    setCustomData
  };
}