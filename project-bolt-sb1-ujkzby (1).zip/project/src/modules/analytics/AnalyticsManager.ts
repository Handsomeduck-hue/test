import { GameState } from '../game/types';
import ReactGA from 'react-ga4';

// Initialize GA4 with measurement ID
ReactGA.initialize('G-K99WE65NDE', {
  testMode: process.env.NODE_ENV !== 'production',
  gaOptions: {
    cookieFlags: 'SameSite=None;Secure',
    anonymizeIp: true,
    allowAdFeatures: false
  }
});

// Page view tracking
export const trackPageView = (path: string) => {
  ReactGA.send({
    hitType: 'pageview',
    page: path
  });

  // Track in Clarity
  if (window.clarity) {
    window.clarity('pageview', path);
  }
};

// Game events tracking
export const trackGameStart = () => {
  ReactGA.event({
    category: 'Game',
    action: 'game_start',
    nonInteraction: false
  });

  if (window.clarity) {
    window.clarity('event', 'game_start');
  }
};

export const trackGameOver = (state: GameState) => {
  const eventData = {
    category: 'Game',
    action: 'game_over',
    label: 'Game Over',
    value: state.score,
    metric1: state.currentLevel,
    metric2: state.bestStreak,
    dimension1: state.difficulty
  };

  ReactGA.event(eventData);

  if (window.clarity) {
    window.clarity('event', 'game_over', {
      score: state.score,
      level: state.currentLevel,
      streak: state.bestStreak,
      difficulty: state.difficulty
    });
  }
};

export const trackLevelComplete = (level: number, score: number) => {
  ReactGA.event({
    category: 'Game',
    action: 'level_complete',
    label: `Level ${level}`,
    value: score,
    metric1: level
  });

  if (window.clarity) {
    window.clarity('event', 'level_complete', {
      level,
      score
    });
  }
};

// User interaction events
export const trackHintUsed = (level: number) => {
  ReactGA.event({
    category: 'User Interaction',
    action: 'hint_used',
    label: `Level ${level}`,
    value: level
  });

  if (window.clarity) {
    window.clarity('event', 'hint_used', { level });
  }
};

export const trackShareScore = (score: number, platform: string) => {
  ReactGA.event({
    category: 'Social',
    action: 'share_score',
    label: platform,
    value: score,
    dimension1: platform
  });

  if (window.clarity) {
    window.clarity('event', 'share_score', { score, platform });
  }
};

// Achievement tracking
export const trackAchievementUnlocked = (achievementId: string) => {
  ReactGA.event({
    category: 'Achievement',
    action: 'achievement_unlocked',
    label: achievementId,
    dimension1: achievementId
  });

  if (window.clarity) {
    window.clarity('event', 'achievement_unlocked', { achievementId });
  }
};

// Ad interaction tracking
export const trackAdInteraction = (adType: string, action: 'init' | 'request' | 'complete' | 'incomplete' | 'error' | 'init_error') => {
  ReactGA.event({
    category: 'Ads',
    action: 'ad_interaction',
    label: `${adType}_${action}`,
    dimension1: adType,
    dimension2: action,
    nonInteraction: action === 'error' || action === 'init_error'
  });

  if (window.clarity) {
    window.clarity('event', 'ad_interaction', { adType, action });
  }
};

// Performance tracking
export const trackPerformanceMetrics = (fps: number, frameTime: number) => {
  ReactGA.event({
    category: 'Performance',
    action: 'performance_metrics',
    label: 'Performance',
    metric1: fps,
    metric2: frameTime
  });

  if (window.clarity) {
    window.clarity('event', 'performance_metrics', { fps, frameTime });
  }
};

// Error tracking
export const trackError = (error: Error, fatal: boolean = false) => {
  ReactGA.event({
    category: 'Error',
    action: 'error_occurred',
    label: error.message,
    nonInteraction: true,
    fatal
  });

  if (window.clarity) {
    window.clarity('event', 'error', {
      message: error.message,
      fatal
    });
  }
};

// User preferences
export const trackThemeChange = (theme: string) => {
  ReactGA.event({
    category: 'User Preference',
    action: 'theme_change',
    label: theme
  });

  if (window.clarity) {
    window.clarity('event', 'theme_change', { theme });
  }
};

// Session timing
export const trackTiming = (
  category: string,
  variable: string,
  value: number,
  label?: string
) => {
  ReactGA.send({
    hitType: 'timing',
    timingCategory: category,
    timingVar: variable,
    timingValue: value,
    timingLabel: label
  });

  if (window.clarity) {
    window.clarity('event', 'timing', {
      category,
      variable,
      value,
      label
    });
  }
};