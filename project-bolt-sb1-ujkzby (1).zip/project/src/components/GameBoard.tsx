import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Category, GameSet } from '../types/game';
import { GameCard } from './GameCard';

type GameBoardProps = {
  category: Category;
  gameSet: GameSet;
  showHint: boolean;
  onGuess: (item: string) => void;
  isGameOver: boolean;
};

export function GameBoard({ category, gameSet, showHint, onGuess, isGameOver }: GameBoardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="bg-white dark:bg-[#1C1C1E] rounded-2xl sm:rounded-3xl p-4 sm:p-6 md:p-8 shadow-sm mx-4 sm:mx-auto max-w-4xl w-full"
    >
      <div className="text-center mb-6 sm:mb-8">
        <motion.div
          initial={{ scale: 0.9 }}
          animate={{ scale: 1 }}
          className="inline-block px-3 sm:px-4 py-1.5 sm:py-2 bg-system-blue/10 dark:bg-system-blue-dark/10 rounded-full text-system-blue dark:text-system-blue-dark text-sm sm:text-base font-medium mb-3 sm:mb-4"
        >
          {category.name}
        </motion.div>
        <h2 className="text-2xl sm:text-3xl font-bold text-[#1D1D1F] dark:text-white mb-2">
          Find the Odd One Out
        </h2>
        <p className="text-sm sm:text-base text-system-gray-1 dark:text-system-gray-dark-1">
          Select the item that doesn't belong in this set
        </p>
      </div>
      
      <div className="grid grid-cols-2 gap-3 sm:gap-4 md:gap-6 mb-4 sm:mb-6">
        {gameSet.items.map((item, index) => (
          <GameCard
            key={item}
            item={item}
            index={index}
            onClick={() => onGuess(item)}
            disabled={isGameOver}
          />
        ))}
      </div>

      <AnimatePresence>
        {showHint && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            className="p-4 sm:p-6 bg-[#F5F5F7] dark:bg-[#2C2C2E] rounded-xl sm:rounded-2xl text-center"
          >
            <p className="text-sm sm:text-base text-[#1D1D1F] dark:text-white font-medium">{gameSet.hint}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}