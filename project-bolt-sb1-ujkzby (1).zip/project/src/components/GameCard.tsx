import React from 'react';
import { motion } from 'framer-motion';

type GameCardProps = {
  item: string;
  index: number;
  onClick: () => void;
  disabled: boolean;
};

export function GameCard({ item, index, onClick, disabled }: GameCardProps) {
  return (
    <motion.button
      initial={{ opacity: 0, y: 20 }}
      animate={{ 
        opacity: 1, 
        y: 0,
        transition: { delay: index * 0.1 }
      }}
      whileHover={disabled ? {} : { 
        scale: 1.02,
        backgroundColor: '#F5F5F7'
      }}
      whileTap={disabled ? {} : { scale: 0.98 }}
      className={`
        relative w-full aspect-square
        flex items-center justify-center
        bg-white rounded-2xl
        text-2xl font-medium
        border-2 border-transparent
        transition-colors duration-200
        ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer hover:border-[#007AFF]'}
        shadow-sm hover:shadow-md
      `}
      onClick={onClick}
      disabled={disabled}
    >
      <span className="relative z-10">{item}</span>
      <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50 rounded-2xl -z-0" />
    </motion.button>
  );
}