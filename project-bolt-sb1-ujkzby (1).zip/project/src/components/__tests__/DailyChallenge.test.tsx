import React from 'react';
import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { DailyChallenge } from '../DailyChallenge';

describe('DailyChallenge', () => {
  const defaultProps = {
    onStart: vi.fn(),
    completed: false,
    highScore: 0
  };

  beforeEach(() => {
    vi.resetAllMocks();
  });

  it('renders daily challenge title', () => {
    render(<DailyChallenge {...defaultProps} />);
    expect(screen.getByText('Daily Challenge')).toBeInTheDocument();
  });

  it('shows correct badge based on completion status', () => {
    const { rerender } = render(<DailyChallenge {...defaultProps} />);
    expect(screen.getByText('New')).toBeInTheDocument();

    rerender(<DailyChallenge {...defaultProps} completed={true} />);
    expect(screen.getByText('Completed')).toBeInTheDocument();
  });

  it('handles start button click', () => {
    render(<DailyChallenge {...defaultProps} />);
    fireEvent.click(screen.getByText('Start Challenge'));
    expect(defaultProps.onStart).toHaveBeenCalled();
  });

  it('disables button when completed', () => {
    render(<DailyChallenge {...defaultProps} completed={true} />);
    const button = screen.getByText('Come back tomorrow!');
    expect(button).toBeDisabled();
  });

  it('shows high score when available', () => {
    render(<DailyChallenge {...defaultProps} highScore={1000} />);
    expect(screen.getByText('Best: 1000')).toBeInTheDocument();
  });

  it('shows remaining time', () => {
    render(<DailyChallenge {...defaultProps} />);
    expect(screen.getByText(/Available for:/)).toBeInTheDocument();
  });
});