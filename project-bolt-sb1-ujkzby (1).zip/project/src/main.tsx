import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import { GAProvider } from './modules/analytics/GoogleAnalytics';
import { ClarityProvider } from './modules/analytics/MicrosoftClarity';
import './index.css';

// Performance optimizations
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/sw.js').catch(console.error);
  });
}

// Use passive listeners to improve scrolling performance
document.addEventListener('touchstart', () => {}, { passive: true });
document.addEventListener('wheel', () => {}, { passive: true });

// Initialize app with error boundary and analytics
const initApp = () => {
  const root = document.getElementById('root');
  if (!root) throw new Error('Root element not found');

  // Report Web Vitals
  if (process.env.NODE_ENV === 'production') {
    import('web-vitals').then(({ getCLS, getFID, getLCP }) => {
      getCLS(console.log);
      getFID(console.log);
      getLCP(console.log);
    });
  }

  createRoot(root).render(
    <StrictMode>
      <GAProvider>
        <ClarityProvider>
          <App />
        </ClarityProvider>
      </GAProvider>
    </StrictMode>
  );
};

initApp();