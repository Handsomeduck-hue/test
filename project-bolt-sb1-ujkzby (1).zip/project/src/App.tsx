import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { GameBoard } from './components/GameBoard';
import { GameHeader } from './components/GameHeader';
import { GameOver } from './components/GameOver';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ThemeSelector } from './components/ThemeSelector';
import { PrivacyPolicy } from './components/PrivacyPolicy';
import { TermsOfService } from './components/TermsOfService';
import { Footer } from './components/Footer';
import { useGameStore } from './store/gameStore';
import { useAdStore } from './modules/ads/AdManager';
import { useTheme } from './modules/ui/hooks/useTheme';
import { cn } from './modules/ui/utils/cn';
import { trackGameStart, trackGameOver, trackLevelComplete } from './modules/analytics/AnalyticsManager';
import { TourProvider } from './modules/tour/TourProvider';

export default function App() {
  const { state, actions } = useGameStore();
  const { actions: adActions } = useAdStore();
  const { colorTheme } = useTheme();

  useEffect(() => {
    adActions.initializeAds();
  }, []);

  useEffect(() => {
    const timer = setInterval(actions.updateTimer, 100);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    if (state.gameStarted) {
      trackGameStart();
    }
  }, [state.gameStarted]);

  useEffect(() => {
    if (state.gameOver) {
      trackGameOver(state);
    }
  }, [state.gameOver]);

  useEffect(() => {
    if (state.lastResult?.correct) {
      trackLevelComplete(state.currentLevel, state.score);
    }
  }, [state.currentLevel]);

  const handleContinue = () => {
    actions.addLife();
    actions.resumeGame();
  };

  return (
    <Router>
      <TourProvider>
        <div className={cn(
          "min-h-screen theme-transition flex flex-col",
          "bg-gradient-to-b",
          `from-[var(--theme-base)] to-white/95 dark:to-black/95`
        )}>
          <div className="relative flex-1">
            <div className={cn(
              "absolute inset-0",
              "backdrop-blur-xl",
              "bg-white/30 dark:bg-black/30",
              "theme-transition"
            )} />
            
            <main className="relative">
              <Routes>
                <Route path="/privacy" element={<PrivacyPolicy />} />
                <Route path="/terms" element={<TermsOfService />} />
                <Route path="/" element={
                  !state.gameStarted ? (
                    <WelcomeScreen onStart={actions.startGame} />
                  ) : (
                    <div className="max-w-4xl mx-auto p-4 space-y-6">
                      <GameHeader
                        score={state.score}
                        lives={state.lives}
                        level={state.currentLevel}
                        timeRemaining={state.timeRemaining}
                        currentStreak={state.currentStreak}
                        hintsRemaining={state.hintsRemaining}
                        onUseHint={actions.useHint}
                      />
                      
                      <AnimatePresence mode="wait">
                        {state.currentCategory && state.currentSet && (
                          <GameBoard
                            category={state.currentCategory}
                            gameSet={state.currentSet}
                            showHint={state.showHint}
                            onGuess={actions.makeGuess}
                            isGameOver={state.gameOver}
                          />
                        )}
                      </AnimatePresence>

                      <AnimatePresence>
                        {state.gameOver && (
                          <GameOver
                            score={state.score}
                            bestStreak={state.bestStreak}
                            level={state.currentLevel}
                            timeBonus={state.timeBonus}
                            streakBonus={state.streakBonus}
                            difficultyBonus={state.difficultyBonus}
                            onRestart={actions.resetGame}
                            onContinue={handleContinue}
                          />
                        )}
                      </AnimatePresence>
                    </div>
                  )
                } />
              </Routes>

              <ThemeSelector />
            </main>
          </div>
          <Footer />
        </div>
      </TourProvider>
    </Router>
  );
}