import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { categories } from '../data/categories';
import { GameState, GameSet, Category, Difficulty } from '../types/game';
import { calculateTimeLimit } from '../modules/game/utils/scoring';

const INITIAL_STATE: GameState = {
  score: 0,
  currentLevel: 1,
  lives: 3,
  gameOver: false,
  gameStarted: false,
  hintsRemaining: 3,
  currentStreak: 0,
  bestStreak: 0,
  timeRemaining: 30,
  showHint: false,
  lastResult: null,
  difficulty: Difficulty.Easy,
  totalGamesPlayed: 0,
  highScores: [],
  timeBonus: 0,
  streakBonus: 0,
  difficultyBonus: 0,
  achievements: [],
};

const getRandomSet = (category: Category): GameSet => {
  const availableSets = category.sets;
  return availableSets[Math.floor(Math.random() * availableSets.length)];
};

const getRandomCategory = (difficulty?: Difficulty): Category => {
  const filteredCategories = difficulty
    ? categories.filter(c => c.difficulty === difficulty)
    : categories;
  return filteredCategories[Math.floor(Math.random() * filteredCategories.length)];
};

export const useGameStore = create<{
  state: GameState;
  actions: {
    startGame: () => void;
    makeGuess: (item: string) => void;
    useHint: () => void;
    resetGame: () => void;
    updateTimer: () => void;
    addLife: () => void;
    resumeGame: () => void;
  };
}>()(
  persist(
    (set, get) => ({
      state: INITIAL_STATE,
      actions: {
        startGame: () => {
          const category = getRandomCategory();
          const gameSet = getRandomSet(category);
          set({
            state: {
              ...INITIAL_STATE,
              gameStarted: true,
              timeRemaining: calculateTimeLimit(1, Difficulty.Easy),
              currentCategory: category,
              currentSet: gameSet,
            },
          });
        },
        makeGuess: (item: string) => {
          const { state } = get();
          if (!state.currentSet) return;
          
          const isCorrect = state.currentSet.oddOneOut === item;

          if (isCorrect) {
            const category = getRandomCategory(state.difficulty);
            const gameSet = getRandomSet(category);
            const timeBonus = Math.ceil(state.timeRemaining * 10);
            const streakBonus = state.currentStreak * 50;
            const difficultyBonus = (() => {
              switch (state.difficulty) {
                case Difficulty.Expert: return 200;
                case Difficulty.Hard: return 150;
                case Difficulty.Medium: return 100;
                default: return 50;
              }
            })();
            
            const newScore = state.score + timeBonus + streakBonus + difficultyBonus;
            const newLevel = state.currentLevel + 1;
            
            set({
              state: {
                ...state,
                score: newScore,
                currentLevel: newLevel,
                currentStreak: state.currentStreak + 1,
                bestStreak: Math.max(state.currentStreak + 1, state.bestStreak),
                timeRemaining: calculateTimeLimit(newLevel, state.difficulty),
                currentCategory: category,
                currentSet: gameSet,
                showHint: false,
                timeBonus,
                streakBonus,
                difficultyBonus,
                lastResult: { 
                  correct: true, 
                  bonus: streakBonus + difficultyBonus,
                  message: `Perfect! +${timeBonus} time bonus, +${streakBonus} streak bonus, +${difficultyBonus} difficulty bonus`
                },
              },
            });
          } else {
            const newLives = state.lives - 1;
            const isGameOver = newLives === 0;
            
            if (isGameOver) {
              const newHighScores = [...state.highScores, {
                score: state.score,
                date: new Date().toISOString(),
                difficulty: state.difficulty,
                level: state.currentLevel,
                achievements: state.achievements,
              }].sort((a, b) => b.score - a.score).slice(0, 10);

              set({
                state: {
                  ...state,
                  lives: newLives,
                  gameOver: true,
                  currentStreak: 0,
                  showHint: false,
                  totalGamesPlayed: state.totalGamesPlayed + 1,
                  highScores: newHighScores,
                  lastResult: { 
                    correct: false, 
                    mistake: item,
                    message: 'Game Over! Your score has been recorded.'
                  },
                },
              });
            } else {
              set({
                state: {
                  ...state,
                  lives: newLives,
                  currentStreak: 0,
                  showHint: false,
                  lastResult: { 
                    correct: false, 
                    mistake: item,
                    message: `Wrong! ${newLives} ${newLives === 1 ? 'life' : 'lives'} remaining`
                  },
                },
              });
            }
          }
        },
        useHint: () => {
          const { state } = get();
          if (state.hintsRemaining > 0) {
            set({
              state: {
                ...state,
                hintsRemaining: state.hintsRemaining - 1,
                showHint: true,
              },
            });
          }
        },
        resetGame: () => {
          const category = getRandomCategory();
          const gameSet = getRandomSet(category);
          set({
            state: {
              ...INITIAL_STATE,
              gameStarted: true,
              timeRemaining: calculateTimeLimit(1, Difficulty.Easy),
              currentCategory: category,
              currentSet: gameSet,
            },
          });
        },
        updateTimer: () => {
          const { state } = get();
          if (state.timeRemaining > 0 && !state.gameOver && state.gameStarted) {
            const newTimeRemaining = Math.max(0, state.timeRemaining - 0.1);
            set({
              state: {
                ...state,
                timeRemaining: newTimeRemaining,
                gameOver: newTimeRemaining === 0,
              },
            });
          }
        },
        addLife: () => {
          const { state } = get();
          set({
            state: {
              ...state,
              lives: state.lives + 1,
            },
          });
        },
        resumeGame: () => {
          const { state } = get();
          set({
            state: {
              ...state,
              gameOver: false,
              timeRemaining: calculateTimeLimit(state.currentLevel, state.difficulty),
            },
          });
        },
      },
    }),
    {
      name: 'odd-one-out-game',
      partialize: (state) => ({
        highScores: state.state.highScores,
        bestStreak: state.state.bestStreak,
        totalGamesPlayed: state.state.totalGamesPlayed,
        achievements: state.state.achievements,
      }),
    }
  )
);