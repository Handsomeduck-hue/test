import React from 'react';
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { Card } from '../Card';

describe('Card', () => {
  it('renders children correctly', () => {
    render(<Card>Card content</Card>);
    expect(screen.getByText('Card content')).toBeInTheDocument();
  });

  it('applies custom className', () => {
    render(<Card className="custom-class">Content</Card>);
    expect(screen.getByText('Content').parentElement).toHaveClass('custom-class');
  });

  it('renders without animation when animate is false', () => {
    render(<Card animate={false}>Content</Card>);
    const element = screen.getByText('Content').parentElement;
    expect(element?.tagName.toLowerCase()).toBe('div');
  });

  it('applies different variants correctly', () => {
    const { rerender } = render(<Card variant="default">Content</Card>);
    expect(screen.getByText('Content').parentElement).toHaveClass('shadow-sm');

    rerender(<Card variant="elevated">Content</Card>);
    expect(screen.getByText('Content').parentElement).toHaveClass('shadow-lg');
  });

  it('applies dark mode classes', () => {
    render(<Card>Content</Card>);
    const element = screen.getByText('Content').parentElement;
    expect(element).toHaveClass('dark:bg-[#1C1C1E]');
    expect(element).toHaveClass('dark:border-[#38383A]');
  });
});